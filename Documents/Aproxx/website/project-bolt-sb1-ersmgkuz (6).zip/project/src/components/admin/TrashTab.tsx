import React, { useState } from 'react';
import { useSigns } from '../../context/SignsContext';
import { Search, RefreshCw, Trash2, Download } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

function TrashTab() {
  const { trashedSigns, restoreFromTrash, emptyTrash, deleteSign } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Sort by trash date (newest first)
  const sortedTrash = [...trashedSigns].sort((a, b) => 
    new Date(b.trashedAt || b.updatedAt).getTime() - 
    new Date(a.trashedAt || a.updatedAt).getTime()
  );
  
  // Apply search filter
  const filteredTrash = sortedTrash.filter(sign => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  const handleRestore = (id: string) => {
    restoreFromTrash(id);
    toast.success('Bord succesvol hersteld');
  };

  const handleDelete = (id: string) => {
    if (confirm('Weet u zeker dat u dit bord permanent wilt verwijderen? Deze actie kan niet ongedaan worden gemaakt.')) {
      deleteSign(id);
      toast.success('Bord permanent verwijderd');
    }
  };

  const handleEmptyTrash = () => {
    if (trashedSigns.length === 0) {
      toast.error('Prullenbak is al leeg');
      return;
    }
    
    if (confirm(`Weet u zeker dat u alle ${trashedSigns.length} borden in de prullenbak permanent wilt verwijderen? Deze actie kan niet ongedaan worden gemaakt.`)) {
      emptyTrash();
      toast.success('Prullenbak succesvol geleegd');
    }
  };

  const handleDownloadImage = (imageUrl: string) => {
    // In a real app, this would download the actual image
    // For now, we'll just open it in a new tab
    window.open(imageUrl, '_blank');
    toast.success('Afbeelding geopend in nieuw tabblad');
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Prullenbak</h2>
      
      <div className="flex justify-between items-center mb-4">
        <div className="text-sm text-gray-500">
          {trashedSigns.length} items in prullenbak
        </div>
        
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Zoek in prullenbak..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
            />
          </div>
          
          <button
            onClick={handleEmptyTrash}
            disabled={trashedSigns.length === 0}
            className={`btn btn-danger flex items-center ${
              trashedSigns.length === 0 ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            <Trash2 size={16} className="mr-1" />
            <span>Leeg Prullenbak</span>
          </button>
        </div>
      </div>
      
      {filteredTrash.length === 0 ? (
        <div className="text-center py-20 text-gray-500 border rounded-lg">
          <Trash2 size={48} className="mx-auto text-gray-300 mb-4" />
          <p>Prullenbak is leeg</p>
        </div>
      ) : (
        <div className="fixed-height-container">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bord Details
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Vorige Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Naar Prullenbak
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acties
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredTrash.map(sign => {
                  // Get previous status before trashing
                  const prevStatusItem = sign.statusHistory[sign.statusHistory.length - 2];
                  const prevStatus = prevStatusItem ? prevStatusItem.status : 'unknown';
                  
                  return (
                    <tr key={sign.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          {sign.imageUrl && (
                            <div className="w-10 h-10 rounded overflow-hidden mr-3">
                              <div 
                                style={{
                                  width: '100%',
                                  height: '100%',
                                  backgroundImage: `url(${sign.imageUrl})`,
                                  backgroundSize: 'cover',
                                  backgroundPosition: 'center',
                                  cursor: 'pointer'
                                }}
                                onClick={() => handleDownloadImage(sign.imageUrl!)}
                              ></div>
                            </div>
                          )}
                          <div>
                            <div className="font-medium text-gray-900">{sign.companyName}</div>
                            <div className="text-sm text-gray-500">{sign.address}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`status-badge status-${prevStatus}`}>
                          {prevStatus === 'pending' ? 'In afwachting' :
                           prevStatus === 'confirmed' ? 'Bevestigd' :
                           prevStatus === 'placed' ? 'Geplaatst' :
                           prevStatus === 'removal-requested' ? 'Verwijdering aangevraagd' :
                           prevStatus === 'removal-confirmed' ? 'Verwijdering bevestigd' :
                           prevStatus === 'removed' ? 'Verwijderd' :
                           prevStatus.replace('-', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {sign.trashedAt 
                          ? formatDistanceToNow(new Date(sign.trashedAt), { addSuffix: true }) 
                          : 'Onbekend'
                        }
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => handleRestore(sign.id)}
                            className="btn btn-sm btn-secondary flex items-center"
                          >
                            <RefreshCw size={14} className="mr-1" />
                            <span>Herstellen</span>
                          </button>
                          
                          <button
                            onClick={() => handleDelete(sign.id)}
                            className="btn btn-sm btn-danger flex items-center"
                          >
                            <Trash2 size={14} className="mr-1" />
                            <span>Verwijderen</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export default TrashTab;