import React, { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import LoginPage from './components/auth/LoginPage';
import AdminDashboard from './components/admin/AdminDashboard';
import UserDashboard from './components/user/UserDashboard';
import { AuthProvider } from './context/AuthContext';
import { SignsProvider } from './context/SignsContext';
import { InvoiceProvider } from './context/InvoiceContext';
import { decryptData, encryptData } from './utils/encryption';
import './App.css';

interface UserAccount {
  id: string;
  companyName: string;
  username: string;
  password: string;
  createdAt: string;
  lastLogin?: string;
}

const STORAGE_KEY = 'userAccounts_encrypted';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);

  // Check if user is already logged in
  useEffect(() => {
    const user = localStorage.getItem('currentUser');
    if (user) {
      const userData = JSON.parse(user);
      setIsAuthenticated(true);
      setIsAdmin(userData.isAdmin);
      setCurrentUser(userData.isAdmin ? null : userData);
    }
  }, []);

  const handleLogin = (username: string, password: string) => {
    // Check admin login first
    if (username === 'admin' && password === 'admin123') {
      const adminData = { username: 'admin', isAdmin: true };
      localStorage.setItem('currentUser', JSON.stringify(adminData));
      setIsAuthenticated(true);
      setIsAdmin(true);
      setCurrentUser(null);
      return true;
    }

    // Check user accounts from encrypted storage
    const savedUsers = localStorage.getItem(STORAGE_KEY);
    if (savedUsers) {
      try {
        const encryptedData = JSON.parse(savedUsers);
        const decryptedData = decryptData(encryptedData);
        const users: UserAccount[] = JSON.parse(decryptedData);
        const user = users.find(u => u.username === username && u.password === password);
        
        if (user) {
          // Update last login time in encrypted storage
          const updatedUsers = users.map(u => 
            u.id === user.id 
              ? { ...u, lastLogin: new Date().toISOString() }
              : u
          );
          
          // Re-encrypt and save
          const dataToEncrypt = JSON.stringify(updatedUsers);
          const encryptedUpdatedData = encryptData(dataToEncrypt);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(encryptedUpdatedData));
          
          // Set current user
          const userData = { ...user, isAdmin: false, lastLogin: new Date().toISOString() };
          localStorage.setItem('currentUser', JSON.stringify(userData));
          setIsAuthenticated(true);
          setIsAdmin(false);
          setCurrentUser(userData);
          return true;
        }
      } catch (error) {
        console.error('Error parsing user accounts:', error);
      }
    }

    return false;
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setIsAuthenticated(false);
    setIsAdmin(false);
    setCurrentUser(null);
  };

  return (
    <AuthProvider value={{ isAuthenticated, isAdmin, login: handleLogin, logout: handleLogout }}>
      <SignsProvider>
        <InvoiceProvider>
          <div className="App font-montserrat">
            {!isAuthenticated ? (
              <LoginPage onLogin={handleLogin} />
            ) : (
              isAdmin ? <AdminDashboard /> : <UserDashboard />
            )}
            <Toaster position="top-right" />
          </div>
        </InvoiceProvider>
      </SignsProvider>
    </AuthProvider>
  );
}

export default App;