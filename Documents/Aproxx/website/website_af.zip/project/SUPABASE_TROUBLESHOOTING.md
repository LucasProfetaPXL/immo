# 🔧 Supabase Setup Troubleshooting

Je krijgt "Something went wrong while setting up Supabase" - dit betekent dat de configuratie niet correct is.

## 🎯 Stap 1: Controleer Environment Variables

Open je `.env` bestand en controleer of het er zo uitziet:

```env
VITE_SUPABASE_URL=https://jouwprojectid.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**BELANGRIJK**: Vervang deze waarden met je NIEUWE Supabase project credentials!

## 🎯 Stap 2: Haal Nieuwe Credentials Op

1. Ga naar je **nieuwe** Supabase Dashboard
2. Ga naar **Settings** → **API**
3. Kopieer deze 3 waarden:
   - **Project URL** (bijv. `https://abcdefg.supabase.co`)
   - **anon public** key (lange string)
   - **service_role** key (andere lange string)

## 🎯 Stap 3: Database Schema Installeren

1. Ga naar **SQL Editor** in je Supabase Dashboard
2. Klik **"New query"**
3. Kopieer de VOLLEDIGE inhoud van het bestand:
   `supabase/migrations/20250706094719_lingering_sunset.sql`
4. Plak in de SQL Editor
5. Klik **"Run"**
6. Wacht op "Success"

## 🎯 Stap 4: Verificatie

Na het uitvoeren van de SQL, controleer:

1. **Tabellen**: Ga naar **Table Editor** - je zou deze tabellen moeten zien:
   - users
   - signs
   - billing_details
   - invoices
   - images

2. **Storage**: Ga naar **Storage** - je zou een "images" bucket moeten zien

3. **Policies**: Ga naar **Authentication** → **Policies** - er zouden RLS policies moeten zijn

## 🎯 Stap 5: Test de Verbinding

1. Herstart je development server:
   ```bash
   # Stop (Ctrl+C) en start opnieuw
   npm run dev
   ```

2. Open de applicatie en test:
   - Login met admin/admin123
   - Probeer een gebruiker aan te maken

## 🚨 Veel Voorkomende Problemen

### "Invalid API URL"
- Controleer dat je URL eindigt op `.supabase.co`
- Geen trailing slash `/` aan het einde

### "Invalid API Key"
- Controleer dat je de juiste keys hebt gekopieerd
- Anon key en Service Role key zijn verschillend

### "Bucket not found"
- De database schema is niet correct geïnstalleerd
- Voer de SQL migratie opnieuw uit

### "Unauthorized"
- RLS policies zijn niet correct
- Voer de complete migratie opnieuw uit

## 📞 Als Het Nog Steeds Niet Werkt

1. Open browser console (F12) en kijk naar error berichten
2. Controleer Supabase Dashboard logs
3. Zorg dat je project actief is (niet gepauzeerd)
4. Probeer een nieuwe browser/incognito mode

## ✅ Success Indicatoren

Je weet dat het werkt wanneer:
- Applicatie laadt zonder "Something went wrong" error
- Admin login (admin/admin123) werkt
- Je kunt nieuwe gebruikers aanmaken
- Afbeelding upload werkt

De error zou nu opgelost moeten zijn!