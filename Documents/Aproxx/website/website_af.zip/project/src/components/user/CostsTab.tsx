import React, { useState, useEffect } from 'react';
import { useSigns } from '../../context/SignsContext';
import { useInvoices } from '../../context/InvoiceContext';
import CostsMainTab from './costs/CostsMainTab';
import InvoicesTab from './costs/InvoicesTab';
import { Receipt, FileText } from 'lucide-react';

type CostsSubTabType = 'main' | 'invoices';

interface CostsTabProps {
  onInvoiceGenerated?: () => void;
}

function CostsTab({ onInvoiceGenerated }: CostsTabProps) {
  const [activeSubTab, setActiveSubTab] = useState<CostsSubTabType>('main');
  const { invoices } = useInvoices();

  // Switch to invoices tab when a new invoice is generated
  useEffect(() => {
    if (onInvoiceGenerated) {
      setActiveSubTab('invoices');
    }
  }, [onInvoiceGenerated]);

  const renderTab = () => {
    switch (activeSubTab) {
      case 'main':
        return <CostsMainTab onInvoiceGenerated={() => setActiveSubTab('invoices')} />;
      case 'invoices':
        return <InvoicesTab />;
      default:
        return <CostsMainTab onInvoiceGenerated={() => setActiveSubTab('invoices')} />;
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Kostenbeheer</h2>
      
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-2 px-4">
            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'main'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => setActiveSubTab('main')}
            >
              <Receipt size={16} className="mr-2" />
              <span>Borden & Kosten</span>
            </button>
            
            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'invoices'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => setActiveSubTab('invoices')}
            >
              <FileText size={16} className="mr-2" />
              <span>Facturen</span>
              {invoices.length > 0 && (
                <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs bg-gray-100">
                  {invoices.length}
                </span>
              )}
            </button>
          </nav>
        </div>
        
        <div className="p-4">
          {renderTab()}
        </div>
      </div>
    </div>
  );
}

export default CostsTab;