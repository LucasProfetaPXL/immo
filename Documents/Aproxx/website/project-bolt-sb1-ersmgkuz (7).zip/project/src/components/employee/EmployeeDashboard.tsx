import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import EmployeeNavigation from './EmployeeNavigation';
import EmployeePlaceSignsTab from './EmployeePlaceSignsTab';
import EmployeeRemoveSignsTab from './EmployeeRemoveSignsTab';
import { LogOut } from 'lucide-react';

type EmployeeTabType = 'place-signs' | 'remove-signs';

function EmployeeDashboard() {
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState<EmployeeTabType>('place-signs');

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-gray-900">Bordbeheer Systeem - Werknemer</h1>
            {currentUser && currentUser.companyName && (
              <>
                <span className="mx-3 text-gray-400">•</span>
                <span className="text-lg font-medium text-green-600">{currentUser.companyName}</span>
                <span className="mx-2 text-gray-400">•</span>
                <span className="text-sm text-gray-600">{currentUser.username}</span>
              </>
            )}
          </div>
          <button
            onClick={logout}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <LogOut size={16} className="mr-1" />
            <span>Uitloggen</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <EmployeeNavigation activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-4 bg-white rounded-lg shadow">
          <div style={{ display: activeTab === 'place-signs' ? 'block' : 'none' }}>
            <EmployeePlaceSignsTab />
          </div>
          <div style={{ display: activeTab === 'remove-signs' ? 'block' : 'none' }}>
            <EmployeeRemoveSignsTab />
          </div>
        </div>
      </main>
    </div>
  );
}

export default EmployeeDashboard;