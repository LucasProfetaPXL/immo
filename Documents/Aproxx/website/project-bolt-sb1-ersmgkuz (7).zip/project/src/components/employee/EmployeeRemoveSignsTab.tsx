import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useSigns } from '../../context/SignsContext';
import SignMap from '../common/SignMap';
import ProofUploadModal from '../common/ProofUploadModal';
import ImageViewerModal from '../common/ImageViewerModal';
import { Search, Check, X, Tag, Download, Camera, Users, Eye } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { getEmployeeWorkAssignment } from '../../utils/workDistribution';
import toast from 'react-hot-toast';

// Belgium bounds
const belgiumBounds = [[49.5, 2.5], [51.5, 6.4]] as L.LatLngBoundsExpression;
const defaultCenter = [50.8503, 4.3517] as [number, number]; // Brussels

function EmployeeRemoveSignsTab() {
  const { signs, updateSignStatus, updateSign } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSigns, setSelectedSigns] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showProofModal, setShowProofModal] = useState(false);
  const [currentSignId, setCurrentSignId] = useState<string | null>(null);
  const [assignedSigns, setAssignedSigns] = useState<any[]>([]);
  const [workAssignment, setWorkAssignment] = useState<any>(null);
  const [imageViewerState, setImageViewerState] = useState<{
    isOpen: boolean;
    images: string[];
    currentIndex: number;
    title: string;
    description: string;
  }>({
    isOpen: false,
    images: [],
    currentIndex: 0,
    title: '',
    description: ''
  });
  
  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();
  
  // Load work assignment for current employee
  useEffect(() => {
    if (currentUser && currentUser.id) {
      console.log(`👤 Loading work assignment for employee: ${currentUser.username}`);
      const assignment = getEmployeeWorkAssignment(currentUser.id);
      setWorkAssignment(assignment);
      
      if (assignment) {
        console.log(`📋 Employee ${currentUser.username} assigned ${assignment.removalSigns.length} removal signs`);
        setAssignedSigns(assignment.removalSigns);
      } else {
        console.log(`❌ No work assignment found for employee: ${currentUser.username}`);
        setAssignedSigns([]);
      }
    }
  }, [currentUser, signs]); // Re-calculate when signs change
  
  // Apply search filter to assigned signs
  const filteredSigns = assignedSigns.filter(sign => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  // Download image function
  const handleDownloadImage = (imageUrl: string, address: string) => {
    try {
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success('Afbeelding download gestart');
    } catch (error) {
      console.error('Download error:', error);
      window.open(imageUrl, '_blank');
      toast.success('Afbeelding geopend in nieuw tabblad');
    }
  };

  // Open image viewer for placement images
  const handleViewPlacementImages = (sign: any) => {
    if (!sign.placementDetails?.placementImages || sign.placementDetails.placementImages.length === 0) {
      return;
    }

    setImageViewerState({
      isOpen: true,
      images: sign.placementDetails.placementImages,
      currentIndex: 0,
      title: 'Plaatsingsafbeeldingen',
      description: `${sign.address} - ${sign.placementDetails.placementImages.length} afbeelding(en)`
    });
  };

  // Open image viewer for proof images
  const handleViewProofImage = (imageUrl: string, type: 'placed' | 'removed', address: string) => {
    setImageViewerState({
      isOpen: true,
      images: [imageUrl],
      currentIndex: 0,
      title: type === 'placed' ? 'Bewijs van Plaatsing' : 'Bewijs van Ophaling',
      description: address
    });
  };

  // Close image viewer
  const closeImageViewer = () => {
    setImageViewerState({
      isOpen: false,
      images: [],
      currentIndex: 0,
      title: '',
      description: ''
    });
  };

  const handleToggleSelect = (id: string) => {
    setSelectedSigns(prev => {
      if (prev.includes(id)) {
        return prev.filter(signId => signId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedSigns.length === filteredSigns.length) {
      setSelectedSigns([]);
    } else {
      setSelectedSigns(filteredSigns.map(sign => sign.id));
    }
  };

  const handleMarkPickedUp = () => {
    if (selectedSigns.length === 0) {
      toast.error('Selecteer ten minste één bord');
      return;
    }
    
    if (selectedSigns.length === 1) {
      // Single sign - show proof upload modal
      setCurrentSignId(selectedSigns[0]);
      setShowProofModal(true);
    } else {
      // Multiple signs - mark as removed without proof for now
      setIsSubmitting(true);
      
      setTimeout(() => {
        selectedSigns.forEach(id => {
          updateSignStatus(id, 'removed');
        });
        
        setSelectedSigns([]);
        setIsSubmitting(false);
        toast.success('Borden succesvol gemarkeerd als opgehaald!');
      }, 800);
    }
  };

  const handleProofSubmit = (proofImageUrl: string) => {
    if (currentSignId) {
      // Update sign with proof image and status
      updateSign(currentSignId, {
        proofImages: {
          ...signs.find(s => s.id === currentSignId)?.proofImages,
          removed: proofImageUrl
        }
      });
      updateSignStatus(currentSignId, 'removed');
      
      setSelectedSigns([]);
      setCurrentSignId(null);
      setShowProofModal(false);
      toast.success('Bord gemarkeerd als opgehaald met bewijs!');
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Borden Verwijderen</h2>
      
      {/* Work Assignment Info */}
      {workAssignment && (
        <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Users size={20} className="text-orange-600 mr-2" />
              <div>
                <h3 className="font-medium text-orange-800">Uw Werkgebied</h3>
                <p className="text-sm text-orange-600">
                  {workAssignment.removalSigns.length} borden om op te halen in uw toegewezen gebied
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-orange-600">Totaal werk toegewezen:</div>
              <div className="font-bold text-orange-800">{workAssignment.totalSigns} borden</div>
              <div className="text-xs text-orange-500">
                ({workAssignment.placementSigns.length} plaatsen + {workAssignment.removalSigns.length} ophalen)
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Section */}
        <div className="rounded-lg overflow-hidden border border-gray-200 h-[500px]">
          <MapContainer 
            center={workAssignment ? [workAssignment.centerLat, workAssignment.centerLng] : defaultCenter} 
            zoom={workAssignment ? 12 : 8} 
            style={{ height: '100%', width: '100%' }}
            zoomControl={true}
            scrollWheelZoom={true}
            maxBounds={belgiumBounds}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            <SignMap 
              signs={assignedSigns} 
              showPreview={true}
            />
          </MapContainer>
        </div>
        
        {/* Signs List Section */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg border border-gray-200">
            <div className="border-b border-gray-200 p-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Toegewezen Borden voor Ophaling</h3>
                
                <div className="flex items-center">
                  <div className="relative mr-2">
                    <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Zoek borden..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
                    />
                    {searchQuery && (
                      <button 
                        onClick={() => setSearchQuery('')}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      >
                        <X size={14} />
                      </button>
                    )}
                  </div>
                  
                  <button
                    onClick={handleSelectAll}
                    className="text-sm text-primary-blue hover:text-blue-700"
                  >
                    {selectedSigns.length === filteredSigns.length && filteredSigns.length > 0 
                      ? 'Deselecteer Alles' 
                      : 'Selecteer Alles'}
                  </button>
                </div>
              </div>
              
              <div>
                <button
                  onClick={handleMarkPickedUp}
                  disabled={selectedSigns.length === 0 || isSubmitting}
                  className={`btn ${
                    selectedSigns.length === 0
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'btn-danger'
                  } ${isSubmitting ? 'opacity-75 cursor-wait' : ''} flex items-center`}
                >
                  <Camera size={16} className="mr-2" />
                  {isSubmitting 
                    ? 'Verwerken...' 
                    : `Markeer als Opgehaald (${selectedSigns.length})`}
                </button>
              </div>
            </div>
            
            <div className="p-4">
              {filteredSigns.length === 0 ? (
                <div className="text-center py-10 text-gray-500">
                  {assignedSigns.length === 0 ? (
                    <p>Geen borden toegewezen voor ophaling</p>
                  ) : (
                    <p>Geen borden gevonden die voldoen aan uw zoekcriteria</p>
                  )}
                </div>
              ) : (
                <div className="fixed-height-container">
                  <div className="space-y-2 p-2">
                    {filteredSigns.map(sign => (
                      <div 
                        key={sign.id}
                        className={`p-4 rounded-md border transition-colors ${
                          selectedSigns.includes(sign.id)
                            ? 'border-primary-blue bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center">
                              <input
                                type="checkbox"
                                className="mr-3 h-5 w-5 text-primary-blue rounded border-gray-300 focus:ring-primary-blue"
                                checked={selectedSigns.includes(sign.id)}
                                onChange={() => handleToggleSelect(sign.id)}
                              />
                              <div>
                                <p className="font-medium">{sign.companyName}</p>
                                <p className="text-sm text-gray-600">{sign.address}</p>
                              </div>
                            </div>
                            
                            <div className="flex items-center mt-2 ml-8">
                              <span className="status-badge status-removal-confirmed">
                                Verwijderd
                              </span>
                              <span className="text-xs text-gray-500 ml-2">
                                Verwijderd {formatDateInDutch(new Date(sign.updatedAt))}
                              </span>
                            </div>

                            {/* Show placement details if available */}
                            {sign.placementDetails && (
                              <div className="ml-8 mt-2 p-2 bg-orange-50 rounded text-xs">
                                {sign.placementDetails.specificLocation && (
                                  <div className="text-orange-700">
                                    📍 <strong>Oorspronkelijke locatie:</strong> {sign.placementDetails.specificLocation}
                                  </div>
                                )}
                                <div className="text-orange-700">
                                  🔄 <strong>Oriëntatie:</strong> {sign.placementDetails.orientation === 'above-ballast' ? 'Boven de ballast' : 'Links van de ballast'}
                                </div>
                                {sign.placementDetails.placementImages && sign.placementDetails.placementImages.length > 0 && (
                                  <div className="text-orange-700 flex items-center">
                                    <span>📷 <strong>Plaatsingsafbeeldingen:</strong> {sign.placementDetails.placementImages.length} beschikbaar</span>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleViewPlacementImages(sign);
                                      }}
                                      className="ml-2 text-orange-600 hover:text-orange-800"
                                      title="Bekijk plaatsingsafbeeldingen"
                                    >
                                      <Eye size={12} />
                                    </button>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Show proof images if available */}
                            {sign.proofImages?.placed && (
                              <div className="ml-8 mt-2 p-2 bg-green-50 rounded text-xs">
                                <div className="text-green-700 flex items-center">
                                  <span>✅ <strong>Bewijs van plaatsing beschikbaar</strong></span>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleViewProofImage(sign.proofImages!.placed!, 'placed', sign.address);
                                    }}
                                    className="ml-2 text-green-600 hover:text-green-800"
                                    title="Bekijk bewijs van plaatsing"
                                  >
                                    <Eye size={12} />
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex items-center">
                            {sign.imageUrl && (
                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDownloadImage(sign.imageUrl!, sign.address);
                                  }}
                                  className="text-gray-500 hover:text-gray-700"
                                  title="Download afbeelding"
                                >
                                  <Download size={16} />
                                </button>
                                <div className="w-16 h-16 rounded-md overflow-hidden border border-gray-200">
                                  <div 
                                    style={{
                                      width: '100%',
                                      height: '100%',
                                      backgroundImage: `url(${sign.imageUrl})`,
                                      backgroundSize: 'cover',
                                      backgroundPosition: 'center',
                                    }}
                                  ></div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Proof Upload Modal */}
      {showProofModal && currentSignId && (
        <ProofUploadModal
          isOpen={showProofModal}
          onClose={() => {
            setShowProofModal(false);
            setCurrentSignId(null);
          }}
          onSubmit={handleProofSubmit}
          title="Bewijs van Ophaling"
          description="Upload een foto als bewijs dat het bord is opgehaald"
        />
      )}

      {/* Image Viewer Modal */}
      <ImageViewerModal
        isOpen={imageViewerState.isOpen}
        onClose={closeImageViewer}
        images={imageViewerState.images}
        currentIndex={imageViewerState.currentIndex}
        onIndexChange={(index) => setImageViewerState(prev => ({ ...prev, currentIndex: index }))}
        title={imageViewerState.title}
        description={imageViewerState.description}
      />
    </div>
  );
}

export default EmployeeRemoveSignsTab;