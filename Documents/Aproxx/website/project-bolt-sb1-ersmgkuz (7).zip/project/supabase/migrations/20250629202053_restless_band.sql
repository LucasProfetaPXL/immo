/*
  # Storage Configuration for Images

  Since storage policies cannot be created via migrations due to RLS restrictions,
  you need to configure the storage bucket and policies in the Supabase Dashboard.

  ## Required Storage Setup (Do this in Supabase Dashboard):

  1. Go to Storage > Buckets in your Supabase Dashboard
  2. Create a bucket named 'images' if it doesn't exist
  3. Make the bucket public
  4. Set file size limit to 10MB
  5. Set allowed MIME types to: image/jpeg, image/jpg, image/png, image/gif, image/webp

  ## Required Storage Policies (Do this in Supabase Dashboard > Storage > Policies):

  Create these policies for the 'images' bucket:

  1. INSERT Policy:
     Name: "Allow authenticated users to upload images"
     Target roles: authenticated
     WITH CHECK: bucket_id = 'images'

  2. SELECT Policy:
     Name: "Allow public read access to images"
     Target roles: public
     USING: bucket_id = 'images'

  3. DELETE Policy:
     Name: "Allow authenticated users to delete images"
     Target roles: authenticated
     USING: bucket_id = 'images'

  This migration ensures our application tables are ready for storage integration.
*/

-- Ensure our signs table has the proper image_url column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'signs' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE signs ADD COLUMN image_url text;
  END IF;
END $$;

-- Update signs table to ensure it can handle image URLs properly
ALTER TABLE signs ALTER COLUMN image_url TYPE text;

-- Add index on image_url for better performance
CREATE INDEX IF NOT EXISTS idx_signs_image_url ON signs(image_url) WHERE image_url IS NOT NULL;

-- Ensure the signs table has all necessary columns for the application
DO $$
BEGIN
  -- Add board_type column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'signs' AND column_name = 'board_type'
  ) THEN
    ALTER TABLE signs ADD COLUMN board_type text;
  END IF;

  -- Add placed_at column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'signs' AND column_name = 'placed_at'
  ) THEN
    ALTER TABLE signs ADD COLUMN placed_at timestamptz;
  END IF;

  -- Add removal_requested_at column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'signs' AND column_name = 'removal_requested_at'
  ) THEN
    ALTER TABLE signs ADD COLUMN removal_requested_at timestamptz;
  END IF;
END $$;