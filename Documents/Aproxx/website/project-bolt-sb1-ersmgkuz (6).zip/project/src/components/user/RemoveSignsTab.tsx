import React, { useState } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useSigns } from '../../context/SignsContext';
import SignMap from '../common/SignMap';
import { Check, Search, X, Download } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import toast from 'react-hot-toast';

// Belgium bounds
const belgiumBounds = [[49.5, 2.5], [51.5, 6.4]] as L.LatLngBoundsExpression;
const defaultCenter = [50.8503, 4.3517] as [number, number]; // Brussels

function RemoveSignsTab() {
  const { signs, updateSignStatus } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSigns, setSelectedSigns] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Filter signs that can be removed (status is 'placed')
  const activeSignsForRemoval = signs.filter(
    sign => sign.status === 'placed'
  );
  
  // Apply search filter
  const filteredSigns = activeSignsForRemoval.filter(sign => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  // Download image function
  const handleDownloadImage = (imageUrl: string, address: string) => {
    try {
      // Create a temporary link element
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success('Afbeelding download gestart');
    } catch (error) {
      console.error('Download error:', error);
      // Fallback: open in new tab
      window.open(imageUrl, '_blank');
      toast.success('Afbeelding geopend in nieuw tabblad');
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedSigns(prev => {
      if (prev.includes(id)) {
        return prev.filter(signId => signId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedSigns.length === filteredSigns.length) {
      // Deselect all
      setSelectedSigns([]);
    } else {
      // Select all
      setSelectedSigns(filteredSigns.map(sign => sign.id));
    }
  };

  const handleRequestRemoval = () => {
    if (selectedSigns.length === 0) {
      toast.error('Selecteer ten minste één bord om te verwijderen');
      return;
    }
    
    setIsSubmitting(true);
    
    // Update status for each selected sign
    setTimeout(() => {
      selectedSigns.forEach(id => {
        updateSignStatus(id, 'removal-requested');
      });
      
      setSelectedSigns([]);
      setIsSubmitting(false);
      toast.success('Verwijderingsverzoek succesvol ingediend!');
    }, 800);
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Borden Verwijderen</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Map Section */}
        <div className="rounded-lg overflow-hidden border border-gray-200 h-[500px]">
          <MapContainer 
            center={defaultCenter} 
            zoom={8} 
            style={{ height: '100%', width: '100%' }}
            zoomControl={true}
            scrollWheelZoom={true}
            maxBounds={belgiumBounds}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            <SignMap 
              signs={signs.filter(sign => sign.status !== 'trashed' && sign.status !== 'deleted')} 
              showPreview={true}
            />
          </MapContainer>
        </div>
        
        {/* Signs List Section */}
        <div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Actieve Borden</h3>
              
              <div className="flex items-center">
                <div className="relative mr-2">
                  <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Zoek borden..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      <X size={14} />
                    </button>
                  )}
                </div>
                
                <button
                  onClick={handleSelectAll}
                  className="text-sm text-primary-blue hover:text-blue-700"
                >
                  {selectedSigns.length === filteredSigns.length && filteredSigns.length > 0 
                    ? 'Deselecteer Alles' 
                    : 'Selecteer Alles'}
                </button>
              </div>
            </div>
            
            {filteredSigns.length === 0 ? (
              <div className="text-center py-10 text-gray-500">
                <p>Geen actieve borden beschikbaar voor verwijdering</p>
              </div>
            ) : (
              <div className="fixed-height-container">
                <div className="space-y-2 p-2">
                  {filteredSigns.map(sign => (
                    <div 
                      key={sign.id}
                      className={`p-3 rounded-md border transition-colors ${
                        selectedSigns.includes(sign.id)
                          ? 'border-primary-blue bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => handleToggleSelect(sign.id)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-sm">{sign.companyName}</p>
                          <p className="text-xs text-gray-600 mt-1">{sign.address}</p>
                          <div className="flex items-center mt-2">
                            <span className="status-badge status-placed">Actief</span>
                            <span className="text-xs text-gray-500 ml-2">
                              Sinds {formatDateInDutch(new Date(sign.placedAt || sign.createdAt))}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          {sign.imageUrl && (
                            <div className="flex items-center space-x-2 mr-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDownloadImage(sign.imageUrl!, sign.address);
                                }}
                                className="text-gray-500 hover:text-gray-700"
                                title="Download afbeelding"
                              >
                                <Download size={14} />
                              </button>
                              <div className="w-12 h-12 rounded overflow-hidden border border-gray-200">
                                <div 
                                  style={{
                                    width: '100%',
                                    height: '100%',
                                    backgroundImage: `url(${sign.imageUrl})`,
                                    backgroundSize: 'cover',
                                    backgroundPosition: 'center',
                                  }}
                                ></div>
                              </div>
                            </div>
                          )}
                          <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                            selectedSigns.includes(sign.id)
                              ? 'bg-primary-blue border-primary-blue'
                              : 'border-gray-300'
                          }`}>
                            {selectedSigns.includes(sign.id) && (
                              <Check size={12} className="text-white" />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="mt-4">
              <button
                onClick={handleRequestRemoval}
                disabled={selectedSigns.length === 0 || isSubmitting}
                className={`btn w-full ${
                  selectedSigns.length === 0
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'btn-warning'
                } ${isSubmitting ? 'opacity-75 cursor-wait' : ''}`}
              >
                {isSubmitting 
                  ? 'Verwerken...' 
                  : `Verwijdering Aanvragen (${selectedSigns.length})`}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* All Signs Overview */}
      {signs.length > 0 && (
        <div className="mt-8 bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Alle Borden Overzicht</h3>
          <div className="space-y-3 max-h-[300px] overflow-y-auto">
            {signs.map(sign => (
              <div key={sign.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex items-center space-x-3">
                  {sign.imageUrl && (
                    <div className="flex items-center space-x-2">
                      <div className="w-12 h-12 rounded overflow-hidden border border-gray-200">
                        <div 
                          style={{
                            width: '100%',
                            height: '100%',
                            backgroundImage: `url(${sign.imageUrl})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                          }}
                        ></div>
                      </div>
                      <button
                        onClick={() => handleDownloadImage(sign.imageUrl!, sign.address)}
                        className="text-gray-500 hover:text-gray-700"
                        title="Download afbeelding"
                      >
                        <Download size={14} />
                      </button>
                    </div>
                  )}
                  <div>
                    <p className="font-medium text-sm">{sign.address}</p>
                    <div className="flex items-center mt-1">
                      <span className={`status-badge status-${sign.status}`}>
                        {sign.status === 'pending' ? 'In afwachting' : 
                         sign.status === 'confirmed' ? 'Bevestigd' : 
                         sign.status === 'placed' ? 'Geplaatst' : 
                         sign.status === 'removal-requested' ? 'Verwijdering aangevraagd' : 
                         sign.status === 'removal-confirmed' ? 'Verwijderd' :
                         sign.status === 'removed' ? 'Verwijderd' : sign.status.replace('-', ' ')}
                      </span>
                      <span className="text-xs text-gray-500 ml-2">
                        Bijgewerkt {formatDateInDutch(new Date(sign.updatedAt))}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default RemoveSignsTab;