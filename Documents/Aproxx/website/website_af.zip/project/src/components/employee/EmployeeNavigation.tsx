import React from 'react';
import { MapPin, Trash2, TrendingUp } from 'lucide-react';

type EmployeeTabType = 'place-signs' | 'remove-signs' | 'sold-signs';

interface EmployeeNavigationProps {
  activeTab: EmployeeTabType;
  onTabChange: (tab: EmployeeTabType) => void;
}

function EmployeeNavigation({ activeTab, onTabChange }: EmployeeNavigationProps) {
  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800">Werknemer Panel</h2>
      </div>
      
      <nav className="p-4 space-y-2">
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'place-signs' ? 'active' : ''}`}
          onClick={() => onTabChange('place-signs')}
        >
          <MapPin size={18} className="mr-3" />
          <span>Borden Plaatsen</span>
        </button>
        
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'remove-signs' ? 'active' : ''}`}
          onClick={() => onTabChange('remove-signs')}
        >
          <Trash2 size={18} className="mr-3" />
          <span>Borden Verwijderen</span>
        </button>
        
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'sold-signs' ? 'active' : ''}`}
          onClick={() => onTabChange('sold-signs')}
        >
          <TrendingUp size={18} className="mr-3" />
          <span>Verkocht Bordjes</span>
        </button>
      </nav>
    </div>
  );
}

export default EmployeeNavigation;