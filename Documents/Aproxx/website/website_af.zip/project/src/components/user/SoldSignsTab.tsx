import React, { useState } from 'react';
import { useSigns } from '../../context/SignsContext';
import { Search, Check, X, TrendingUp } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { formatAddress } from '../../utils/addressFormatter.tsx';
import toast from 'react-hot-toast';

function SoldSignsTab() {
  const { signs, updateSoldStatus } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSigns, setSelectedSigns] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Filter signs that can be marked as sold (status is 'placed' and not already sold)
  const eligibleSigns = signs.filter(
    sign => sign.status === 'placed' && (!sign.soldStatus || sign.soldStatus === 'none')
  );
  
  // Apply search filter
  const filteredSigns = eligibleSigns.filter(sign => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  const handleToggleSelect = (id: string) => {
    setSelectedSigns(prev => {
      if (prev.includes(id)) {
        return prev.filter(signId => signId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedSigns.length === filteredSigns.length) {
      // Deselect all
      setSelectedSigns([]);
    } else {
      // Select all
      setSelectedSigns(filteredSigns.map(sign => sign.id));
    }
  };

  const handleMarkAsSold = () => {
    if (selectedSigns.length === 0) {
      toast.error('Selecteer ten minste één bord om als verkocht te markeren');
      return;
    }
    
    setIsSubmitting(true);
    
    // Update sold status for each selected sign
    setTimeout(() => {
      selectedSigns.forEach(id => {
        updateSoldStatus(id, 'requested');
      });
      
      setSelectedSigns([]);
      setIsSubmitting(false);
      toast.success('Verkocht aanvraag succesvol ingediend! Admin zal de aanvraag beoordelen.');
    }, 800);
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Verkochte Borden</h2>
      
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-lg font-semibold">Borden Markeren als Verkocht</h3>
            <p className="text-sm text-gray-500">
              Selecteer borden waarvan het pand verkocht is om een verkocht bordje aan te vragen
            </p>
          </div>
          
          <div className="flex items-center">
            <div className="relative mr-2">
              <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Zoek borden..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <X size={14} />
                </button>
              )}
            </div>
            
            <button
              onClick={handleSelectAll}
              className="text-sm text-primary-blue hover:text-blue-700"
            >
              {selectedSigns.length === filteredSigns.length && filteredSigns.length > 0 
                ? 'Deselecteer Alles' 
                : 'Selecteer Alles'}
            </button>
          </div>
        </div>
        
        {filteredSigns.length === 0 ? (
          <div className="text-center py-10 text-gray-500">
            <TrendingUp size={48} className="mx-auto text-gray-300 mb-4" />
            <p>Geen actieve borden beschikbaar om als verkocht te markeren</p>
            <p className="text-sm mt-2">Alleen geplaatste borden kunnen als verkocht worden gemarkeerd</p>
          </div>
        ) : (
          <>
            <div className="fixed-height-container">
              <div className="space-y-2 p-2">
                {filteredSigns.map(sign => (
                  <div 
                    key={sign.id}
                    className={`p-3 rounded-md border transition-colors ${
                      selectedSigns.includes(sign.id)
                        ? 'border-primary-blue bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => handleToggleSelect(sign.id)}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center">
                          <div className={`w-5 h-5 rounded-full border flex items-center justify-center mr-3 ${
                            selectedSigns.includes(sign.id)
                              ? 'bg-primary-blue border-primary-blue'
                              : 'border-gray-300'
                          }`}>
                            {selectedSigns.includes(sign.id) && (
                              <Check size={12} className="text-white" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium text-sm">{sign.companyName}</p>
                            <p className="text-xs text-gray-600 mt-1">{formatAddress(sign.address)}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center mt-2 ml-8">
                          <span className="status-badge status-placed">Actief</span>
                          <span className="text-xs text-gray-500 ml-2">
                            Sinds {formatDateInDutch(new Date(sign.placedAt || sign.createdAt))}
                          </span>
                        </div>
                      </div>
                      
                      {sign.imageUrl && (
                        <div className="w-12 h-12 rounded overflow-hidden border border-gray-200 ml-3">
                          <div 
                            style={{
                              width: '100%',
                              height: '100%',
                              backgroundImage: `url(${sign.imageUrl})`,
                              backgroundSize: 'cover',
                              backgroundPosition: 'center',
                            }}
                          ></div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-200">
              <button
                onClick={handleMarkAsSold}
                disabled={selectedSigns.length === 0 || isSubmitting}
                className={`btn w-full ${
                  selectedSigns.length === 0
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'btn-success'
                } ${isSubmitting ? 'opacity-75 cursor-wait' : ''} flex items-center justify-center`}
              >
                <TrendingUp size={16} className="mr-2" />
                {isSubmitting 
                  ? 'Verwerken...' 
                  : `Markeer als Verkocht (${selectedSigns.length})`}
              </button>
              
              <p className="text-xs text-gray-500 mt-2 text-center">
                Na markering wordt een verkocht bordje aangevraagd bij de admin
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default SoldSignsTab;