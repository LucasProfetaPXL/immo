import React, { useState, useRef } from 'react';
import { X, Camera, Upload, Image as ImageIcon } from 'lucide-react';
import { uploadImage } from '../../lib/supabase';
import { downloadImage } from '../../utils/imageUtils';
import toast from 'react-hot-toast';

interface ProofUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (imageUrl: string) => void;
  title: string;
  description: string;
}

function ProofUploadModal({ isOpen, onClose, onSubmit, title, description }: ProofUploadModalProps) {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  if (!isOpen) return null;

  // Function to start the camera
  const startCamera = async () => {
    try {
      // Check if the browser supports getUserMedia
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toast.error('Je browser ondersteunt geen camera toegang');
        // Fall back to file input
        cameraInputRef.current?.click();
        return;
      }

      // Request camera access with environment camera preferred (rear camera on mobile)
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      
      // Store the stream reference for later cleanup
      streamRef.current = stream;
      
      // Set camera as active
      setIsCameraActive(true);
      
      // Set the video source to the camera stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      toast.error('Kon geen toegang krijgen tot de camera');
      // Fall back to file input
      cameraInputRef.current?.click();
    }
  };

  // Function to stop the camera
  const stopCamera = () => {
    if (streamRef.current) {
      // Stop all tracks in the stream
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    // Reset video element
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    setIsCameraActive(false);
  };

  // Function to capture a photo from the camera
  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw the current video frame to the canvas
    const context = canvas.getContext('2d');
    if (context) {
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Convert canvas to blob
      canvas.toBlob((blob) => {
        if (blob) {
          // Create a File object from the blob
          const file = new File([blob], `camera_capture_${Date.now()}.png`, { type: 'image/png' });
          
          // Use the same handler as file upload
          handleImageSelect(file);
          
          // Stop the camera after taking the photo
          stopCamera();
        }
      }, 'image/png');
    }
  };

  const handleImageSelect = (file: File) => {
    // Validate file type
    if (!file.type.match('image/jpeg') && !file.type.match('image/png')) {
      toast.error('Alleen JPG of PNG afbeeldingen zijn toegestaan');
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('Afbeelding mag maximaal 10MB zijn');
      return;
    }

    setSelectedImage(file);

    // Create preview
    const reader = new FileReader();
    reader.onload = (event) => {
      setImagePreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleImageSelect(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    if (!selectedImage) {
      toast.error('Selecteer eerst een afbeelding');
      return;
    }

    setIsSubmitting(true);

    try {
      console.log('Uploading proof image...');
      const imageUrl = await uploadImage(selectedImage, 'proof');
      console.log('Image uploaded successfully:', imageUrl);
      
      // Call the onSubmit callback with the uploaded image URL or key
      onSubmit(imageUrl);
      
      // Reset form
      setSelectedImage(null);
      setImagePreview(null);
      if (isCameraActive) {
        stopCamera();
      }
      
      toast.success('Afbeelding succesvol geüpload');
    } catch (error) {
      console.error('Error uploading image:', error);
      toast.error('Fout bij uploaden van afbeelding');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setSelectedImage(null);
    setImagePreview(null);
    onClose();
    // Make sure to stop the camera if it's active
    stopCamera();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={handleClose} className="text-gray-500 hover: text-gray-700">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6">
          <p className="text-gray-600 mb-6">{description}</p>
          
          {/* Image Preview */}
          {imagePreview ? (
            <div className="mb-6">
              <div className="relative w-full h-48 rounded-lg overflow-hidden border border-gray-200">
                <img 
                  src={imagePreview} 
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => {
                    setSelectedImage(null);
                    setImagePreview(null);
                  }}
                  className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          ) : (
            <div className="mb-6">
              <div className="w-full h-48 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <ImageIcon size={48} className="mx-auto text-gray-400 mb-2" />
                  <p className="text-gray-500">Geen afbeelding geselecteerd</p>
                </div>
              </div>
            </div>
          )}
          
          {/* Upload Options */}
          <div className="space-y-3 mb-6">
            <button
              onClick={startCamera}
              className="w-full btn btn-primary flex items-center justify-center"
              disabled={isSubmitting}
            >
              <Camera size={20} className="mr-2" />
              <span>Foto Maken</span>
            </button>
            
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full btn btn-secondary flex items-center justify-center"
              disabled={isSubmitting}
            >
              <Upload size={20} className="mr-2" />
              <span>Bestand Uploaden</span>
            </button>
          </div>
          
          {/* Hidden file inputs */}
          {/* Camera input as fallback if direct camera access fails */}
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFileUpload}
            className="hidden"
          />
          
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png"
            onChange={handleFileUpload}
            className="hidden"
          />

          {/* Camera UI */}
          {isCameraActive && (
            <div className="fixed inset-0 z-50 bg-black flex flex-col">
              <div className="flex justify-between items-center p-4 bg-black bg-opacity-75">
                <button 
                  onClick={stopCamera}
                  className="p-2 bg-red-500 rounded-full"
                >
                  <X size={24} color="white" />
                </button>
                <h3 className="text-white font-medium">Maak een foto</h3>
                <div className="w-10"></div> {/* Spacer for alignment */}
              </div>
              
              <div className="flex-1 relative">
                <video 
                  ref={videoRef}
                  className="absolute inset-0 w-full h-full object-cover"
                  autoPlay
                  playsInline
                ></video>
                
                <canvas ref={canvasRef} className="hidden"></canvas>
              </div>
              
              <div className="p-4 flex justify-center bg-black bg-opacity-75">
                <button 
                  onClick={capturePhoto}
                  className="w-16 h-16 rounded-full bg-white border-4 border-gray-300 flex items-center justify-center"
                  title="Foto maken"
                >
                  <div className="w-12 h-12 rounded-full bg-white"></div>
                </button>
              </div>
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex justify-end space-x-3">
            <button 
              onClick={handleClose}
              className="btn btn-secondary"
              disabled={isSubmitting}
            >
              Annuleren
            </button>
            <button 
              onClick={handleSubmit}
              disabled={!selectedImage || isSubmitting}
              className={`btn btn-primary ${
                !selectedImage || isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? 'Uploaden...' : 'Bevestigen'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProofUploadModal;