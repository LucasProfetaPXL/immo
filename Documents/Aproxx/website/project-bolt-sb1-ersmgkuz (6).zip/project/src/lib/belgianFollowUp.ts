import { addDays, differenceInDays, isAfter } from 'date-fns';
import type { Invoice, ReminderEmail, InterestCalculation, ForfaitaryCompensation } from '../types';

// Belgian law constants (effective December 1, 2023)
export const BELGIAN_FOLLOW_UP_CONFIG = {
  PAYMENT_TERM_DAYS: 30,
  FREE_REMINDER_REQUIRED: true,
  WAITING_PERIOD_DAYS: 14,
  ANNUAL_INTEREST_RATE: 0.125, // 12.5% per year
  COMPANY_NAME: 'Aproxx',
  COMPANY_NUMBER: 'BE1007197223',
  COMPANY_EMAIL: 'info@aproxx.com',
  COMPANY_PHONE: '+32 11 XX XX XX'
};

/**
 * Calculate forfaitary compensation according to Belgian law
 */
export const calculateForfaitaryCompensation = (invoiceAmount: number): ForfaitaryCompensation => {
  let compensationAmount = 0;
  let tier: 'tier1' | 'tier2' | 'tier3';

  if (invoiceAmount <= 150) {
    // Tier 1: Up to €150 → max €20
    compensationAmount = Math.min(20, invoiceAmount * 0.1); // 10% with max €20
    tier = 'tier1';
  } else if (invoiceAmount <= 500) {
    // Tier 2: €150.01 to €500 → €30 + 10% on amount above €150
    const excessAmount = invoiceAmount - 150;
    compensationAmount = 30 + (excessAmount * 0.1);
    tier = 'tier2';
  } else {
    // Tier 3: Above €500 → €65 + 5% on amount above €500, max €2000
    const excessAmount = invoiceAmount - 500;
    compensationAmount = Math.min(2000, 65 + (excessAmount * 0.05));
    tier = 'tier3';
  }

  return {
    invoiceAmount,
    compensationAmount: Math.round(compensationAmount * 100) / 100, // Round to 2 decimals
    tier
  };
};

/**
 * Calculate interest for late payment (12.5% per year)
 */
export const calculateInterest = (principal: number, daysLate: number): InterestCalculation => {
  const rate = BELGIAN_FOLLOW_UP_CONFIG.ANNUAL_INTEREST_RATE;
  const interestAmount = (principal * rate * daysLate) / 365;
  
  return {
    principal,
    rate,
    daysLate,
    interestAmount: Math.round(interestAmount * 100) / 100 // Round to 2 decimals
  };
};

/**
 * Check if invoice needs first reminder (after 30 days)
 */
export const needsFirstReminder = (invoice: Invoice): boolean => {
  if (invoice.status === 'paid' || invoice.firstReminderSent) {
    return false;
  }

  const createdDate = new Date(invoice.createdAt);
  const reminderDate = addDays(createdDate, BELGIAN_FOLLOW_UP_CONFIG.PAYMENT_TERM_DAYS);
  
  return isAfter(new Date(), reminderDate);
};

/**
 * Check if waiting period has ended (14 days after first reminder)
 */
export const isWaitingPeriodEnded = (invoice: Invoice): boolean => {
  if (!invoice.firstReminderSent || invoice.status === 'paid') {
    return false;
  }

  const reminderDate = new Date(invoice.firstReminderSent);
  const waitingPeriodEnd = addDays(reminderDate, BELGIAN_FOLLOW_UP_CONFIG.WAITING_PERIOD_DAYS);
  
  return isAfter(new Date(), waitingPeriodEnd);
};

/**
 * Calculate total amount due including interest and compensation
 */
export const calculateTotalAmountDue = (invoice: Invoice): number => {
  let totalAmount = invoice.amount;

  // Only add costs if waiting period has ended
  if (isWaitingPeriodEnded(invoice)) {
    // Add forfaitary compensation
    const compensation = calculateForfaitaryCompensation(invoice.amount);
    totalAmount += compensation.compensationAmount;

    // Add interest if applicable
    if (invoice.firstReminderSent) {
      const reminderDate = new Date(invoice.firstReminderSent);
      const waitingPeriodEnd = addDays(reminderDate, BELGIAN_FOLLOW_UP_CONFIG.WAITING_PERIOD_DAYS);
      const daysLate = differenceInDays(new Date(), waitingPeriodEnd);
      
      if (daysLate > 0) {
        const interest = calculateInterest(invoice.amount, daysLate);
        totalAmount += interest.interestAmount;
      }
    }
  }

  return Math.round(totalAmount * 100) / 100; // Round to 2 decimals
};

/**
 * Generate first reminder email content
 */
export const generateFirstReminderEmail = (invoice: Invoice): ReminderEmail => {
  const dueDate = new Date(invoice.dueDate).toLocaleDateString('nl-BE');
  const compensation = calculateForfaitaryCompensation(invoice.amount);
  
  const subject = `Betalingsherinnering - Factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`;
  
  const body = `
Geachte ${invoice.billingDetails.name},

Wij stellen vast dat onderstaande factuur nog niet werd betaald:

FACTUURGEGEVENS:
- Factuurnummer: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}
- Factuurdatum: ${new Date(invoice.createdAt).toLocaleDateString('nl-BE')}
- Vervaldatum: ${dueDate}
- Te betalen bedrag: €${invoice.amount.toFixed(2)}

DIENSTVERLENING:
${invoice.signId === 'combined' ? 
  `Plaatsing van ${invoice.signDetails?.length || 1} lichtborden` : 
  `Plaatsing lichtbord op ${invoice.address}`
}

SCHULDEISER:
${BELGIAN_FOLLOW_UP_CONFIG.COMPANY_NAME}
Ondernemingsnummer: ${BELGIAN_FOLLOW_UP_CONFIG.COMPANY_NUMBER}

CONTRACTUELE SCHADEVERGOEDING:
Bij laattijdige betaling is een forfaitaire schadevergoeding van €${compensation.compensationAmount.toFixed(2)} verschuldigd conform onze algemene voorwaarden.

WETTELIJKE WACHTTIJD:
Conform de Belgische wetgeving vanaf 1 december 2023 heeft u nog 14 kalenderdagen vanaf de verzending van deze herinnering om te betalen zonder bijkomende kosten.

Na deze wachttijd kunnen verwijlintresten van 12,5% per jaar worden aangerekend.

BETALINGSGEGEVENS:
IBAN: BE66 3632 4232 5743
BIC: BBRUBEBB
Referentie: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}

Voor vragen kunt u contact opnemen via ${BELGIAN_FOLLOW_UP_CONFIG.COMPANY_EMAIL}.

Met vriendelijke groeten,
${BELGIAN_FOLLOW_UP_CONFIG.COMPANY_NAME}
  `.trim();

  return {
    to: invoice.billingDetails.email,
    subject,
    body,
    invoiceId: invoice.id,
    reminderType: 'first'
  };
};

/**
 * Generate second reminder email content (after waiting period)
 */
export const generateSecondReminderEmail = (invoice: Invoice): ReminderEmail => {
  const totalAmountDue = calculateTotalAmountDue(invoice);
  const compensation = calculateForfaitaryCompensation(invoice.amount);
  
  let interestAmount = 0;
  if (invoice.firstReminderSent) {
    const reminderDate = new Date(invoice.firstReminderSent);
    const waitingPeriodEnd = addDays(reminderDate, BELGIAN_FOLLOW_UP_CONFIG.WAITING_PERIOD_DAYS);
    const daysLate = differenceInDays(new Date(), waitingPeriodEnd);
    
    if (daysLate > 0) {
      const interest = calculateInterest(invoice.amount, daysLate);
      interestAmount = interest.interestAmount;
    }
  }
  
  const subject = `TWEEDE HERINNERING - Factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`;
  
  const body = `
Geachte ${invoice.billingDetails.name},

Ondanks onze eerste herinnering is onderstaande factuur nog steeds niet betaald:

FACTUURGEGEVENS:
- Factuurnummer: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}
- Oorspronkelijk bedrag: €${invoice.amount.toFixed(2)}
- Forfaitaire schadevergoeding: €${compensation.compensationAmount.toFixed(2)}
${interestAmount > 0 ? `- Verwijlintresten (12,5%/jaar): €${interestAmount.toFixed(2)}` : ''}
- TOTAAL TE BETALEN: €${totalAmountDue.toFixed(2)}

De wettelijke wachttijd van 14 dagen is verstreken. Conform de Belgische wetgeving zijn nu bijkomende kosten van toepassing.

BETALINGSGEGEVENS:
IBAN: BE66 3632 4232 5743
BIC: BBRUBEBB
Referentie: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}

Gelieve dit bedrag binnen 7 dagen te betalen om verdere juridische stappen te vermijden.

Met vriendelijke groeten,
${BELGIAN_FOLLOW_UP_CONFIG.COMPANY_NAME}
  `.trim();

  return {
    to: invoice.billingDetails.email,
    subject,
    body,
    invoiceId: invoice.id,
    reminderType: 'second'
  };
};

/**
 * Generate final reminder email content
 */
export const generateFinalReminderEmail = (invoice: Invoice): ReminderEmail => {
  const totalAmountDue = calculateTotalAmountDue(invoice);
  
  const subject = `LAATSTE HERINNERING - Factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`;
  
  const body = `
Geachte ${invoice.billingDetails.name},

Dit is onze laatste herinnering voor factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}.

TOTAAL TE BETALEN: €${totalAmountDue.toFixed(2)}

Indien dit bedrag niet binnen 5 werkdagen wordt betaald, zullen wij genoodzaakt zijn juridische stappen te ondernemen.

BETALINGSGEGEVENS:
IBAN: BE66 3632 4232 5743
BIC: BBRUBEBB
Referentie: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}

Voor vragen: ${BELGIAN_FOLLOW_UP_CONFIG.COMPANY_EMAIL}

Met vriendelijke groeten,
${BELGIAN_FOLLOW_UP_CONFIG.COMPANY_NAME}
  `.trim();

  return {
    to: invoice.billingDetails.email,
    subject,
    body,
    invoiceId: invoice.id,
    reminderType: 'final'
  };
};

/**
 * Process invoice for Belgian follow-up system
 */
export const processInvoiceFollowUp = (invoice: Invoice): {
  needsAction: boolean;
  actionType?: 'first_reminder' | 'apply_costs' | 'second_reminder' | 'final_reminder';
  reminderEmail?: ReminderEmail;
  updatedInvoice?: Partial<Invoice>;
} => {
  // Skip if already paid
  if (invoice.status === 'paid') {
    return { needsAction: false };
  }

  const now = new Date();
  const createdDate = new Date(invoice.createdAt);
  const daysOverdue = differenceInDays(now, addDays(createdDate, BELGIAN_FOLLOW_UP_CONFIG.PAYMENT_TERM_DAYS));

  // Check if first reminder is needed (after 30 days)
  if (needsFirstReminder(invoice)) {
    const reminderEmail = generateFirstReminderEmail(invoice);
    const updatedInvoice: Partial<Invoice> = {
      reminderStatus: 'first',
      firstReminderSent: now.toISOString(),
      waitingPeriodEnd: addDays(now, BELGIAN_FOLLOW_UP_CONFIG.WAITING_PERIOD_DAYS).toISOString(),
      lastReminderSent: now.toISOString()
    };

    return {
      needsAction: true,
      actionType: 'first_reminder',
      reminderEmail,
      updatedInvoice
    };
  }

  // Check if waiting period has ended and costs should be applied
  if (isWaitingPeriodEnded(invoice) && invoice.reminderStatus === 'first') {
    const compensation = calculateForfaitaryCompensation(invoice.amount);
    const totalAmountDue = calculateTotalAmountDue(invoice);
    
    const updatedInvoice: Partial<Invoice> = {
      reminderStatus: 'second',
      forfaitaryCompensation: compensation.compensationAmount,
      totalAmountDue,
      interestStartDate: invoice.waitingPeriodEnd
    };

    const reminderEmail = generateSecondReminderEmail({
      ...invoice,
      ...updatedInvoice
    } as Invoice);

    return {
      needsAction: true,
      actionType: 'second_reminder',
      reminderEmail,
      updatedInvoice
    };
  }

  // Check if final reminder is needed (after 21 days from second reminder)
  if (invoice.reminderStatus === 'second' && daysOverdue > 51) { // 30 + 14 + 7 days
    const reminderEmail = generateFinalReminderEmail(invoice);
    const updatedInvoice: Partial<Invoice> = {
      reminderStatus: 'final',
      lastReminderSent: now.toISOString()
    };

    return {
      needsAction: true,
      actionType: 'final_reminder',
      reminderEmail,
      updatedInvoice
    };
  }

  // Update interest calculation if in interest period
  if (invoice.interestStartDate && invoice.reminderStatus !== 'none') {
    const interestStartDate = new Date(invoice.interestStartDate);
    const daysLate = differenceInDays(now, interestStartDate);
    
    if (daysLate > 0) {
      const interest = calculateInterest(invoice.amount, daysLate);
      const compensation = calculateForfaitaryCompensation(invoice.amount);
      const totalAmountDue = invoice.amount + compensation.compensationAmount + interest.interestAmount;
      
      const updatedInvoice: Partial<Invoice> = {
        totalInterest: interest.interestAmount,
        totalAmountDue: Math.round(totalAmountDue * 100) / 100
      };

      return {
        needsAction: true,
        actionType: 'apply_costs',
        updatedInvoice
      };
    }
  }

  return { needsAction: false };
};