import React from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useSigns } from '../../context/SignsContext';
import SignMap from '../common/SignMap';
import { MapPin, Package, TrendingUp, Clock } from 'lucide-react';
import { getUserAvailableBoards, calculateBoardsInUse, getUserExclusiveAllocation, getSharedPoolSize } from '../../utils/inventoryManager';

// Belgium bounds
const belgiumBounds = [[49.5, 2.5], [51.5, 6.4]] as L.LatLngBoundsExpression;
const defaultCenter = [50.8503, 4.3517] as [number, number]; // Brussels

function UserDashboardTab() {
  const { signs, getAllSignsIncludingHidden } = useSigns();
  
  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();
  
  // Calculate statistics
  const allUserSigns = getAllSignsIncludingHidden();
  const activeSigns = allUserSigns.filter(sign => sign.status === 'placed');
  const pendingSigns = allUserSigns.filter(sign => sign.status === 'pending' || sign.status === 'confirmed');
  const soldSigns = allUserSigns.filter(sign => sign.soldStatus === 'placed');
  
  // Inventory calculations
  const availableBoards = currentUser ? getUserAvailableBoards(currentUser.id) : 0;
  const boardsInUse = currentUser ? (calculateBoardsInUse(allUserSigns)[currentUser.id] || 0) : 0;
  const remainingBoards = availableBoards - boardsInUse;
  const hasExclusiveAccess = currentUser ? getUserExclusiveAllocation(currentUser.id) > 0 : false;

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Dashboard</h2>
      
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100">
              <MapPin size={24} className="text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Actieve Borden</p>
              <p className="text-2xl font-bold text-gray-900">{activeSigns.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-blue-100">
              <Clock size={24} className="text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">In Behandeling</p>
              <p className="text-2xl font-bold text-gray-900">{pendingSigns.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100">
              <TrendingUp size={24} className="text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Verkocht</p>
              <p className="text-2xl font-bold text-gray-900">{soldSigns.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-orange-100">
              <Package size={24} className="text-orange-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Beschikbare Borden</p>
              <p className="text-2xl font-bold text-gray-900">{remainingBoards}</p>
              <p className="text-xs text-gray-500">
                {boardsInUse} van {availableBoards} in gebruik
                {hasExclusiveAccess ? ' (exclusief)' : ' (gedeelde pool)'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Central Map */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold">Overzichtskaart</h3>
          <p className="text-sm text-gray-500">Alle uw borden op één kaart</p>
        </div>
        
        <div className="p-4">
          <div className="h-[500px] w-full rounded-lg overflow-hidden border border-gray-200">
            <MapContainer 
              center={defaultCenter} 
              zoom={8} 
              style={{ height: '100%', width: '100%', display: 'block' }}
              zoomControl={true}
              scrollWheelZoom={true}
              maxBounds={belgiumBounds}
            >
              <TileLayer
                url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              <SignMap signs={signs} showPreview={true} />
            </MapContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserDashboardTab;