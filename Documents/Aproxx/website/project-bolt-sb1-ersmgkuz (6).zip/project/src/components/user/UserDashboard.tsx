import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import UserNavigation from './UserNavigation';
import PlaceOrderTab from './PlaceOrderTab';
import RemoveSignsTab from './RemoveSignsTab';
import CostsTab from './CostsTab';
import { LogOut } from 'lucide-react';

type UserTabType = 'place-order' | 'remove-signs' | 'costs';

function UserDashboard() {
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState<UserTabType>('place-order');

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'place-order':
        return <PlaceOrderTab />;
      case 'remove-signs':
        return <RemoveSignsTab />;
      case 'costs':
        return <CostsTab />;
      default:
        return <PlaceOrderTab />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-gray-900">Bordbeheer Systeem</h1>
            {currentUser && currentUser.companyName && (
              <>
                <span className="mx-3 text-gray-400">•</span>
                <span className="text-lg font-medium text-primary-blue">{currentUser.companyName}</span>
              </>
            )}
          </div>
          <button
            onClick={logout}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <LogOut size={16} className="mr-1" />
            <span>Uitloggen</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <UserNavigation activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-4 bg-white rounded-lg shadow">
          {renderActiveTab()}
        </div>
      </main>
    </div>
  );
}

export default UserDashboard;