import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';
import type { Invoice, SignData } from '../types';

const addLogoToDoc = async (doc: jsPDF) => {
  try {
    // Load the logo image
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    return new Promise<void>((resolve, reject) => {
      img.onload = () => {
        try {
          // Create canvas to convert image to base64
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          if (!ctx) {
            reject(new Error('Could not get canvas context'));
            return;
          }
          
          // Set canvas size to match image
          canvas.width = img.width;
          canvas.height = img.height;
          
          // Draw image on canvas
          ctx.drawImage(img, 0, 0);
          
          // Get base64 data
          const dataURL = canvas.toDataURL('image/png');
          
          // Add logo to PDF (positioned at top left) - LARGER SIZE
          // Logo dimensions: approximately 80mm wide, maintaining aspect ratio
          const logoWidth = 100;
          const logoHeight = (img.height / img.width) * logoWidth;
          
          doc.addImage(dataURL, 'PNG', 4, -22, logoWidth, logoHeight);
          
          resolve();
        } catch (error) {
          console.error('Error processing logo:', error);
          // Fallback to text
          addTextLogo(doc);
          resolve();
        }
      };
      
      img.onerror = () => {
        console.error('Error loading logo image');
        // Fallback to text
        addTextLogo(doc);
        resolve();
      };
      
      // Load the logo from public folder
      img.src = '/1.png';
    });
  } catch (error) {
    console.error('Error adding logo:', error);
    // Fallback to text
    addTextLogo(doc);
  }
};

const addTextLogo = (doc: jsPDF) => {
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('AproXX', 15, 25);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('Real estate light signs', 15, 30);
};

export const generateInvoicePDF = async (invoice: Invoice) => {
  const doc = new jsPDF();
  
  // Add logo
  await addLogoToDoc(doc);
  
  // Reset text color
  doc.setTextColor(0, 0, 0);

  // Add company information in top right
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Aproxx', 150, 20);
  doc.text('De Slogen 47', 150, 25);
  doc.text('3550 Heusden-Zolder', 150, 30);
  doc.text('België', 150, 35);
  doc.text('BTW: BE1007197223', 150, 40);
  doc.text('M: info@aproxx.com', 150, 45);

  // Add invoice header - MOVED TO ALIGN WITH BILLING DETAILS
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('FACTUUR', 150, 95);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Factuurnummer: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`, 150, 105);
  doc.text(`Datum: ${format(new Date(invoice.createdAt), 'dd/MM/yyyy')}`, 150, 110);
  doc.text(`Vervaldatum: ${format(new Date(invoice.dueDate), 'dd/MM/yyyy')}`, 150, 115);

  // Add billing details - SAME Y POSITION AS INVOICE HEADER
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Factureren aan:', 15, 95);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.billingDetails.name, 15, 105);
  doc.text(invoice.billingDetails.address, 15, 110);
  doc.text(`${invoice.billingDetails.postalCode} ${invoice.billingDetails.city}`, 15, 115);
  doc.text(invoice.billingDetails.country, 15, 120);
  doc.text(`BTW: ${invoice.billingDetails.vatNumber}`, 15, 125);

  // Get pricing used for this invoice (fallback to defaults if not available)
  const baseCost = invoice.pricingUsed?.baseCost || 220;
  const dailyCost = invoice.pricingUsed?.dailyCost || 4;

  // Add sign details
  const daysOver30 = Math.max(0, invoice.days - 30);
  const extraDaysCost = daysOver30 * dailyCost;
  const totalExcl = baseCost + extraDaysCost;
  const vat = totalExcl * 0.21;
  const totalIncl = totalExcl + vat;

  autoTable(doc, {
    startY: 145,
    margin: { left: 15, right: 15 }, // Equal margins on both sides
    head: [['Omschrijving', 'Dagen', 'Tarief', 'Bedrag']],
    body: [
      [
        `Plaatsing bord op ${invoice.address}`,
        invoice.days > 30 ? '30' : invoice.days.toString(),
        '-',
        `€${baseCost.toFixed(2)}`
      ],
      ...(daysOver30 > 0 ? [
        [
          'Extra dagen',
          daysOver30.toString(),
          `€${dailyCost.toFixed(2)}`,
          `€${extraDaysCost.toFixed(2)}`
        ]
      ] : [])
    ],
    foot: [
      [
        { content: 'Subtotaal', colSpan: 3, styles: { halign: 'right', fontStyle: 'bold', textColor: [0, 0, 0] } },
        `€${totalExcl.toFixed(2)}`
      ],
      [
        { content: 'BTW (21%)', colSpan: 3, styles: { halign: 'right', textColor: [0, 0, 0] } },
        `€${vat.toFixed(2)}`
      ],
      [
        { content: 'Totaal', colSpan: 3, styles: { halign: 'right', fontStyle: 'bold', textColor: [0, 0, 0] } },
        `€${totalIncl.toFixed(2)}`
      ]
    ],
    theme: 'striped',
    styles: { 
      fontSize: 9, // Smaller font
      cellPadding: 4, // Less padding
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3 // Thinner lines
    },
    headStyles: { 
      fillColor: [0, 74, 173], 
      textColor: [255, 255, 255],
      fontSize: 10, // Smaller header font
      fontStyle: 'bold',
      cellPadding: 3, // Less padding for lower height
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3
    },
    footStyles: { 
      fillColor: [245, 245, 245], 
      textColor: [0, 0, 0],
      fontSize: 9, // Smaller footer font
      fontStyle: 'bold',
      cellPadding: 4, // Less padding
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3
    },
    alternateRowStyles: {
      fillColor: [250, 250, 250],
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3
    },
    tableWidth: 'auto', // Let table use full available width
    columnStyles: {
      0: { cellWidth: 'auto' }, // Omschrijving - auto width
      1: { cellWidth: 25, halign: 'center' }, // Dagen - fixed width
      2: { cellWidth: 25, halign: 'center' }, // Tarief - fixed width
      3: { cellWidth: 30, halign: 'right' } // Bedrag - fixed width
    }
  });

  // Add payment details
  const finalY = (doc as any).lastAutoTable.finalY || 145;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Betalingsgegevens:', 15, finalY + 15); // Reduced spacing
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('IBAN: BE66 3632 4232 5743', 15, finalY + 23); // Reduced spacing
  doc.text('BIC: BBRUBEBB', 15, finalY + 28); // Reduced spacing
  doc.text(`Referentie: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`, 15, finalY + 33); // Reduced spacing

  // Add Belgian payment terms
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('Betalingsvoorwaarden:', 15, finalY + 45);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  
  // Split the text into multiple lines for better readability
  const paymentTerms = [
    'Betalingstermijn: 30 dagen vanaf factuurdatum',
    'Na 30 dagen wordt automatisch een gratis herinnering verstuurd.',
    'Na de herinnering heeft u 14 dagen de tijd om te betalen.',
    'Na deze periode kunnen verwijlintresten van 12,5%',
    'en forfaitaire schadevergoeding worden aangerekend conform',
    'de Belgische wetgeving (vanaf 1 december 2023).'
  ];
  
  let currentY = finalY + 53;
  paymentTerms.forEach(line => {
    doc.text(line, 15, currentY);
    currentY += 4;
  });

  // Add footer - MOVED BELOW PAYMENT TERMS
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text('Bedankt voor uw vertrouwen', 15, currentY + 8);

  return doc;
};

export const generateCombinedInvoicePDF = async (invoice: Invoice, signs: SignData[]) => {
  const doc = new jsPDF();
  
  // Add logo
  await addLogoToDoc(doc);
  
  // Reset text color
  doc.setTextColor(0, 0, 0);

  // Add company information in top right
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Aproxx', 150, 20);
  doc.text('De Slogen 47', 150, 25);
  doc.text('3550 Heusden-Zolder', 150, 30);
  doc.text('België', 150, 35);
  doc.text('BTW: BE1007197223', 150, 40);
  doc.text('M: info@aproxx.com', 150, 45);

  // Add invoice header - MOVED TO ALIGN WITH BILLING DETAILS
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('FACTUUR', 150, 95);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Factuurnummer: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`, 150, 105);
  doc.text(`Datum: ${format(new Date(invoice.createdAt), 'dd/MM/yyyy')}`, 150, 110);
  doc.text(`Vervaldatum: ${format(new Date(invoice.dueDate), 'dd/MM/yyyy')}`, 150, 115);
  doc.text(`Aantal borden: ${signs.length}`, 150, 120);

  // Add billing details - SAME Y POSITION AS INVOICE HEADER
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('Factureren aan:', 15, 95);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(invoice.billingDetails.name, 15, 105);
  doc.text(invoice.billingDetails.address, 15, 110);
  doc.text(`${invoice.billingDetails.postalCode} ${invoice.billingDetails.city}`, 15, 115);
  doc.text(invoice.billingDetails.country, 15, 120);
  doc.text(`BTW: ${invoice.billingDetails.vatNumber}`, 15, 125);

  // Get pricing used for this invoice (fallback to defaults if not available)
  const baseCost = invoice.pricingUsed?.baseCost || 220;
  const dailyCost = invoice.pricingUsed?.dailyCost || 4;

  // Prepare table data for all signs
  const tableData = [];
  let totalExcl = 0;

  signs.forEach((sign, index) => {
    let days = 0;
    if (sign.placedAt && sign.removalRequestedAt) {
      const placedDate = new Date(sign.placedAt);
      const removalDate = new Date(sign.removalRequestedAt);
      days = Math.max(0, Math.floor(
        (removalDate.getTime() - placedDate.getTime()) / (1000 * 60 * 60 * 24)
      )) + 1;
    }

    const daysOver30 = Math.max(0, days - 30);
    const extraDaysCost = daysOver30 * dailyCost;
    const signTotal = baseCost + extraDaysCost;
    totalExcl += signTotal;

    // Add base cost row
    tableData.push([
      `${index + 1}. Plaatsing bord op ${sign.address}`,
      days > 30 ? '30' : days.toString(),
      '-',
      `€${baseCost.toFixed(2)}`
    ]);

    // Add extra days row if applicable
    if (daysOver30 > 0) {
      tableData.push([
        `   Extra dagen voor bord ${index + 1}`,
        daysOver30.toString(),
        `€${dailyCost.toFixed(2)}`,
        `€${extraDaysCost.toFixed(2)}`
      ]);
    }
  });

  const vat = totalExcl * 0.21;
  const totalIncl = totalExcl + vat;

  autoTable(doc, {
    startY: 145,
    margin: { left: 15, right: 15 }, // Equal margins on both sides
    head: [['Omschrijving', 'Dagen', 'Tarief', 'Bedrag']],
    body: tableData,
    foot: [
      [
        { content: 'Subtotaal', colSpan: 3, styles: { halign: 'right', fontStyle: 'bold', textColor: [0, 0, 0] } },
        `€${totalExcl.toFixed(2)}`
      ],
      [
        { content: 'BTW (21%)', colSpan: 3, styles: { halign: 'right', textColor: [0, 0, 0] } },
        `€${vat.toFixed(2)}`
      ],
      [
        { content: 'Totaal', colSpan: 3, styles: { halign: 'right', fontStyle: 'bold', textColor: [0, 0, 0] } },
        `€${totalIncl.toFixed(2)}`
      ]
    ],
    theme: 'striped',
    styles: { 
      fontSize: 8, // Even smaller for combined invoice
      cellPadding: 3, // Less padding
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3 // Thinner lines
    },
    headStyles: { 
      fillColor: [0, 74, 173], 
      textColor: [255, 255, 255],
      fontSize: 9, // Smaller header font
      fontStyle: 'bold',
      cellPadding: 2, // Less padding for lower height
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3
    },
    footStyles: { 
      fillColor: [245, 245, 245], 
      textColor: [0, 0, 0],
      fontSize: 8, // Smaller footer font
      fontStyle: 'bold',
      cellPadding: 3, // Less padding
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3
    },
    alternateRowStyles: {
      fillColor: [250, 250, 250],
      lineColor: [0, 0, 0], // Black borders
      lineWidth: 0.3
    },
    tableWidth: 'auto', // Let table use full available width
    columnStyles: {
      0: { cellWidth: 'auto' }, // Omschrijving - auto width for combined invoice
      1: { cellWidth: 20, halign: 'center' }, // Dagen - smaller for combined invoice
      2: { cellWidth: 20, halign: 'center' }, // Tarief - smaller for combined invoice
      3: { cellWidth: 25, halign: 'right' } // Bedrag - smaller for combined invoice
    }
  });

  // Add payment details
  const finalY = (doc as any).lastAutoTable.finalY || 145;
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Betalingsgegevens:', 15, finalY + 15); // Reduced spacing
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('IBAN: BE66 3632 4232 5743', 15, finalY + 23); // Reduced spacing
  doc.text('BIC: BBRUBEBB', 15, finalY + 28); // Reduced spacing
  doc.text(`Referentie: ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`, 15, finalY + 33); // Reduced spacing

  // Add Belgian payment terms
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('Betalingsvoorwaarden:', 15, finalY + 45);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  
  // Split the text into multiple lines for better readability
  const paymentTerms = [
    'Betalingstermijn: 30 dagen vanaf factuurdatum',
    'Na 30 dagen wordt automatisch een gratis herinnering verstuurd.',
    'Na de herinnering heeft u 14 dagen de tijd om te betalen.',
    'Na deze periode kunnen verwijlintresten van 12,5%',
    'en forfaitaire schadevergoeding worden aangerekend conform',
    'de Belgische wetgeving (vanaf 1 december 2023).'
  ];
  
  let currentY = finalY + 53;
  paymentTerms.forEach(line => {
    doc.text(line, 15, currentY);
    currentY += 4;
  });

  // Add footer - MOVED BELOW PAYMENT TERMS
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text('Bedankt voor uw vertrouwen', 15, currentY + 8);

  return doc;
};