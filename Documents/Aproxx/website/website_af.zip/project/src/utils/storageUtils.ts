// Storage utility functions

/**
 * Test if localStorage is available and working
 * 
 * This function tests if localStorage is available and working correctly
 * by attempting to set and retrieve a test value.
 * 
 * @returns boolean True if localStorage is available and working
 */
export const testLocalStorage = (): boolean => {
  try {
    // Try to set a test value
    const testKey = '_test_storage_' + Date.now();
    localStorage.setItem(testKey, 'test');
    
    // Try to retrieve the test value
    const testValue = localStorage.getItem(testKey);
    
    // Clean up the test value
    localStorage.removeItem(testKey);
    
    // Check if the test value was retrieved correctly
    return testValue === 'test';
  } catch (error) {
    console.error('localStorage test failed:', error);
    return false;
  }
};

/**
 * Get the total localStorage usage in bytes
 * 
 * @returns number The total size in bytes
 */
export const getLocalStorageUsage = (): number => {
  try {
    let totalSize = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        const value = localStorage.getItem(key) || '';
        totalSize += key.length + value.length;
      }
    }
    return totalSize;
  } catch (error) {
    console.error('Error calculating localStorage usage:', error);
    return 0;
  }
};

/**
 * Get the localStorage usage as a percentage of the available space
 * 
 * Most browsers have a limit of 5MB (5,242,880 bytes) for localStorage
 * 
 * @returns number The percentage of used space (0-100)
 */
export const getLocalStorageUsagePercentage = (): number => {
  try {
    const totalSize = getLocalStorageUsage();
    // Assume 5MB limit (common browser limit)
    const limit = 5 * 1024 * 1024;
    return (totalSize / limit) * 100;
  } catch (error) {
    console.error('Error calculating localStorage usage percentage:', error);
    return 0;
  }
};

/**
 * Clear all application data from localStorage
 * 
 * WARNING: This will delete all application data!
 * 
 * @returns boolean True if successful
 */
export const clearAllApplicationData = (): boolean => {
  try {
    // List of keys to clear
    const appKeys = [
      'allSigns',
      'allTrashedSigns',
      'allInvoices',
      'allDeletedInvoices',
      'workAssignments_v2',
      'invoiceCounter'
    ];
    
    // Clear all app-specific keys
    appKeys.forEach(key => localStorage.removeItem(key));
    
    // Clear all user-specific billing details
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('userBillingDetails_')) {
        localStorage.removeItem(key);
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error clearing application data:', error);
    return false;
  }
};

/**
 * Export all application data as a JSON string
 * 
 * @returns string JSON string containing all application data
 */
export const exportApplicationData = (): string => {
  try {
    const data: Record<string, any> = {};
    
    // Export all localStorage items
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        const value = localStorage.getItem(key);
        if (value) {
          try {
            // Try to parse JSON values
            data[key] = JSON.parse(value);
          } catch {
            // If not JSON, store as string
            data[key] = value;
          }
        }
      }
    }
    
    return JSON.stringify(data, null, 2);
  } catch (error) {
    console.error('Error exporting application data:', error);
    return JSON.stringify({ error: 'Failed to export data' });
  }
};

/**
 * Import application data from a JSON string
 * 
 * @param jsonData JSON string containing application data
 * @returns boolean True if successful
 */
export const importApplicationData = (jsonData: string): boolean => {
  try {
    const data = JSON.parse(jsonData);
    
    // Import all items
    Object.entries(data).forEach(([key, value]) => {
      localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
    });
    
    return true;
  } catch (error) {
    console.error('Error importing application data:', error);
    return false;
  }
};