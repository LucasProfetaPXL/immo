# Supabase Setup Error Fix

Je krijgt "Something went wrong while setting up Supabase" omdat de configuratie niet correct is. Volg deze stappen:

## 🔧 Stap 1: Controleer Environment Variables

1. **Controleer je `.env` bestand** - Het moet deze structuur hebben:
```env
VITE_SUPABASE_URL=https://jouwprojectid.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

2. **Zorg dat de waarden EXACT kloppen** met je nieuwe Supabase project

## 🔧 Stap 2: Nieuwe Supabase Credentials Ophalen

1. Ga naar je **nieuwe** Supabase Dashboard
2. Ga naar **Settings** → **API**
3. Kopieer deze waarden:
   - **Project URL** (bijv. `https://abcdefg.supabase.co`)
   - **anon public** key (lange string)
   - **service_role** key (andere lange string)

## 🔧 Stap 3: Database Schema Installeren

1. Ga naar **SQL Editor** in je Supabase Dashboard
2. Klik **"New query"**
3. Kopieer de VOLLEDIGE inhoud van `supabase/migrations/20250706094719_lingering_sunset.sql`
4. Plak in de editor
5. Klik **"Run"**
6. Wacht tot "Success" verschijnt

## 🔧 Stap 4: Storage Policies Fix (Als Nodig)

Als je nog steeds errors krijgt, voer dan ook uit:
1. Kopieer de inhoud van `supabase/migrations/20250706094810_still_tooth.sql`
2. Voer uit in SQL Editor

## 🔧 Stap 5: Applicatie Herstarten

1. Stop de development server (Ctrl+C)
2. Start opnieuw: `npm run dev`
3. Test de applicatie

## ✅ Verificatie

Test deze functionaliteiten:
- [ ] Applicatie laadt zonder errors
- [ ] Admin login werkt (admin/admin123)
- [ ] Nieuwe gebruiker kan worden aangemaakt
- [ ] Afbeelding upload werkt

## 🚨 Veel Voorkomende Problemen

### "Invalid API URL"
- Controleer dat je URL eindigt op `.supabase.co`
- Geen trailing slash `/` aan het einde

### "Invalid API Key"
- Controleer dat je de juiste keys hebt gekopieerd
- Anon key en Service Role key zijn verschillend

### "Bucket not found"
- Voer de storage policies fix uit
- Controleer dat de images bucket bestaat in Storage

### "Unauthorized"
- Database schema is niet correct geïnstalleerd
- Voer de complete migratie opnieuw uit

## 📞 Als Het Nog Steeds Niet Werkt

1. Controleer browser console voor specifieke errors
2. Controleer Supabase Dashboard logs
3. Zorg dat je project actief is (niet gepauzeerd)
4. Probeer een nieuwe browser/incognito mode

De error zou nu opgelost moeten zijn!