import React, { useState } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useAuth } from '../../context/AuthContext';
import { useSigns } from '../../context/SignsContext';
import SignMap from '../common/SignMap';
import EmployeeNavigation from './EmployeeNavigation';
import EmployeePlaceSignsTab from './EmployeePlaceSignsTab';
import EmployeeRemoveSignsTab from './EmployeeRemoveSignsTab';
import EmployeeSoldSignsTab from './EmployeeSoldSignsTab';
import { getEmployeeWorkAssignment } from '../../utils/workDistribution';
import { LogOut, Menu, X } from 'lucide-react';

// Belgium bounds
const belgiumBounds = [[49.5, 2.5], [51.5, 6.4]] as L.LatLngBoundsExpression;
const defaultCenter = [50.8503, 4.3517] as [number, number]; // Brussels

type EmployeeTabType = 'place-signs' | 'remove-signs' | 'sold-signs';

function EmployeeDashboard() {
  const { logout } = useAuth();
  const { allSigns } = useSigns();
  const [activeTab, setActiveTab] = useState<EmployeeTabType>('place-signs');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();
  
  // Get work assignment for map display
  const workAssignment = currentUser ? getEmployeeWorkAssignment(currentUser.id, allSigns) : null;
  const allAssignedSigns = workAssignment ? [
    ...workAssignment.placementSigns,
    ...workAssignment.removalSigns,
    ...workAssignment.soldSigns
  ] : [];

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };
  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Header */}
      <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <button
              onClick={toggleSidebar}
              className="mobile-menu-toggle mr-3 lg:hidden"
              aria-label="Toggle menu"
            >
              {sidebarCollapsed ? <Menu size={24} /> : <X size={24} />}
            </button>
            <h1 className="text-xl font-bold text-gray-900">Bordbeheer Systeem - Werknemer</h1>
            {currentUser && currentUser.companyName && (
              <>
                <span className="mx-3 text-gray-400">•</span>
                <span className="text-lg font-medium text-green-600">{currentUser.companyName}</span>
                <span className="mx-2 text-gray-400">•</span>
                <span className="text-sm text-gray-600">{currentUser.username}</span>
              </>
            )}
          </div>
          <button
            onClick={logout}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <LogOut size={16} className="mr-1" />
            <span>Uitloggen</span>
          </button>
        </div>
      </header>

      {/* Sidebar Overlay for mobile */}
      <div 
        className={`sidebar-overlay ${!sidebarCollapsed ? 'active' : ''} lg:hidden`}
        onClick={toggleSidebar}
      />
      {/* Sidebar with Navigation */}
      <div className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''} fixed left-0 top-16 bottom-0 z-20 lg:relative lg:transform-none`}>
        <EmployeeNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>

      {/* Left Panel - Map (hidden on mobile when sidebar is open) */}
      <div className={`w-full lg:w-1/2 mt-16 p-4 ${!sidebarCollapsed ? 'hidden lg:block' : ''}`}>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm h-full">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold">Uw Werkgebied</h3>
            <p className="text-sm text-gray-500">
              {workAssignment ? `${workAssignment.totalSigns} borden toegewezen` : 'Geen werk toegewezen'}
            </p>
          </div>
          
          <div className="p-4 h-[calc(100vh-250px)]">
            <div className="h-full w-full rounded-lg overflow-hidden border border-gray-200">
              <MapContainer 
                center={workAssignment ? [workAssignment.centerLat, workAssignment.centerLng] : defaultCenter} 
                zoom={workAssignment ? 12 : 8} 
                style={{ height: '100%', width: '100%', display: 'block' }}
                zoomControl={true}
                scrollWheelZoom={true}
                maxBounds={belgiumBounds}
                key="employee-dashboard-map"
              >
                <TileLayer
                  url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <SignMap 
                  signs={allAssignedSigns} 
                  showPreview={true}
                />
              </MapContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Content */}
      <div className={`w-full lg:w-1/2 mt-16 p-4 ${sidebarCollapsed ? 'ml-0' : 'ml-64 lg:ml-0'}`}>
        <div className="bg-white rounded-lg shadow h-full">
          <div className="p-4 h-[calc(100vh-200px)] overflow-y-auto">
            <div style={{ display: activeTab === 'place-signs' ? 'block' : 'none' }}>
              <EmployeePlaceSignsTab />
            </div>
            <div style={{ display: activeTab === 'remove-signs' ? 'block' : 'none' }}>
              <EmployeeRemoveSignsTab />
            </div>
            <div style={{ display: activeTab === 'sold-signs' ? 'block' : 'none' }}>
              <EmployeeSoldSignsTab />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EmployeeDashboard;