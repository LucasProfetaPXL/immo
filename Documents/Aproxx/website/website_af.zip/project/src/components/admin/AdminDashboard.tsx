import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import AdminNavigation from './AdminNavigation';
import AdminDashboardTab from './AdminDashboardTab';
import PlaceSignsTab from './PlaceSignsTab';
import RemoveSignsTab from './RemoveSignsTab';
import SoldSignsTab from './SoldSignsTab';
import EmployeesTab from './EmployeesTab';
import CompanyOverviewTab from './CompanyOverviewTab';
import UserManagementTab from './UserManagementTab';
import IncomeTab from './IncomeTab';
import { LogOut, Menu, X } from 'lucide-react';

type AdminTabType = 'dashboard' | 'place-signs' | 'remove-signs' | 'sold-signs' | 'employees' | 'company-overview' | 'income' | 'user-management';

function AdminDashboard() {
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTabType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Header */}
      <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <button
              onClick={toggleSidebar}
              className="mobile-menu-toggle mr-3 lg:hidden"
              aria-label="Toggle menu"
            >
              {sidebarCollapsed ? <Menu size={24} /> : <X size={24} />}
            </button>
            <h1 className="text-xl font-bold text-gray-900">Bordbeheer Systeem - Admin</h1>
          </div>
          <button
            onClick={logout}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <LogOut size={16} className="mr-1" />
            <span>Uitloggen</span>
          </button>
        </div>
      </header>

      {/* Sidebar Overlay for mobile */}
      <div 
        className={`sidebar-overlay ${!sidebarCollapsed ? 'active' : ''} lg:hidden`}
        onClick={toggleSidebar}
      />

      {/* Sidebar */}
      <div className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''} fixed left-0 top-16 bottom-0 z-20`}>
        <AdminNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>

      {/* Main Content */}
      <main className={`flex-1 mt-16 p-6 ${sidebarCollapsed ? 'sidebar-collapsed' : 'ml-64'}`}>
        <div className="bg-white rounded-lg shadow">
          <div style={{ display: activeTab === 'dashboard' ? 'block' : 'none' }}>
            <AdminDashboardTab />
          </div>
          <div style={{ display: activeTab === 'place-signs' ? 'block' : 'none' }}>
            <PlaceSignsTab />
          </div>
          <div style={{ display: activeTab === 'remove-signs' ? 'block' : 'none' }}>
            <RemoveSignsTab />
          </div>
          <div style={{ display: activeTab === 'sold-signs' ? 'block' : 'none' }}>
            <SoldSignsTab />
          </div>
          <div style={{ display: activeTab === 'employees' ? 'block' : 'none' }}>
            <EmployeesTab />
          </div>
          <div style={{ display: activeTab === 'company-overview' ? 'block' : 'none' }}>
            <CompanyOverviewTab />
          </div>
          <div style={{ display: activeTab === 'user-management' ? 'block' : 'none' }}>
            <UserManagementTab />
          </div>
          <div style={{ display: activeTab === 'income' ? 'block' : 'none' }}>
            <IncomeTab />
          </div>
        </div>
      </main>
    </div>
  );
}

export default AdminDashboard;