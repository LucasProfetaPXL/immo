import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import AdminNavigation from './AdminNavigation';
import PlaceSignsTab from './PlaceSignsTab';
import RemoveSignsTab from './RemoveSignsTab';
import CompanyOverviewTab from './CompanyOverviewTab';
import UserManagementTab from './UserManagementTab';
import IncomeTab from './IncomeTab';
import { LogOut } from 'lucide-react';

type AdminTabType = 'place-signs' | 'remove-signs' | 'company-overview' | 'user-management' | 'income';

function AdminDashboard() {
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTabType>('place-signs');

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold text-gray-900">Bordbeheer Systeem - Admin</h1>
          <button
            onClick={logout}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <LogOut size={16} className="mr-1" />
            <span>Uitloggen</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <AdminNavigation activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-4 bg-white rounded-lg shadow">
          <div style={{ display: activeTab === 'place-signs' ? 'block' : 'none' }}>
            <PlaceSignsTab />
          </div>
          <div style={{ display: activeTab === 'remove-signs' ? 'block' : 'none' }}>
            <RemoveSignsTab />
          </div>
          <div style={{ display: activeTab === 'company-overview' ? 'block' : 'none' }}>
            <CompanyOverviewTab />
          </div>
          <div style={{ display: activeTab === 'user-management' ? 'block' : 'none' }}>
            <UserManagementTab />
          </div>
          <div style={{ display: activeTab === 'income' ? 'block' : 'none' }}>
            <IncomeTab />
          </div>
        </div>
      </main>
    </div>
  );
}

export default AdminDashboard;