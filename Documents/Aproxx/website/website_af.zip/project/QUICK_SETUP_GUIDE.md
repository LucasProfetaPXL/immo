# 🚀 Quick Setup Guide - Nieuwe Supabase Account

## Stap 1: Environment Variables (MEEST BELANGRIJK)

1. **Open je `.env` bestand**
2. **Vervang ALLE waarden** met je nieuwe Supabase project:

```env
VITE_SUPABASE_URL=https://jouwnieuweprojectid.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Waar vind je deze waarden?**
- Ga naar je Supabase Dashboard
- Klik **Settings** → **API**
- Kopieer de 3 waarden

## Stap 2: Database Schema Installeren

1. **Ga naar SQL Editor** in je Supabase Dashboard
2. **Kopieer deze VOLLEDIGE file**: `supabase/migrations/20250706094719_lingering_sunset.sql`
3. **Plak in SQL Editor** en klik **"Run"**
4. **Wacht op "Success"**

## Stap 3: Test de Applicatie

1. **Herstart de app**: Stop (Ctrl+C) en start `npm run dev`
2. **Test admin login**: admin/admin123
3. **Test afbeelding upload**

## ✅ Klaar!

Je applicatie zou nu moeten werken met alle functionaliteiten:
- Multi-user support
- Custom pricing
- Belgian invoice system  
- Work distribution
- Image management
- Placement details
- Proof images

**Als je nog errors krijgt, voer dan ook `supabase/migrations/20250706094810_still_tooth.sql` uit voor storage fixes.**