import React, { useState, useEffect } from 'react';
import { useSigns } from '../../context/SignsContext';
import ProofUploadModal from '../common/ProofUploadModal';
import ImageViewerModal from '../common/ImageViewerModal';
import { Search, X, Download, Camera, Users, Eye } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { getEmployeeWorkAssignment } from '../../utils/workDistribution';
import { downloadImage } from '../../utils/imageUtils';
import { formatAddress } from '../../utils/addressFormatter.tsx';
import toast from 'react-hot-toast';

function EmployeeRemoveSignsTab() {
  const { updateSignStatus, updateSign, getSignById, allSigns } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSigns, setSelectedSigns] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showProofModal, setShowProofModal] = useState(false);
  const [currentSignId, setCurrentSignId] = useState<string | null>(null);
  const [assignedSigns, setAssignedSigns] = useState<any[]>([]);
  const [workAssignment, setWorkAssignment] = useState<any>(null);
  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());
  const [imageViewerState, setImageViewerState] = useState<{
    isOpen: boolean;
    images: string[];
    currentIndex: number;
    title: string;
    description: string;
  }>({
    isOpen: false,
    images: [],
    currentIndex: 0,
    title: '',
    description: ''
  });
  
  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();
  
  // Load completed tasks from localStorage
  useEffect(() => {
    if (currentUser && currentUser.id) {
      const savedCompletedTasks = localStorage.getItem(`completedTasks_${currentUser.id}`);
      if (savedCompletedTasks) {
        try {
          const taskIds = JSON.parse(savedCompletedTasks);
          setCompletedTasks(new Set(taskIds));
          console.log(`📋 Loaded ${taskIds.length} completed tasks for employee ${currentUser.username}`);
        } catch (error) {
          console.error('Error loading completed tasks:', error);
        }
      }
    }
  }, [currentUser?.id]);

  // Save completed tasks to localStorage whenever they change
  useEffect(() => {
    if (currentUser && currentUser.id && completedTasks.size > 0) {
      const taskIds = Array.from(completedTasks);
      localStorage.setItem(`completedTasks_${currentUser.id}`, JSON.stringify(taskIds));
      console.log(`💾 Saved ${taskIds.length} completed tasks for employee ${currentUser.username}`);
    }
  }, [completedTasks, currentUser?.id]);

  // Load work assignment ONLY ONCE on mount
  useEffect(() => {
    if (currentUser && currentUser.id) {
      console.log(`👤 Loading work assignment for employee: ${currentUser.username}`);
      const assignment = getEmployeeWorkAssignment(currentUser.id, allSigns);
      setWorkAssignment(assignment);
      
      if (assignment) {
        console.log(`📋 Employee ${currentUser.username} assigned ${assignment.removalSigns.length} removal signs`);
        setAssignedSigns(assignment.removalSigns);
      } else {
        console.log(`❌ No work assignment found for employee: ${currentUser.username}`);
        setAssignedSigns([]);
      }
    }
  }, [currentUser?.id, allSigns]);

  // Filter out completed tasks from display
  const activeSigns = assignedSigns.filter(sign => !completedTasks.has(sign.id));
  
  const filteredSigns = activeSigns.filter(sign => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  const handleViewPlacementImages = (sign: any) => {
    setImageViewerState({
      isOpen: true,
      images: sign.placementDetails.placementImages,
      currentIndex: 0,
      title: 'Plaatsingsafbeeldingen',
      description: `${sign.address} - ${sign.placementDetails.placementImages.length} afbeelding(en)`
    });
  };

  // Open image viewer for proof images
  const handleViewProofImage = (imageUrl: string, type: 'placed' | 'removed', address: string) => {
    setImageViewerState({
      isOpen: true,
      images: [imageUrl],
      currentIndex: 0,
      title: type === 'placed' ? 'Bewijs van Plaatsing' : 'Bewijs van Ophaling',
      description: address
    });
  };

  // Close image viewer
  const closeImageViewer = () => {
    setImageViewerState({
      isOpen: false,
      images: [],
      currentIndex: 0,
      title: '',
      description: ''
    });
  };

  const handleToggleSelect = (id: string) => {
    if (selectedSigns.includes(id)) {
      setSelectedSigns([]);
    } else {
      // Only allow single selection for removal tasks
      setSelectedSigns([id]);
    }
  };

  const handleMarkPickedUp = () => {
    if (selectedSigns.length === 0) {
      toast.error('Selecteer ten minste één bord');
      return;
    }
    
    if (selectedSigns.length !== 1) {
      toast.error('Selecteer precies één bord om op te halen');
      return;
    }
    
    setCurrentSignId(selectedSigns[0]);
    setShowProofModal(true);
  };

  const handleProofSubmit = (proofImageUrl: string) => {
    if (currentSignId) {
      console.log(`🔄 Completing task for sign ${currentSignId}`);
      console.log(`📸 Proof image URL received: ${proofImageUrl}`);
      
      const currentSign = getSignById(currentSignId);
      if (currentSign) {
        console.log(`📋 Current sign found:`, currentSign.id);
        console.log(`📋 Current proof images:`, currentSign.proofImages);
        
        // Update with proof image
        updateSign(currentSignId, {
          proofImages: {
            ...(currentSign.proofImages || {}),
            removed: proofImageUrl
          }
        });
        
        console.log(`💾 Updated sign with proof image for removal`);
        
        // Update status to removed
        updateSignStatus(currentSignId, 'removed');
        console.log(`🔄 Updated sign status to 'removed'`);
      } else {
        console.error(`❌ Sign ${currentSignId} not found when trying to save proof`);
      }
      
      // Mark task as completed locally (for employee view only)
      setCompletedTasks(prev => {
        const newSet = new Set(prev);
        newSet.add(currentSignId);
        console.log(`✅ Task ${currentSignId} marked as completed locally for employee`);
        return newSet;
      });
      
      // Clear selection
      setSelectedSigns([]);
      setCurrentSignId(null);
      setShowProofModal(false);
      
      toast.success('Taak voltooid - bord opgehaald!');
    }
  };

  // Handle selection of all signs
  const handleSelectAll = () => {
    if (selectedSigns.length > 0) {
      setSelectedSigns([]);
    } else {
      // For removal tasks, only allow single selection - select first available sign
      if (filteredSigns.length > 0) {
        setSelectedSigns([filteredSigns[0].id]);
        toast('Voor ophaling kunt u slechts één bord per keer selecteren', {
          icon: 'ℹ️'
        });
      }
    }
  };

  const handleDownloadImage = (imageUrl: string, address: string) => {
    downloadImage(imageUrl, address);
  };

  const formatAddress = (address: string) => {
    return address;
  };

  return (
    <div>
      <h2 className="text-lg font-bold mb-4">Borden Verwijderen</h2>
      
      {/* Work Assignment Info */}
      {workAssignment && (
        <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Users size={20} className="text-orange-600 mr-2" />
              <div>
                <h3 className="font-medium text-orange-800">Uw Werkgebied</h3>
                <p className="text-sm text-orange-600">
                  {activeSigns.length} borden om op te halen in uw toegewezen gebied
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-orange-600">Totaal werk toegewezen:</div>
              <div className="font-bold text-orange-800">{workAssignment.totalSigns} borden</div>
              <div className="text-xs text-orange-500">
                ({workAssignment.placementSigns.length} plaatsen + {workAssignment.removalSigns.length} ophalen)
              </div>
              {completedTasks.size > 0 && (
                <div className="text-xs text-green-600 mt-1">
                  Voltooid: {completedTasks.size} taken
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-gray-50 rounded-lg border border-gray-200">
        <div className="border-b border-gray-200 p-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className="relative mr-2">
                <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Zoek borden..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')} 
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>
              
              <button
                onClick={handleSelectAll}
                className="text-sm text-primary-blue hover:text-blue-700" 
              >
                {selectedSigns.length > 0 
                  ? 'Deselecteer'
                  : 'Selecteer Eerste'}
              </button>
            </div>
            
            <div>
              <button
                onClick={handleMarkPickedUp}
                disabled={selectedSigns.length === 0 || isSubmitting}
                className={`btn ${
                  selectedSigns.length === 0
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'btn-danger'
                } ${isSubmitting ? 'opacity-75 cursor-wait' : ''} flex items-center`}
              >
                <Camera size={16} className="mr-2" />
                {isSubmitting 
                  ? 'Verwerken...' 
                  : selectedSigns.length === 1 
                    ? 'Markeer als Opgehaald (1)' 
                    : 'Selecteer 1 Bord'}
              </button>
            </div>
          </div>
          
          <div className="p-4">
            {filteredSigns.length === 0 ? (
              <div className="text-center py-10 text-gray-500">
                {activeSigns.length === 0 ? (
                  <div>
                    <p>Geen borden toegewezen voor ophaling</p>
                    {completedTasks.size > 0 && (
                      <p className="text-sm text-green-600 mt-2">
                        ✅ {completedTasks.size} taken voltooid
                      </p>
                    )}
                  </div>
                ) : (
                  <p>Geen borden gevonden die voldoen aan uw zoekcriteria</p>
                )}
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredSigns.map(sign => (
                  <div 
                    key={sign.id}
                    className={`p-3 rounded-md border transition-colors ${
                      selectedSigns.includes(sign.id)
                        ? 'border-primary-blue bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            className="mr-3 h-4 w-4 text-primary-blue rounded border-gray-300 focus:ring-primary-blue"
                            checked={selectedSigns.includes(sign.id)}
                            onChange={() => handleToggleSelect(sign.id)}
                          />
                          <div>
                            <p className="font-medium text-sm">{sign.companyName}</p>
                            <p className="text-xs text-gray-600">{sign.address}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center mt-2 ml-7">
                          <span className="status-badge status-removal-confirmed text-xs">
                            Verwijderd
                          </span>
                          <span className="text-xs text-gray-500 ml-2">
                            {formatDateInDutch(new Date(sign.updatedAt))}
                          </span>
                        </div>

                        {/* Show placement details if available */}
                        {sign.placementDetails && (
                          <div className="ml-7 mt-2 p-2 bg-orange-50 rounded text-xs">
                            {sign.placementDetails.specificLocation && (
                              <div className="text-orange-700">
                                📍 {sign.placementDetails.specificLocation}
                              </div>
                            )}
                            <div className="text-orange-700">
                              🔄 {sign.placementDetails.orientation === 'above-ballast' ? 'Boven de ballast' : 'Links van de ballast'}
                            </div>
                            {sign.placementDetails.placementImages && sign.placementDetails.placementImages.length > 0 && (
                              <div className="text-orange-700 flex items-center">
                                <span>📷 {sign.placementDetails.placementImages.length} afbeelding(en)</span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleViewPlacementImages(sign);
                                  }}
                                  className="ml-2 text-orange-600 hover:text-orange-800"
                                  title="Bekijk plaatsingsafbeeldingen"
                                >
                                  <Eye size={10} />
                                </button>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Show proof images if available */}
                        {sign.proofImages?.placed && (
                          <div className="ml-7 mt-2 p-2 bg-green-50 rounded text-xs">
                            <div className="text-green-700 flex items-center">
                              <span>✅ Bewijs van plaatsing beschikbaar</span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleViewProofImage(sign.proofImages!.placed!, 'placed', sign.address);
                                }}
                                className="ml-2 text-green-600 hover:text-green-800"
                                title="Bekijk bewijs van plaatsing"
                              >
                                <Eye size={10} />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex items-center">
                        {sign.imageUrl && (
                          <div className="flex items-center space-x-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDownloadImage(sign.imageUrl!, sign.address);
                              }}
                              className="text-gray-500 hover:text-gray-700"
                              title="Download afbeelding"
                            >
                              <Download size={12} />
                            </button>
                            <div className="w-12 h-12 rounded-md overflow-hidden border border-gray-200">
                              <div 
                                style={{
                                  width: '100%',
                                  height: '100%',
                                  backgroundImage: `url(${sign.imageUrl})`,
                                  backgroundSize: 'cover',
                                  backgroundPosition: 'center',
                                }}
                              ></div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="p-4 border-t border-gray-200">
            <button
              onClick={handleMarkPickedUp}
              disabled={selectedSigns.length === 0 || isSubmitting}
              className={`btn w-full ${
                selectedSigns.length === 0
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'btn-danger'
              } ${isSubmitting ? 'opacity-75 cursor-wait' : ''} flex items-center justify-center`}
            >
              <Camera size={16} className="mr-2" />
              {isSubmitting 
                ? 'Verwerken...' 
                : selectedSigns.length === 1 
                  ? 'Markeer als Opgehaald (1)' 
                  : 'Selecteer 1 Bord'}
            </button>
          </div>
        </div>
      </div>

      {/* Proof Upload Modal */}
      {showProofModal && currentSignId && (
        <ProofUploadModal
          isOpen={showProofModal}
          onClose={() => {
            setShowProofModal(false);
            setCurrentSignId(null);
          }}
          onSubmit={handleProofSubmit}
          title="Bewijs van Ophaling"
          description="Upload een foto als bewijs dat het bord is opgehaald"
        />
      )}

      {/* Image Viewer Modal */}
      <ImageViewerModal
        isOpen={imageViewerState.isOpen}
        onClose={closeImageViewer}
        images={imageViewerState.images}
        currentIndex={imageViewerState.currentIndex}
        onIndexChange={(index) => setImageViewerState(prev => ({ ...prev, currentIndex: index }))}
        title={imageViewerState.title}
        description={imageViewerState.description}
      />
    </div>
  );
}

export default EmployeeRemoveSignsTab;