import React, { useState, useEffect } from 'react';
import { useSigns } from '../../context/SignsContext';
import { Search, ChevronDown, ChevronRight, MapPin, Download, RefreshCw, Eye } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { decryptData } from '../../utils/encryption';
import { downloadImage } from '../../utils/imageUtils';
import { formatAddress } from '../../utils/addressFormatter';
import ImageViewerModal from '../common/ImageViewerModal';
import toast from 'react-hot-toast';

interface UserAccount {
  id: string;
  companyName: string;
  username: string;
  password: string;
  createdAt: string;
  lastLogin?: string;
  role?: 'user' | 'employee';
}

const STORAGE_KEY = 'userAccounts_encrypted';

function CompanyOverviewTab() {
  const { getVisibleSigns } = useSigns(); // Use visible signs for overview (excludes old removed signs)
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCompanies, setExpandedCompanies] = useState<Record<string, boolean>>({});
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [imageViewerState, setImageViewerState] = useState<{
    isOpen: boolean;
    images: string[];
    currentIndex: number;
    title: string;
    description: string;
  }>({
    isOpen: false,
    images: [],
    currentIndex: 0,
    title: '',
    description: ''
  });
  
  // Load users from encrypted localStorage
  const loadUsers = () => {
    const savedUsers = localStorage.getItem(STORAGE_KEY);
    if (savedUsers) {
      try {
        const encryptedData = JSON.parse(savedUsers);
        const decryptedData = decryptData(encryptedData);
        const parsedUsers = JSON.parse(decryptedData);
        setUsers(parsedUsers);
      } catch (error) {
        console.error('Error loading users:', error);
        setUsers([]);
      }
    } else {
      setUsers([]);
    }
    setIsLoaded(true);
  };

  // Only load users once when component mounts
  useEffect(() => {
    if (!isLoaded) {
      loadUsers();
    }
  }, [isLoaded]);

  // Get visible signs for admin view (excludes old removed signs)
  const allSigns = getVisibleSigns();
  
  // Filter out employees from users - only show regular company users
  const companyUsers = users.filter(user => user.role !== 'employee');
  
  // Group signs by company and get user info (excluding employees)
  const companiesWithSigns = companyUsers.map(user => {
    const companySigns = allSigns.filter(sign => 
      sign.userId === user.id &&
      sign.status !== 'trashed' &&
      sign.status !== 'deleted'
    );
    
    return {
      ...user,
      signs: companySigns,
      signsCount: companySigns.length
    };
  });
  
  // Apply search filter
  const filteredCompanies = companiesWithSigns.filter(company => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      company.companyName.toLowerCase().includes(query) ||
      company.username.toLowerCase().includes(query)
    );
  });
  
  // Sort companies alphabetically by company name
  const sortedCompanies = [...filteredCompanies].sort((a, b) => 
    a.companyName.localeCompare(b.companyName)
  );

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  // Download image function
  const handleDownloadImage = (imageUrl: string, address: string) => {
    downloadImage(imageUrl, `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}`);
  };

  // Open image viewer for placement images
  const handleViewPlacementImages = (sign: any) => {
    if (!sign.placementDetails?.placementImages || sign.placementDetails.placementImages.length === 0) {
      return;
    }

    setImageViewerState({
      isOpen: true,
      images: sign.placementDetails.placementImages,
      currentIndex: 0,
      title: 'Plaatsingsafbeeldingen',
      description: `${sign.address} - ${sign.placementDetails.placementImages.length} afbeelding(en)`
    });
  };

  // Open image viewer for proof images
  const handleViewProofImage = (imageUrl: string, type: 'placed' | 'removed', address: string) => {
    setImageViewerState({
      isOpen: true,
      images: [imageUrl],
      currentIndex: 0,
      title: type === 'placed' ? 'Bewijs van Plaatsing' : 'Bewijs van Ophaling',
      description: address
    });
  };

  // Close image viewer
  const closeImageViewer = () => {
    setImageViewerState({
      isOpen: false,
      images: [],
      currentIndex: 0,
      title: '',
      description: ''
    });
  };

  const toggleCompanyExpand = (companyId: string) => {
    setExpandedCompanies(prev => ({
      ...prev,
      [companyId]: !prev[companyId]
    }));
  };

  const handleRefresh = () => {
    loadUsers();
    toast.success('Gegevens ververst');
  };

  const getStatusText = (status: string) => {
    switch(status) {
      case 'pending': return 'In afwachting';
      case 'confirmed': return 'Bevestigd';
      case 'placed': return 'Geplaatst';
      case 'removal-requested': return 'Verwijdering aangevraagd';
      case 'removal-confirmed': return 'Verwijderd';
      case 'removed': return 'Verwijderd';
      default: return status.replace('-', ' ');
    }
  };

  // Show loading state while data is being loaded
  if (!isLoaded) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-bold mb-4">Bedrijfsoverzicht</h2>
        <div className="flex justify-center items-center py-10">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-blue"></div>
          <span className="ml-2 text-gray-500">Gegevens laden...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Bedrijfsoverzicht</h2>
      
      <div className="flex justify-between items-center mb-4">
        <div className="text-sm text-gray-500">
          {sortedCompanies.length} ondernemingen, {allSigns.filter(s => s.status !== 'trashed' && s.status !== 'deleted').length} actieve borden
          {users.filter(u => u.role === 'employee').length > 0 && (
            <span className="ml-2 text-xs text-gray-400">
              ({users.filter(u => u.role === 'employee').length} werknemers niet getoond)
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={handleRefresh}
            className="btn btn-secondary flex items-center"
            title="Ververs gegevens"
          >
            <RefreshCw size={16} className="mr-1" />
            <span>Ververs</span>
          </button>
          
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Zoek ondernemingen..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-64"
            />
          </div>
        </div>
      </div>
      
      {sortedCompanies.length === 0 ? (
        <div className="text-center py-10 text-gray-500 border rounded-lg">
          <p>Geen ondernemingen gevonden</p>
          {companyUsers.length === 0 && (
            <p className="mt-2 text-sm">Ga naar Gebruikersbeheer om bedrijven aan te maken</p>
          )}
        </div>
      ) : (
        <div className="fixed-height-container">
          <div className="space-y-3 p-3">
            {sortedCompanies.map(company => {
              const isExpanded = expandedCompanies[company.id] || false;
              
              return (
                <div key={company.id} className="border rounded-lg overflow-hidden">
                  <div 
                    className="flex justify-between items-center p-4 bg-gray-50 cursor-pointer hover:bg-gray-100"
                    onClick={() => toggleCompanyExpand(company.id)}
                  >
                    <div className="flex items-center">
                      {isExpanded ? (
                        <ChevronDown size={18} className="text-gray-400 mr-2" />
                      ) : (
                        <ChevronRight size={18} className="text-gray-400 mr-2" />
                      )}
                      <div>
                        <span className="font-medium">{company.companyName}</span>
                        <div className="text-sm text-gray-500">
                          Gebruiker: {company.username} • Laatste login: {company.lastLogin ? formatDateInDutch(new Date(company.lastLogin)) : 'Nooit'}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center text-sm text-gray-500">
                      <MapPin size={16} className="mr-1" />
                      <span>{company.signsCount} borden</span>
                    </div>
                  </div>
                  
                  {isExpanded && (
                    <div className="p-4 border-t">
                      {company.signs.length === 0 ? (
                        <p className="text-sm text-gray-500 text-center py-4">Geen actieve borden</p>
                      ) : (
                        <div className="space-y-2">
                          {company.signs.map(sign => (
                            <div key={sign.id} className="flex justify-between items-start p-2 hover:bg-gray-50 rounded">
                              <div className="flex-1">
                                <p className="text-sm">{formatAddress(sign.address)}</p>
                                <div className="flex items-center mt-1">
                                  <span className={`status-badge status-${sign.status}`}>
                                    {getStatusText(sign.status)}
                                  </span>
                                  <span className="text-xs text-gray-500 ml-2">
                                    Sinds {formatDateInDutch(new Date(sign.updatedAt))}
                                  </span>
                                </div>
                                
                                {/* Show placement details if available */}
                                {sign.placementDetails && (
                                  <div className="text-xs text-blue-600 mt-1">
                                    {sign.placementDetails.specificLocation && (
                                      <div>📍 {sign.placementDetails.specificLocation}</div>
                                    )}
                                    <div>
                                      🔄 {sign.placementDetails.orientation === 'above-ballast' ? 'Boven de ballast' : 'Links van de ballast'}
                                    </div>
                                    {sign.placementDetails.placementImages && sign.placementDetails.placementImages.length > 0 && (
                                      <div className="flex items-center mt-1">
                                        <span>📷 {sign.placementDetails.placementImages.length} plaatsingsafbeelding(en)</span>
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleViewPlacementImages(sign);
                                          }}
                                          className="ml-2 text-blue-600 hover:text-blue-800"
                                          title="Bekijk plaatsingsafbeeldingen"
                                        >
                                          <Eye size={12} />
                                        </button>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex items-center space-x-2">
                                {/* Proof images */}
                                {(sign.proofImages?.placed || sign.proofImages?.removed) && (
                                  <div className="flex items-center space-x-1">
                                    {sign.proofImages?.placed && (
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleViewProofImage(sign.proofImages!.placed!, 'placed', sign.address);
                                        }}
                                        className="w-6 h-6 rounded overflow-hidden border border-green-200"
                                        title="Bekijk bewijs van plaatsing"
                                      >
                                        <div 
                                          style={{
                                            width: '100%',
                                            height: '100%',
                                            backgroundImage: `url(${sign.proofImages.placed})`,
                                            backgroundSize: 'cover',
                                            backgroundPosition: 'center',
                                          }}
                                        ></div>
                                      </button>
                                    )}
                                    {sign.proofImages?.removed && (
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleViewProofImage(sign.proofImages!.removed!, 'removed', sign.address);
                                        }}
                                        className="w-6 h-6 rounded overflow-hidden border border-red-200"
                                        title="Bekijk bewijs van ophaling"
                                      >
                                        <div 
                                          style={{
                                            width: '100%',
                                            height: '100%',
                                            backgroundImage: `url(${sign.proofImages.removed})`,
                                            backgroundSize: 'cover',
                                            backgroundPosition: 'center',
                                          }}
                                        ></div>
                                      </button>
                                    )}
                                  </div>
                                )}
                                
                                {/* Main sign image */}
                                {sign.imageUrl && (
                                  <div className="flex items-center space-x-2">
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleDownloadImage(sign.imageUrl!, sign.address);
                                      }}
                                      className="text-gray-500 hover:text-gray-700"
                                      title="Download afbeelding"
                                    >
                                      <Download size={16} />
                                    </button>
                                    <div className="w-10 h-10 rounded overflow-hidden border border-gray-200">
                                      <div 
                                        style={{
                                          width: '100%',
                                          height: '100%', 
                                          backgroundImage: `url(${sign.imageUrl})`,
                                          backgroundSize: 'cover',
                                          backgroundPosition: 'center',
                                          cursor: 'pointer'
                                        }}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleViewProofImage(sign.imageUrl!, 'placed', sign.address);
                                        }}
                                      ></div>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Image Viewer Modal */}
      <ImageViewerModal
        isOpen={imageViewerState.isOpen}
        onClose={closeImageViewer}
        images={imageViewerState.images}
        currentIndex={imageViewerState.currentIndex}
        onIndexChange={(index) => setImageViewerState(prev => ({ ...prev, currentIndex: index }))}
        title={imageViewerState.title}
        description={imageViewerState.description}
      />
    </div>
  );
}

export default CompanyOverviewTab;