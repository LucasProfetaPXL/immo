import React, { useState } from 'react';
import { useInvoices } from '../../context/InvoiceContext';
import { useSigns } from '../../context/SignsContext';
import { Search, Download, CreditCard, FolderOpen, FileText, AlertTriangle, Send, Calculator } from 'lucide-react';
import { formatAddress } from '../../utils/addressFormatter.tsx';
import { getInvoicesByYear } from '../../lib/invoiceNumbering';
import { calculateTotalAmountDue, calculateForfaitaryCompensation, calculateInterest, processInvoiceFollowUp } from '../../lib/belgianFollowUp';
import toast from 'react-hot-toast';
import { generateInvoicePDF, generateCombinedInvoicePDF } from '../../lib/pdf';

type SubTabType = 'paid' | 'unpaid' | 'invoices' | 'overdue';

function IncomeTab() {
  const { invoices, markInvoiceAsPaid, markInvoiceAsUnpaid, getAllInvoices, getOverdueInvoices } = useInvoices();
  const { getSignById } = useSigns();
  const [activeSubTab, setActiveSubTab] = useState<SubTabType>('unpaid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedYear, setSelectedYear] = useState<string>('');
  const [processingReminders, setProcessingReminders] = useState<Set<string>>(new Set());
  
  // Get all invoices for admin view (no deleted status needed)
  const allInvoices = getAllInvoices();
  const overdueInvoices = getOverdueInvoices();
  
  // Admin sees all invoices regardless of user deletion status
  const allInvoicesForAdmin = allInvoices;
  
  // Filter invoices by status and search query
  const filteredInvoices = allInvoicesForAdmin.filter(invoice => {
    let statusMatch = false;
    
    if (activeSubTab === 'paid') {
      statusMatch = invoice.status === 'paid';
    } else if (activeSubTab === 'unpaid') {
      statusMatch = invoice.status === 'unpaid';
    } else if (activeSubTab === 'overdue') {
      const now = new Date();
      statusMatch = invoice.status === 'unpaid' && new Date(invoice.dueDate) < now;
    }
    
    if (!statusMatch && activeSubTab !== 'invoices') return false;
    
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      invoice.companyName.toLowerCase().includes(query) ||
      invoice.address.toLowerCase().includes(query) ||
      invoice.billingDetails.name.toLowerCase().includes(query) ||
      invoice.billingDetails.email.toLowerCase().includes(query) ||
      (invoice.invoiceNumber && invoice.invoiceNumber.toLowerCase().includes(query))
    );
  });
  
  // Sort by date (newest first)
  const sortedInvoices = [...filteredInvoices].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  // For invoices tab - group by year (including deleted invoices)
  const invoicesByYear = getInvoicesByYear(allInvoicesForAdmin);
  const years = Object.keys(invoicesByYear).sort((a, b) => parseInt(b) - parseInt(a));

  const handleTogglePaymentStatus = (invoiceId: string, currentStatus: 'paid' | 'unpaid') => {
    if (currentStatus === 'unpaid') {
      markInvoiceAsPaid(invoiceId);
      toast.success('Factuur gemarkeerd als betaald');
    } else {
      markInvoiceAsUnpaid(invoiceId);
      toast.success('Factuur gemarkeerd als onbetaald');
    }
  };

  const handleSendReminder = async (invoiceId: string) => {
    if (processingReminders.has(invoiceId)) {
      return; // Already processing
    }

    setProcessingReminders(prev => new Set(prev).add(invoiceId));
    
    try {
      const invoice = allInvoices.find(inv => inv.id === invoiceId);
      if (!invoice) {
        toast.error('Factuur niet gevonden');
        return;
      }

      // Process the follow-up for this specific invoice
      const followUpResult = processInvoiceFollowUp(invoice);
      
      if (followUpResult.needsAction && followUpResult.reminderEmail) {
        // In a real application, you would send the email here
        console.log('📧 Manual reminder sent:', followUpResult.reminderEmail);
        
        // Show success message based on reminder type
        if (followUpResult.actionType === 'first_reminder') {
          toast.success(`Eerste herinnering verstuurd naar ${invoice.billingDetails.email}`);
        } else if (followUpResult.actionType === 'second_reminder') {
          toast.success(`Tweede herinnering verstuurd naar ${invoice.billingDetails.email}`);
        } else if (followUpResult.actionType === 'final_reminder') {
          toast.success(`Laatste herinnering verstuurd naar ${invoice.billingDetails.email}`);
        } else {
          toast.success(`Herinnering verstuurd naar ${invoice.billingDetails.email}`);
        }

        // Force a re-render by updating the invoice context
        // This would normally be handled by the context's processFollowUps function
        if (followUpResult.updatedInvoice) {
          // Update the invoice in the context
          // For now, we'll just show the success message
        }
      } else {
        // Check if we can force a reminder anyway
        const now = new Date();
        const createdDate = new Date(invoice.createdAt);
        const daysOverdue = differenceInDays(now, addDays(createdDate, 30));
        
        if (daysOverdue >= 0) {
          // Force send first reminder
          console.log('📧 Forced reminder sent for invoice:', invoice.invoiceNumber || invoice.id.substring(0, 8));
          toast.success(`Herinnering geforceerd verstuurd naar ${invoice.billingDetails.email}`);
        } else {
          toast('Deze factuur is nog niet vervallen voor een herinnering');
        }
      }
    } catch (error) {
      console.error('Error sending reminder:', error);
      toast.error('Fout bij versturen herinnering');
    } finally {
      setProcessingReminders(prev => {
        const newSet = new Set(prev);
        newSet.delete(invoiceId);
        return newSet;
      });
    }
  };

  const handleDownloadInvoice = async (invoice: any) => {
    try {
      // Re-generate the PDF for download
      if (invoice.signId === 'combined' && invoice.signDetails) {
        // This is a combined invoice - we need the original signs data
        // For now, we'll just download with available data
        const pdfDoc = await generateInvoicePDF(invoice);
        pdfDoc.save(`Factuur_${invoice.invoiceNumber || invoice.id.substring(0, 8)}.pdf`);
      } else {
        const pdfDoc = await generateInvoicePDF(invoice);
        pdfDoc.save(`Factuur_${invoice.invoiceNumber || invoice.id.substring(0, 8)}.pdf`);
      }
      
      toast.success('Factuur download gestart');
    } catch (error) {
      console.error('Error downloading invoice:', error);
      toast.error('Fout bij downloaden van factuur');
    }
  };

  // Calculate total for displayed invoices
  const totalAmount = sortedInvoices.reduce((sum, invoice) => sum + (invoice.totalAmountDue || invoice.amount), 0);

  const renderInvoicesOverview = () => {
    if (selectedYear) {
      const yearInvoices = invoicesByYear[selectedYear] || [];
      const filteredYearInvoices = yearInvoices.filter(invoice => {
        if (!searchQuery) return true;
        const query = searchQuery.toLowerCase();
        return (
          invoice.companyName.toLowerCase().includes(query) ||
          invoice.address.toLowerCase().includes(query) ||
          invoice.billingDetails.name.toLowerCase().includes(query) ||
          (invoice.invoiceNumber && invoice.invoiceNumber.toLowerCase().includes(query))
        );
      });

      return (
        <div>
          <div className="flex items-center mb-4">
            <button
              onClick={() => setSelectedYear('')}
              className="btn btn-secondary mr-4"
            >
              ← Terug naar overzicht
            </button>
            <h4 className="text-lg font-semibold">Facturen {selectedYear}</h4>
            <span className="ml-4 text-sm text-gray-500">
              {filteredYearInvoices.length} facturen
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Factuurnummer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Factuurgegevens
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bedrag & Status
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acties
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredYearInvoices.map(invoice => {
                  return (
                    <tr key={invoice.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">
                          {invoice.invoiceNumber || invoice.id.substring(0, 8)}
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(invoice.createdAt).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{invoice.companyName}</div>
                        <div className="text-sm text-gray-500">{invoice.address}</div>
                        <div className="text-xs text-gray-500">{invoice.billingDetails.name}</div>
                        {/* Show comment/reference if available */}
                        {invoice.billingDetails.reference && invoice.billingDetails.reference.trim() && (
                          <div className="text-xs text-blue-600 mt-1 italic">
                            Opmerking: {invoice.billingDetails.reference}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">€{(invoice.totalAmountDue || invoice.amount).toFixed(2)}</div>
                        <span className={`status-badge ${invoice.status === 'paid' ? 'status-paid' : 'status-invoiced'}`}>
                          {invoice.status === 'paid' ? 'Betaald' : 'Onbetaald'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => handleDownloadInvoice(invoice)}
                          className="btn btn-sm btn-secondary flex items-center"
                        >
                          <Download size={14} className="mr-1" />
                          <span>PDF</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      );
    }

    return (
      <div>
        <h4 className="text-lg font-semibold mb-4">Facturen per Jaar</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {years.map(year => {
            const yearInvoices = invoicesByYear[year];
            const totalAmount = yearInvoices.reduce((sum, inv) => sum + (inv.totalAmountDue || inv.amount), 0);
            const paidAmount = yearInvoices.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + (inv.totalAmountDue || inv.amount), 0);
            
            return (
              <div
                key={year}
                onClick={() => setSelectedYear(year)}
                className="bg-white border border-gray-200 rounded-lg p-6 hover:border-primary-blue cursor-pointer transition-colors"
              >
                <div className="flex items-center mb-3">
                  <FolderOpen size={24} className="text-primary-blue mr-3" />
                  <h5 className="text-lg font-semibold">{year}</h5>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Facturen:</span>
                    <span className="font-medium">{yearInvoices.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Totaal:</span>
                    <span className="font-medium">€{totalAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Betaald:</span>
                    <span className="font-medium text-green-600">€{paidAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Openstaand:</span>
                    <span className="font-medium text-orange-600">€{(totalAmount - paidAmount).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderOverdueDetails = (invoice: any) => {
    const now = new Date();
    const createdDate = new Date(invoice.createdAt);
    const dueDate = new Date(invoice.dueDate);
    const daysOverdue = differenceInDays(now, dueDate);
    
    // Calculate Belgian follow-up details
    const totalAmountDue = calculateTotalAmountDue(invoice);
    const compensation = calculateForfaitaryCompensation(invoice.amount);
    
    let interestAmount = 0;
    if (invoice.firstReminderSent) {
      const reminderDate = new Date(invoice.firstReminderSent);
      const waitingPeriodEnd = addDays(reminderDate, 14);
      const daysLate = differenceInDays(now, waitingPeriodEnd);
      
      if (daysLate > 0) {
        const interest = calculateInterest(invoice.amount, daysLate);
        interestAmount = interest.interestAmount;
      }
    }

    return (
      <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-md">
        <div className="flex items-center mb-2">
          <AlertTriangle size={16} className="text-red-500 mr-2" />
          <span className="text-sm font-medium text-red-700">
            {daysOverdue} dagen te laat
          </span>
        </div>
        
        <div className="text-xs text-red-600 space-y-1">
          <div>Oorspronkelijk bedrag: €{invoice.amount.toFixed(2)}</div>
          {compensation.compensationAmount > 0 && (
            <div>Forfaitaire schadevergoeding: €{compensation.compensationAmount.toFixed(2)}</div>
          )}
          {interestAmount > 0 && (
            <div>Verwijlintresten (12,5%/jaar): €{interestAmount.toFixed(2)}</div>
          )}
          <div className="font-medium border-t border-red-200 pt-1">
            Totaal verschuldigd: €{totalAmountDue.toFixed(2)}
          </div>
        </div>

        <div className="mt-2 text-xs text-red-600">
          {!invoice.firstReminderSent && (
            <div>Status: Eerste herinnering nog niet verstuurd</div>
          )}
          {invoice.firstReminderSent && !invoice.waitingPeriodEnd && (
            <div>Status: Wachttijd van 14 dagen loopt</div>
          )}
          {invoice.waitingPeriodEnd && new Date() > new Date(invoice.waitingPeriodEnd) && (
            <div>Status: Wachttijd verstreken - kosten van toepassing</div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Inkomstenbeheer</h2>
      
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-2 px-4">
            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'unpaid'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => setActiveSubTab('unpaid')}
            >
              <span>Onbetaalde Facturen</span>
              <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs bg-gray-100">
                {allInvoices.filter(inv => inv.status === 'unpaid').length}
              </span>
            </button>
            
            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'overdue'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => setActiveSubTab('overdue')}
            >
              <AlertTriangle size={16} className="mr-2" />
              <span>Te Laat</span>
              <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs bg-red-100 text-red-800">
                {overdueInvoices.length}
              </span>
            </button>
            
            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'paid'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => setActiveSubTab('paid')}
            >
              <span>Betaalde Facturen</span>
              <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs bg-gray-100">
                {allInvoicesForAdmin.filter(inv => inv.status === 'paid').length}
              </span>
            </button>

            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'invoices'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => {
                setActiveSubTab('invoices');
                setSelectedYear('');
              }}
            >
              <FileText size={16} className="mr-2" />
              <span>Facturen</span>
              <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs bg-gray-100">
                {allInvoicesForAdmin.length}
              </span>
            </button>
          </nav>
        </div>
        
        <div className="p-4">
          {activeSubTab === 'invoices' ? (
            renderInvoicesOverview()
          ) : (
            <>
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                  <div className="relative">
                    <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Zoek facturen..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-64"
                    />
                  </div>
                </div>
                
                <div className="bg-gray-50 px-4 py-2 rounded-md">
                  <span className="text-sm text-gray-500 mr-2">Totaal:</span>
                  <span className="font-medium">€{totalAmount.toFixed(2)}</span>
                </div>
              </div>
              
              {sortedInvoices.length === 0 ? (
                <div className="text-center py-10 text-gray-500">
                  <p>Geen {activeSubTab === 'paid' ? 'betaalde' : activeSubTab === 'overdue' ? 'te late' : 'onbetaalde'} facturen gevonden</p>
                </div>
              ) : (
                <div className="fixed-height-container">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Factuurnummer
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Factuurgegevens
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Facturering
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Bedrag & Status
                          </th>
                          <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Acties
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {sortedInvoices.map(invoice => {
                          const sign = getSignById(invoice.signId);
                          const createdDate = new Date(invoice.createdAt);
                          const isOverdue = invoice.status === 'unpaid' && new Date() > new Date(invoice.dueDate);
                          const totalAmountDue = calculateTotalAmountDue(invoice);
                          const isProcessingReminder = processingReminders.has(invoice.id);
                          
                          return (
                            <tr key={invoice.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="font-medium text-gray-900">
                                  {invoice.invoiceNumber || invoice.id.substring(0, 8)}
                                </div>
                                <div className="text-xs text-gray-400">
                                  Aangemaakt {formatDistanceToNow(createdDate, { addSuffix: true })}
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="font-medium text-gray-900">{invoice.companyName}</div>
                                <div className="text-sm text-gray-500">{formatAddress(invoice.address)}</div>
                                {/* Show comment/reference if available */}
                                {invoice.billingDetails.reference && invoice.billingDetails.reference.trim() && (
                                  <div className="text-xs text-blue-600 mt-1 italic">
                                    Opmerking: {invoice.billingDetails.reference}
                                  </div>
                                )}
                                {activeSubTab === 'overdue' && renderOverdueDetails(invoice)}
                              </td>
                              <td className="px-6 py-4">
                                <div className="text-sm text-gray-900">{invoice.billingDetails.name}</div>
                                <div className="text-xs text-gray-500">{invoice.billingDetails.email}</div>
                                <div className="text-xs text-gray-500">
                                  {invoice.billingDetails.vatNumber}
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="font-medium text-gray-900">
                                  €{totalAmountDue.toFixed(2)}
                                  {totalAmountDue !== invoice.amount && (
                                    <div className="text-xs text-gray-500">
                                      (oorspronkelijk €{invoice.amount.toFixed(2)})
                                    </div>
                                  )}
                                </div>
                                <div className="flex items-center mt-1">
                                  <span className={`status-badge ${invoice.status === 'paid' ? 'status-paid' : isOverdue ? 'status-removal-requested' : 'status-invoiced'}`}>
                                    {invoice.status === 'paid' ? 'Betaald' : 'Onbetaald'}
                                    {isOverdue && ' (te laat)'}
                                  </span>
                                  
                                  {invoice.reminderStatus !== 'none' && (
                                    <span className="status-badge status-removal-confirmed ml-2 text-xs">
                                      {invoice.reminderStatus === 'first' ? 'Eerste' : 
                                       invoice.reminderStatus === 'second' ? 'Tweede' : 'Laatste'} herinnering
                                    </span>
                                  )}
                                </div>
                                {invoice.status === 'paid' && invoice.paidAt && (
                                  <div className="text-xs text-gray-500 mt-1">
                                    Betaald {formatDistanceToNow(new Date(invoice.paidAt), { addSuffix: true })}
                                  </div>
                                )}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div className="flex justify-end space-x-2">
                                  <button
                                    onClick={() => handleDownloadInvoice(invoice)}
                                    className="btn btn-sm btn-secondary flex items-center"
                                  >
                                    <Download size={14} className="mr-1" />
                                    <span>PDF</span>
                                  </button>

                                  {invoice.status === 'unpaid' && (
                                    <button
                                      onClick={() => handleSendReminder(invoice.id)}
                                      disabled={isProcessingReminder}
                                      className={`btn btn-sm btn-warning flex items-center ${
                                        isProcessingReminder ? 'opacity-50 cursor-not-allowed' : ''
                                      }`}
                                      title="Verstuur herinnering"
                                    >
                                      <Send size={14} className="mr-1" />
                                      <span>{isProcessingReminder ? 'Versturen...' : 'Herinnering'}</span>
                                    </button>
                                  )}
                                  
                                  <button
                                    onClick={() => handleTogglePaymentStatus(
                                      invoice.id, 
                                      invoice.status as 'paid' | 'unpaid'
                                    )}
                                    className={`btn btn-sm ${
                                      invoice.status === 'unpaid' ? 'btn-success' : 'btn-warning'
                                    } flex items-center`}
                                  >
                                    <CreditCard size={14} className="mr-1" />
                                    <span>{invoice.status === 'unpaid' ? 'Markeer Betaald' : 'Markeer Onbetaald'}</span>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default IncomeTab;