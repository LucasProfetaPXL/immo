import { SignData, SignStatus } from '../types';
import { v4 as uuidv4 } from '../utils/uuid';

// Generate dates in the past
const daysAgo = (days: number) => {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString();
};

const createStatusHistory = (status: SignStatus, baseDaysAgo: number) => {
  const history = [];
  
  switch (status) {
    case 'placed':
      history.push({ status: 'pending', date: daysAgo(baseDaysAgo + 4) });
      history.push({ status: 'confirmed', date: daysAgo(baseDaysAgo + 2) });
      history.push({ status: 'placed', date: daysAgo(baseDaysAgo) });
      break;
      
    case 'removal-requested':
      history.push({ status: 'pending', date: daysAgo(baseDaysAgo + 10) });
      history.push({ status: 'confirmed', date: daysAgo(baseDaysAgo + 8) });
      history.push({ status: 'placed', date: daysAgo(baseDaysAgo + 7) });
      history.push({ status: 'removal-requested', date: daysAgo(baseDaysAgo) });
      break;
      
    case 'removal-confirmed':
      history.push({ status: 'pending', date: daysAgo(baseDaysAgo + 15) });
      history.push({ status: 'confirmed', date: daysAgo(baseDaysAgo + 13) });
      history.push({ status: 'placed', date: daysAgo(baseDaysAgo + 12) });
      history.push({ status: 'removal-requested', date: daysAgo(baseDaysAgo + 2) });
      history.push({ status: 'removal-confirmed', date: daysAgo(baseDaysAgo) });
      break;
      
    case 'removed':
      history.push({ status: 'pending', date: daysAgo(baseDaysAgo + 20) });
      history.push({ status: 'confirmed', date: daysAgo(baseDaysAgo + 18) });
      history.push({ status: 'placed', date: daysAgo(baseDaysAgo + 17) });
      history.push({ status: 'removal-requested', date: daysAgo(baseDaysAgo + 5) });
      history.push({ status: 'removal-confirmed', date: daysAgo(baseDaysAgo + 2) });
      history.push({ status: 'removed', date: daysAgo(baseDaysAgo) });
      break;
      
    default:
      history.push({ status: 'pending', date: daysAgo(baseDaysAgo) });
  }
  
  return history;
};

// Create mock sign data - these will be visible to all users for demo purposes
// In production, each user would start with empty data
export const mockSigns: SignData[] = [
  {
    id: uuidv4(),
    userId: 'demo-user-1', // Demo user ID
    companyName: 'Rue de la Loi 16, 1000 Brussels',
    address: 'Rue de la Loi 16, 1000 Brussels',
    category: 'B',
    lat: 50.8466,
    lng: 4.3699,
    status: 'placed',
    imageUrl: 'https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg?auto=compress&cs=tinysrgb&w=600',
    createdAt: daysAgo(14),
    updatedAt: daysAgo(10),
    placedAt: daysAgo(10),
    statusHistory: createStatusHistory('placed', 10)
  },
  {
    id: uuidv4(),
    userId: 'demo-user-2', // Different demo user ID
    companyName: 'Avenue Louise 143, 1050 Brussels',
    address: 'Avenue Louise 143, 1050 Brussels',
    category: 'B',
    lat: 50.8269,
    lng: 4.3667,
    status: 'removal-requested',
    imageUrl: 'https://images.pexels.com/photos/159306/construction-site-build-construction-work-159306.jpeg?auto=compress&cs=tinysrgb&w=600',
    createdAt: daysAgo(35),
    updatedAt: daysAgo(5),
    placedAt: daysAgo(30),
    removalRequestedAt: daysAgo(5),
    statusHistory: createStatusHistory('removal-requested', 5)
  },
  {
    id: uuidv4(),
    userId: 'demo-user-1', // Same as first demo user
    companyName: 'Rue du Marché aux Herbes 78, 1000 Brussels',
    address: 'Rue du Marché aux Herbes 78, 1000 Brussels',
    category: 'B',
    lat: 50.8462,
    lng: 4.3543,
    status: 'removal-confirmed',
    imageUrl: 'https://images.pexels.com/photos/1546168/pexels-photo-1546168.jpeg?auto=compress&cs=tinysrgb&w=600',
    createdAt: daysAgo(45),
    updatedAt: daysAgo(3),
    placedAt: daysAgo(40),
    removalRequestedAt: daysAgo(7),
    statusHistory: createStatusHistory('removal-confirmed', 3)
  }
];

// Create demo users
export const demoUsers = {
  "admin": { password: "admin123", isAdmin: true }
};