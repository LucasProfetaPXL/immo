import React from 'react';
import { MapPin, Trash2, Receipt, List, Home } from 'lucide-react';

type UserTabType = 'dashboard' | 'place-order' | 'remove-signs' | 'sold-signs' | 'costs' | 'status-overview';

interface UserNavigationProps {
  activeTab: UserTabType;
  onTabChange: (tab: UserTabType) => void;
}

function UserNavigation({ activeTab, onTabChange }: UserNavigationProps) {
  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800">Bordbeheer</h2>
      </div>
      
      <nav className="p-4 space-y-2">
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'dashboard' ? 'active' : ''}`}
          onClick={() => onTabChange('dashboard')}
        >
          <Home size={18} className="mr-3" />
          <span>Dashboard</span>
        </button>
        
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'place-order' ? 'active' : ''}`}
          onClick={() => onTabChange('place-order')}
        >
          <MapPin size={18} className="mr-3" />
          <span>Borden Plaatsen</span>
        </button>
        
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'remove-signs' ? 'active' : ''}`}
          onClick={() => onTabChange('remove-signs')}
        >
          <Trash2 size={18} className="mr-3" />
          <span>Borden Verwijderen</span>
        </button>
        
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'sold-signs' ? 'active' : ''}`}
          onClick={() => onTabChange('sold-signs')}
        >
          <Receipt size={18} className="mr-3" />
          <span>Verkochte Borden</span>
        </button>
        
        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'costs' ? 'active' : ''}`}
          onClick={() => onTabChange('costs')}
        >
          <Receipt size={18} className="mr-3" />
          <span>Kosten</span>
        </button>

        <button
          className={`w-full nav-link flex items-center justify-start ${activeTab === 'status-overview' ? 'active' : ''}`}
          onClick={() => onTabChange('status-overview')}
        >
          <List size={18} className="mr-3" />
          <span>Status Overzicht</span>
        </button>
      </nav>
    </div>
  );
}

export default UserNavigation;