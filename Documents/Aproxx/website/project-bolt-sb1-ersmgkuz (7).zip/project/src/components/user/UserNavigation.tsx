import React from 'react';
import { MapPin, Trash2, Receipt, List } from 'lucide-react';

type UserTabType = 'place-order' | 'remove-signs' | 'costs' | 'status-overview';

interface UserNavigationProps {
  activeTab: UserTabType;
  onTabChange: (tab: UserTabType) => void;
}

function UserNavigation({ activeTab, onTabChange }: UserNavigationProps) {
  return (
    <nav className="flex space-x-4 overflow-x-auto pb-2">
      <button
        className={`nav-link flex items-center ${activeTab === 'place-order' ? 'active' : ''}`}
        onClick={() => onTabChange('place-order')}
      >
        <MapPin size={18} className="mr-2" />
        <span>Bestelling Plaatsen</span>
      </button>
      
      <button
        className={`nav-link flex items-center ${activeTab === 'remove-signs' ? 'active' : ''}`}
        onClick={() => onTabChange('remove-signs')}
      >
        <Trash2 size={18} className="mr-2" />
        <span>Borden Verwijderen</span>
      </button>
      
      <button
        className={`nav-link flex items-center ${activeTab === 'costs' ? 'active' : ''}`}
        onClick={() => onTabChange('costs')}
      >
        <Receipt size={18} className="mr-2" />
        <span>Kosten</span>
      </button>

      <button
        className={`nav-link flex items-center ${activeTab === 'status-overview' ? 'active' : ''}`}
        onClick={() => onTabChange('status-overview')}
      >
        <List size={18} className="mr-2" />
        <span>Status Overzicht</span>
      </button>
    </nav>
  );
}

export default UserNavigation;