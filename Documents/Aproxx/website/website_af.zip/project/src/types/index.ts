// Sign Types
export type SignStatus = 
  | 'pending'
  | 'confirmed'
  | 'placed'
  | 'removal-requested'
  | 'removal-confirmed'
  | 'removed'
  | 'trashed'
  | 'deleted';

export type SoldStatus = 'none' | 'requested' | 'confirmed' | 'placed';

export type InvoiceStatus = 'invoiced' | 'pending' | 'unpaid' | 'paid';
export type ReminderStatus = 'none' | 'first' | 'second' | 'final';

export interface StatusHistoryItem {
  status: string;
  date: string;
  proofImage?: string; // Add proof image for status changes
  employeeId?: string; // Track which employee made the change
}

// Placement Details Interface
export interface PlacementDetails {
  specificLocation?: string; // Where exactly in the front yard
  orientation?: string; // 'above-ballast' or 'left-of-ballast'
  placementImages?: string[]; // URLs of uploaded images (max 3)
  placementImageFiles?: File[]; // Temporary storage for files before upload
}

export interface SignData {
  id: string;
  userId?: string; // Associate sign with user
  companyName: string;
  address: string;
  category: string;
  boardType?: string; // Add board type field
  lat: number;
  lng: number;
  imageUrl?: string;
  status: SignStatus;
  invoiceStatus?: 'pending' | 'invoiced';
  soldStatus?: SoldStatus; // Add sold status
  soldRequestedAt?: string;
  createdAt: string;
  updatedAt: string;
  placedAt?: string;
  removalRequestedAt?: string;
  trashedAt?: string;
  statusHistory: StatusHistoryItem[];
  adminNotes?: string;
  billingDetails?: BillingDetails;
  placementDetails?: PlacementDetails; // Add placement details
  proofImages?: { // Add proof images for different statuses
    placed?: string;
    removed?: string;
    sold?: string;
  };
}

export interface BillingDetails {
  name: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  vatNumber: string;
  email: string;
  reference?: string;
}

export interface Company {
  name: string;
  signsCount: number;
  expanded?: boolean;
}

// Board Type Pricing
export interface BoardTypePricing {
  boardType: string;
  baseCost: number;
  dailyCost: number;
}

// Pricing Types
export interface PricingSettings {
  useCustomPricing: boolean;
  baseCost: number; // Standard: €220 for Lichtbord (batterij)
  dailyCost: number; // Standard: €4 for Lichtbord (batterij)
  boardTypePricing?: BoardTypePricing[]; // Custom pricing per board type
}

export interface UserAccount {
  id: string;
  companyName: string;
  username: string;
  password: string;
  createdAt: string;
  lastLogin?: string;
  pricingSettings: PricingSettings;
  role?: 'user' | 'employee'; // Add role field
  parentUserId?: string; // For employees, link to parent user
  inventory?: number; // Available boards for this user
}

// Inventory management
export interface InventorySettings {
  totalBoards: number; // Total boards available in system
  allocatedBoards: Record<string, number>; // Boards allocated per user
}
// Invoice Types
export interface Invoice {
  id: string;
  invoiceNumber?: string; // New field for proper invoice numbering
  signId: string;
  userId?: string; // Associate invoice with user
  companyName: string;
  address: string;
  billingDetails: BillingDetails;
  amount: number;
  status: InvoiceStatus;
  reminderStatus: ReminderStatus;
  createdAt: string;
  paidAt?: string;
  dueDate: string;
  lastReminderSent?: string;
  deletedAt?: string;
  days: number;
  signDetails?: Array<{
    id: string;
    address: string;
    days: number;
    cost: number;
    boardType?: string; // Add board type to sign details
  }>;
  // Belgian follow-up system fields
  firstReminderSent?: string;
  waitingPeriodEnd?: string;
  interestStartDate?: string;
  totalInterest?: number;
  forfaitaryCompensation?: number;
  totalAmountDue?: number;
  // Pricing information used for this invoice
  pricingUsed?: {
    baseCost: number;
    dailyCost: number;
    boardType?: string; // Track which board type pricing was used
  };
}

// Map Types
export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  status: SignStatus;
  address: string;
  companyName: string;
  boardType?: string;
}

// Auth Types
export interface User {
  username: string;
  isAdmin: boolean;
  isEmployee?: boolean;
  parentUserId?: string;
}

// Belgian Follow-up System Types
export interface ReminderEmail {
  to: string;
  subject: string;
  body: string;
  invoiceId: string;
  reminderType: 'first' | 'second' | 'final';
}

export interface InterestCalculation {
  principal: number;
  rate: number; // 12.5% per year
  daysLate: number;
  interestAmount: number;
}

export interface ForfaitaryCompensation {
  invoiceAmount: number;
  compensationAmount: number;
  tier: 'tier1' | 'tier2' | 'tier3'; // ≤€150, €150.01-€500, >€500
}