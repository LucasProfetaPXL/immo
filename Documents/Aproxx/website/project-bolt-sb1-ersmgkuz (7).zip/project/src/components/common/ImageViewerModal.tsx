import React from 'react';
import { X, Download, ChevronLeft, ChevronRight } from 'lucide-react';
import toast from 'react-hot-toast';

interface ImageViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  images: string[];
  currentIndex: number;
  onIndexChange: (index: number) => void;
  title?: string;
  description?: string;
}

function ImageViewerModal({ 
  isOpen, 
  onClose, 
  images, 
  currentIndex, 
  onIndexChange, 
  title = "Afbeelding bekijken",
  description 
}: ImageViewerModalProps) {
  if (!isOpen || images.length === 0) return null;

  const currentImage = images[currentIndex];
  const hasMultipleImages = images.length > 1;

  const handlePrevious = () => {
    if (currentIndex > 0) {
      onIndexChange(currentIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < images.length - 1) {
      onIndexChange(currentIndex + 1);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    } else if (e.key === 'ArrowLeft' && hasMultipleImages) {
      handlePrevious();
    } else if (e.key === 'ArrowRight' && hasMultipleImages) {
      handleNext();
    }
  };

  const handleDownload = () => {
    try {
      const link = document.createElement('a');
      link.href = currentImage;
      link.download = `afbeelding_${currentIndex + 1}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success('Download gestart');
    } catch (error) {
      console.error('Download error:', error);
      window.open(currentImage, '_blank');
      toast.success('Afbeelding geopend in nieuw tabblad');
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-90"
      onKeyDown={handleKeyDown}
      tabIndex={0}
    >
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-black bg-opacity-50 p-4">
        <div className="flex items-center justify-between text-white">
          <div>
            <h3 className="text-lg font-semibold">{title}</h3>
            {description && (
              <p className="text-sm text-gray-300 mt-1">{description}</p>
            )}
            {hasMultipleImages && (
              <p className="text-sm text-gray-400 mt-1">
                {currentIndex + 1} van {images.length}
              </p>
            )}
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={handleDownload}
              className="p-2 bg-white bg-opacity-20 rounded-full hover:bg-opacity-30 transition-colors"
              title="Download afbeelding"
            >
              <Download size={20} />
            </button>
            
            <button
              onClick={onClose}
              className="p-2 bg-white bg-opacity-20 rounded-full hover:bg-opacity-30 transition-colors"
              title="Sluiten (Esc)"
            >
              <X size={20} />
            </button>
          </div>
        </div>
      </div>

      {/* Navigation arrows */}
      {hasMultipleImages && (
        <>
          <button
            onClick={handlePrevious}
            disabled={currentIndex === 0}
            className={`absolute left-4 top-1/2 transform -translate-y-1/2 z-10 p-3 bg-black bg-opacity-50 rounded-full text-white transition-all ${
              currentIndex === 0 
                ? 'opacity-30 cursor-not-allowed' 
                : 'hover:bg-opacity-70'
            }`}
            title="Vorige afbeelding (←)"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button
            onClick={handleNext}
            disabled={currentIndex === images.length - 1}
            className={`absolute right-4 top-1/2 transform -translate-y-1/2 z-10 p-3 bg-black bg-opacity-50 rounded-full text-white transition-all ${
              currentIndex === images.length - 1 
                ? 'opacity-30 cursor-not-allowed' 
                : 'hover:bg-opacity-70'
            }`}
            title="Volgende afbeelding (→)"
          >
            <ChevronRight size={24} />
          </button>
        </>
      )}

      {/* Main image */}
      <div className="relative max-w-[90vw] max-h-[90vh] flex items-center justify-center">
        <img 
          src={currentImage} 
          alt={`Afbeelding ${currentIndex + 1}`}
          className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
          style={{ maxHeight: 'calc(90vh - 100px)' }} // Account for header
        />
      </div>

      {/* Thumbnail strip for multiple images */}
      {hasMultipleImages && images.length <= 10 && (
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-10">
          <div className="flex space-x-2 bg-black bg-opacity-50 p-3 rounded-lg">
            {images.map((image, index) => (
              <button
                key={index}
                onClick={() => onIndexChange(index)}
                className={`w-16 h-16 rounded-md overflow-hidden border-2 transition-all ${
                  index === currentIndex 
                    ? 'border-white' 
                    : 'border-transparent hover:border-gray-400'
                }`}
              >
                <img 
                  src={image} 
                  alt={`Thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Click outside to close */}
      <div 
        className="absolute inset-0 -z-10"
        onClick={onClose}
      />
    </div>
  );
}

export default ImageViewerModal;