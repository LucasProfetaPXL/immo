# Complete Supabase Setup Guide

Dit document bevat alle stappen om de Sign Management System applicatie te configureren met een nieuwe Supabase account.

## 📋 Vereisten

- Een Supabase account (gratis tier is voldoende)
- Toegang tot de Supabase Dashboard
- De applicatie broncode

## 🚀 Stap-voor-stap Setup

### 1. Nieuw Supabase Project Aanmaken

1. Ga naar [https://supabase.com/dashboard](https://supabase.com/dashboard)
2. Klik op **"New Project"**
3. Kies een **Organization** (of maak een nieuwe aan)
4. Vul de project details in:
   - **Name**: `sign-management-system` (of een naam naar keuze)
   - **Database Password**: Kies een sterk wachtwoord (bewaar dit goed!)
   - **Region**: Kies de dichtstbijzijnde regio (bijv. `West EU (Ireland)`)
5. Klik **"Create new project"**
6. Wacht tot het project volledig is opgezet (kan 1-2 minuten duren)

### 2. Database Schema Installeren

1. Ga naar **SQL Editor** in je Supabase Dashboard
2. Klik op **"New query"**
3. Kopieer de volledige inhoud van `supabase/migrations/20250101000001_complete_setup.sql`
4. Plak de SQL code in de editor
5. Klik **"Run"** om de migratie uit te voeren
6. Controleer dat er geen errors zijn (je zou "Success" moeten zien)

### 3. Environment Variables Configureren

1. Ga naar **Settings** → **API** in je Supabase Dashboard
2. Kopieer de volgende waarden:
   - **Project URL** (bijv. `https://abcdefghijklmnop.supabase.co`)
   - **anon public key** (lange string die begint met `eyJ...`)
   - **service_role key** (andere lange string die begint met `eyJ...`)

3. Maak een `.env` bestand aan in de root van je project:

```env
VITE_SUPABASE_URL=https://jouwprojectid.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**⚠️ BELANGRIJK**: Vervang de waarden met je eigen project credentials!

### 4. Storage Bucket Verificatie

De migratie zou automatisch de storage bucket moeten hebben aangemaakt, maar controleer dit:

1. Ga naar **Storage** in je Supabase Dashboard
2. Controleer dat er een bucket genaamd **"images"** bestaat
3. Controleer dat de bucket **Public** is (toggle moet aan staan)
4. Ga naar **Storage** → **Policies**
5. Controleer dat er 4 policies bestaan voor `storage.objects`:
   - `Allow authenticated uploads`
   - `Allow public downloads`
   - `Allow authenticated deletes`
   - `Allow authenticated updates`

### 5. Authentication Configureren

1. Ga naar **Authentication** → **Settings** in je Supabase Dashboard
2. Onder **Site URL**, voeg toe:
   - `http://localhost:5173` (voor development)
   - Je productie URL (indien van toepassing)
3. Onder **Redirect URLs**, voeg toe:
   - `http://localhost:5173/**`
   - Je productie URL met wildcard (indien van toepassing)

### 6. Database Verificatie

Controleer dat alle tabellen correct zijn aangemaakt:

1. Ga naar **Table Editor** in je Supabase Dashboard
2. Je zou de volgende tabellen moeten zien:
   - `users` - Gebruikersaccounts en metadata
   - `signs` - Bord plaatsing en beheer data
   - `billing_details` - Factuurgegevens
   - `invoices` - Factuur beheer met Belgisch opvolgsysteem
   - `images` - Afbeelding metadata en storage referenties

### 7. RLS (Row Level Security) Verificatie

1. Ga naar **Authentication** → **Policies**
2. Controleer dat alle tabellen RLS policies hebben:
   - Elke tabel zou minimaal SELECT, INSERT, UPDATE policies moeten hebben
   - Users kunnen alleen hun eigen data zien en bewerken

## 🧪 Applicatie Testen

1. Start de applicatie: `npm run dev`
2. Ga naar `http://localhost:5173`
3. Test de volgende functionaliteiten:
   - **Login systeem** (admin/admin123 voor admin toegang)
   - **Gebruiker aanmaken** via admin panel
   - **Bord plaatsing** via gebruiker account
   - **Afbeelding upload** (test met een kleine afbeelding)
   - **Factuur generatie**

## 🔧 Troubleshooting

### Storage Upload Errors

Als je errors krijgt bij het uploaden van afbeeldingen:

1. Controleer dat de `images` bucket bestaat en public is
2. Controleer de storage policies in **Storage** → **Policies**
3. Voer deze SQL uit in de **SQL Editor** als backup:

```sql
-- Reset storage policies
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated deletes" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated updates" ON storage.objects;

CREATE POLICY "Allow authenticated uploads" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow public downloads" ON storage.objects
  FOR SELECT TO public
  USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated deletes" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated updates" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'images')
  WITH CHECK (bucket_id = 'images');
```

### Authentication Errors

Als je problemen hebt met inloggen:

1. Controleer je environment variables in `.env`
2. Controleer dat de Site URL en Redirect URLs correct zijn ingesteld
3. Controleer de browser console voor specifieke error berichten

### Database Connection Errors

Als de applicatie geen verbinding kan maken:

1. Controleer je `VITE_SUPABASE_URL` in `.env`
2. Controleer dat je project actief is in de Supabase Dashboard
3. Controleer je internetverbinding

## 📊 Database Schema Overzicht

### Tabellen

- **users**: Gebruikersaccounts met rollen (admin/user/employee) en pricing instellingen
- **signs**: Borden met locatie, status, afbeeldingen en placement details
- **billing_details**: Factuurgegevens per gebruiker
- **invoices**: Facturen met Belgisch opvolgsysteem (herinneringen, rente, etc.)
- **images**: Metadata voor geüploade afbeeldingen

### Storage

- **images bucket**: Publieke bucket voor alle afbeeldingen (borden, placement photos, proof images)

### Security

- **Row Level Security (RLS)**: Gebruikers kunnen alleen hun eigen data zien
- **Storage Policies**: Authenticated users kunnen uploaden, iedereen kan downloaden
- **API Keys**: Anon key voor frontend, service role key voor admin operaties

## 🎯 Productie Deployment

Voor productie deployment:

1. Update de Site URL en Redirect URLs in Supabase Authentication settings
2. Voeg je productie domain toe aan de allowed origins
3. Update je environment variables met de productie URLs
4. Overweeg het upgraden naar een betaald Supabase plan voor meer storage en bandwidth

## 📞 Support

Als je problemen ondervindt:

1. Controleer de browser console voor error berichten
2. Controleer de Supabase Dashboard logs
3. Controleer dat alle environment variables correct zijn ingesteld
4. Controleer dat alle migraties succesvol zijn uitgevoerd

De applicatie zou nu volledig functioneel moeten zijn met je nieuwe Supabase account!