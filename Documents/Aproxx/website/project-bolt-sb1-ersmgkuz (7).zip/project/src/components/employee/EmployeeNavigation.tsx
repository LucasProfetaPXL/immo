import React from 'react';
import { MapPin, Trash2 } from 'lucide-react';

type EmployeeTabType = 'place-signs' | 'remove-signs';

interface EmployeeNavigationProps {
  activeTab: EmployeeTabType;
  onTabChange: (tab: EmployeeTabType) => void;
}

function EmployeeNavigation({ activeTab, onTabChange }: EmployeeNavigationProps) {
  return (
    <nav className="flex space-x-4 overflow-x-auto pb-2">
      <button
        className={`nav-link flex items-center ${activeTab === 'place-signs' ? 'active' : ''}`}
        onClick={() => onTabChange('place-signs')}
      >
        <MapPin size={18} className="mr-2" />
        <span>Borden Plaatsen</span>
      </button>
      
      <button
        className={`nav-link flex items-center ${activeTab === 'remove-signs' ? 'active' : ''}`}
        onClick={() => onTabChange('remove-signs')}
      >
        <Trash2 size={18} className="mr-2" />
        <span>Borden Verwijderen</span>
      </button>
    </nav>
  );
}

export default EmployeeNavigation;