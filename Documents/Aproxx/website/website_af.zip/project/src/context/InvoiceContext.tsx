import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { v4 as uuidv4 } from '../utils/uuid';
import { Invoice, InvoiceStatus, SignData } from '../types';
import { useSigns } from './SignsContext';
import { addDays, isAfter } from 'date-fns';
import { calculateSignCost, calculateSignCostWithPricing, getUserPricing } from '../utils/costCalculator';
import { generateInvoicePDF, generateCombinedInvoicePDF } from '../lib/pdf';
import { getNextInvoiceNumber } from '../lib/invoiceNumbering';
import { processInvoiceFollowUp } from '../lib/belgianFollowUp'; 
import toast from 'react-hot-toast';

// Local storage keys
const STORAGE_KEY_INVOICES = 'allInvoices';
const STORAGE_KEY_BILLING_DETAILS_PREFIX = 'userBillingDetails_';

interface InvoiceContextType {
  invoices: Invoice[];
  generateInvoice: (signId: string, billingDetails: any) => Promise<string>;
  generateAllInvoices: (billingDetails: any) => Promise<string[]>;
  markInvoiceAsPaid: (invoiceId: string) => void;
  markInvoiceAsUnpaid: (invoiceId: string) => void;
  getInvoiceById: (invoiceId: string) => Invoice | undefined;
  getInvoicesByStatus: (status: InvoiceStatus) => Invoice[];
  getUserBillingDetails: () => any;
  setUserBillingDetails: (details: any) => void;
  getAllInvoices: () => Invoice[]; // For admin access
  processFollowUps: () => void; // Manual trigger for follow-ups
  getOverdueInvoices: () => Invoice[];
  sendReminder: (invoiceId: string) => void;
}

const InvoiceContext = createContext<InvoiceContextType | undefined>(undefined);

export function InvoiceProvider({ children }: { children: ReactNode }) {
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const [isInvoicesLoaded, setIsInvoicesLoaded] = useState(false);
  const [userBillingDetails, setUserBillingDetails] = useState<any>(null);
  const [isBillingDetailsLoaded, setIsBillingDetailsLoaded] = useState(false);
  const { getSignById, updateSign, getAllSignsIncludingHidden } = useSigns(); // Use hidden signs for invoices

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  // Filter invoices for current user (unless admin)
  const getFilteredInvoices = () => {
    const user = getCurrentUser();
    if (!user) return [];
    
    if (user.isAdmin) {
      return allInvoices; // Admin sees all invoices
    }
    
    // Regular users only see their own invoices
    return allInvoices.filter(invoice => invoice.userId === user.id);
  };


  // Load invoices from localStorage
  useEffect(() => {
    if (!isInvoicesLoaded) {
      console.log('🔄 Loading invoices from localStorage...');
      const savedInvoices = localStorage.getItem(STORAGE_KEY_INVOICES);
      if (savedInvoices) {
        try {
          const parsedInvoices = JSON.parse(savedInvoices);
          console.log(`✅ Loaded ${parsedInvoices.length} invoices from localStorage`);
          setAllInvoices(parsedInvoices);
        } catch (error) {
          console.error('❌ Error loading invoices:', error);
          setAllInvoices([]);
        }
      } else {
        console.log('ℹ️ No invoices found in localStorage');
        setAllInvoices([]);
      }
      setIsInvoicesLoaded(true);
    }
  }, [isInvoicesLoaded]);

  // Save invoices to localStorage
  useEffect(() => {
    if (isInvoicesLoaded) {
      console.log(`💾 Saving ${allInvoices.length} invoices to localStorage`);
      localStorage.setItem(STORAGE_KEY_INVOICES, JSON.stringify(allInvoices));
    }
  }, [allInvoices, isInvoicesLoaded]);


  // Load saved billing details from localStorage (user-specific)
  useEffect(() => {
    if (!isBillingDetailsLoaded) {
      const user = getCurrentUser();
      if (user && !user.isAdmin) {
        console.log(`🔄 Loading billing details for user ${user.id}...`);
        const savedBillingDetails = localStorage.getItem(`${STORAGE_KEY_BILLING_DETAILS_PREFIX}${user.id}`);
        if (savedBillingDetails) {
          try {
            const parsedBillingDetails = JSON.parse(savedBillingDetails);
            console.log('✅ Loaded billing details from localStorage');
            setUserBillingDetails(parsedBillingDetails);
          } catch (error) {
            console.error('❌ Error loading billing details:', error);
            setUserBillingDetails(null);
          }
        } else {
          console.log('ℹ️ No billing details found for this user');
          setUserBillingDetails(null);
        }
      }
      setIsBillingDetailsLoaded(true);
    }
  }, [isBillingDetailsLoaded]);

  // Save billing details to localStorage when updated (user-specific)
  useEffect(() => {
    if (isBillingDetailsLoaded && userBillingDetails) {
      const user = getCurrentUser();
      if (user && !user.isAdmin) {
        console.log(`💾 Saving billing details for user ${user.id}`);
        try {
          localStorage.setItem(`${STORAGE_KEY_BILLING_DETAILS_PREFIX}${user.id}`, JSON.stringify(userBillingDetails));
        } catch (error) {
          console.error('❌ Error saving billing details:', error);
        }
      }
    }
  }, [userBillingDetails, isBillingDetailsLoaded]);

  // Process follow-ups every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      processFollowUps();
    }, 5 * 60 * 1000); // 5 minutes

    // Also run on component mount
    processFollowUps();

    return () => clearInterval(interval);
  }, [allInvoices]);

  const processFollowUps = () => {
    setAllInvoices(prevInvoices => {
      const updatedInvoices = [...prevInvoices];
      let hasUpdates = false;

      prevInvoices.forEach((invoice, index) => {
        const followUpResult = processInvoiceFollowUp(invoice);
        
        if (followUpResult.needsAction && followUpResult.updatedInvoice) {
          updatedInvoices[index] = {
            ...invoice,
            ...followUpResult.updatedInvoice
          };
          hasUpdates = true;

          // In a real application, you would send the email here
          if (followUpResult.reminderEmail) {
            console.log('📧 Reminder email would be sent:', followUpResult.reminderEmail);
            
            // Show notification to user about reminder being sent
            if (followUpResult.actionType === 'first_reminder') {
              toast.success(`Eerste herinnering verstuurd voor factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`);
            } else if (followUpResult.actionType === 'second_reminder') {
              toast.warning(`Tweede herinnering verstuurd voor factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`);
            } else if (followUpResult.actionType === 'final_reminder') {
              toast.error(`Laatste herinnering verstuurd voor factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`);
            }
          }
        }
      });

      return hasUpdates ? updatedInvoices : prevInvoices;
    });
  };

  const generateInvoice = async (signId: string, billingDetails: any): Promise<string> => {
    console.log(`📝 Generating invoice for sign: ${signId}`);
    const user = getCurrentUser();
    if (!user || user.isAdmin) {
      throw new Error('Only regular users can generate invoices');
    }

    const sign = getSignById(signId);
    
    if (!sign) {
      throw new Error('Sign not found');
    }
    
    // Check if invoice already exists for this sign
    const existingInvoice = allInvoices.find(inv => inv.signId === signId);
    if (existingInvoice) {
      return existingInvoice.id;
    }
    
    // Get user-specific pricing
    const userPricing = getUserPricing(user.id);
    
    // Calculate sign cost with user pricing
    const totalCost = calculateSignCost(sign);
    
    // Calculate days active
    let days = 0;
    if (sign.placedAt && sign.removalRequestedAt) {
      const placedDate = new Date(sign.placedAt);
      const removalDate = new Date(sign.removalRequestedAt);
      days = Math.max(0, Math.floor(
        (removalDate.getTime() - placedDate.getTime()) / (1000 * 60 * 60 * 24)
      )) + 1; // +1 to include both days
    }
    
    const invoiceId = uuidv4();
    const invoiceNumber = getNextInvoiceNumber(); // Global invoice numbering
    
    const newInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber,
      signId,
      userId: user.id, // Associate invoice with current user
      companyName: sign.companyName,
      address: sign.address,
      billingDetails,
      amount: totalCost,
      status: 'unpaid',
      reminderStatus: 'none',
      createdAt: new Date().toISOString(),
      dueDate: addDays(new Date(), 30).toISOString(),
      days,
      // Belgian follow-up system fields
      totalAmountDue: totalCost, // Initially same as amount
      // Store pricing used for this invoice
      pricingUsed: {
        baseCost: userPricing.baseCost,
        dailyCost: userPricing.dailyCost
      }
    };
    
    setAllInvoices(prev => [...prev, newInvoice]);
    
    // Update sign status to invoiced
    updateSign(signId, { 
      invoiceStatus: 'invoiced',
      updatedAt: new Date().toISOString()
    });
    
    // Generate and download PDF
    try {
      const pdfDoc = await generateInvoicePDF(newInvoice);
      pdfDoc.save(`Factuur_${invoiceNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      // Continue with invoice creation even if PDF fails
    }
    
    // Save billing details for future use if not already saved (user-specific)
    if (!userBillingDetails) {
      setUserBillingDetails(billingDetails);
    }
    
    return invoiceId;
  };

  const generateAllInvoices = async (billingDetails: any): Promise<string[]> => {
    console.log('📝 Generating invoices for all eligible signs');
    const user = getCurrentUser();
    if (!user || user.isAdmin) {
      throw new Error('Only regular users can generate invoices');
    }

    const userSigns = getAllSignsIncludingHidden().filter(sign => sign.userId === user.id); // Get user's signs including hidden
    const eligibleSigns = userSigns.filter(sign => 
      (sign.status === 'removal-requested' || sign.status === 'removal-confirmed' || sign.status === 'removed') && 
      !sign.invoiceStatus
    );
    
    if (eligibleSigns.length === 0) {
      return [];
    }
    
    // Get user-specific pricing
    const userPricing = getUserPricing(user.id);
    
    // Create one combined invoice for all eligible signs
    const invoiceId = uuidv4();
    const invoiceNumber = getNextInvoiceNumber(); // Global invoice numbering
    
    // Calculate total amount and prepare sign details
    let totalAmount = 0;
    const signDetails = eligibleSigns.map(sign => {
      const cost = calculateSignCost(sign);
      totalAmount += cost;
      
      let days = 0;
      if (sign.placedAt && sign.removalRequestedAt) {
        const placedDate = new Date(sign.placedAt);
        const removalDate = new Date(sign.removalRequestedAt);
        days = Math.max(0, Math.floor(
          (removalDate.getTime() - placedDate.getTime()) / (1000 * 60 * 60 * 24)
        )) + 1;
      }
      
      return {
        id: sign.id,
        address: sign.address,
        days,
        cost
      };
    });
    
    // Create combined invoice
    const combinedInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber,
      signId: 'combined', // Special identifier for combined invoices
      userId: user.id, // Associate invoice with current user
      companyName: 'Gecombineerde Factuur',
      address: `${eligibleSigns.length} borden`,
      billingDetails,
      amount: totalAmount,
      status: 'unpaid',
      reminderStatus: 'none',
      createdAt: new Date().toISOString(),
      dueDate: addDays(new Date(), 30).toISOString(),
      days: 0, // Not applicable for combined invoice
      signDetails, // Add sign details for PDF generation
      // Belgian follow-up system fields
      totalAmountDue: totalAmount, // Initially same as amount
      // Store pricing used for this invoice
      pricingUsed: {
        baseCost: userPricing.baseCost,
        dailyCost: userPricing.dailyCost
      }
    };
    
    setAllInvoices(prev => [...prev, combinedInvoice]);
    
    // Update all signs to invoiced status
    eligibleSigns.forEach(sign => {
      updateSign(sign.id, { 
        invoiceStatus: 'invoiced',
        updatedAt: new Date().toISOString()
      });
    });
    
    // Generate and download combined PDF
    try {
      const pdfDoc = await generateCombinedInvoicePDF(combinedInvoice, eligibleSigns);
      pdfDoc.save(`Gecombineerde_Factuur_${invoiceNumber}.pdf`);
    } catch (error) {
      console.error('Error generating combined PDF:', error);
    }
    
    // Save billing details for future use if not already saved (user-specific)
    if (!userBillingDetails) {
      setUserBillingDetails(billingDetails);
    }
    
    return [invoiceId];
  };

  const markInvoiceAsPaid = (invoiceId: string) => {
    console.log(`💰 Marking invoice as paid: ${invoiceId}`);
    setAllInvoices(prevInvoices => 
      prevInvoices.map(invoice => 
        invoice.id === invoiceId 
          ? { 
              ...invoice, 
              status: 'paid', 
              paidAt: new Date().toISOString(),
              reminderStatus: 'none'
            } 
          : invoice
      )
    );
  };

  const markInvoiceAsUnpaid = (invoiceId: string) => {
    console.log(`⚠️ Marking invoice as unpaid: ${invoiceId}`);
    setAllInvoices(prevInvoices => 
      prevInvoices.map(invoice => 
        invoice.id === invoiceId 
          ? { 
              ...invoice, 
              status: 'unpaid', 
              paidAt: undefined
            } 
          : invoice
      )
    );
  };




  const getInvoiceById = (invoiceId: string) => {
    const user = getCurrentUser();
    
    // Admin can see all invoices including deleted ones
    if (user && user.isAdmin) {
      return allInvoices.find(inv => inv.id === invoiceId);
    }
    
    // Regular users only see their own invoices
    const filteredInvoices = getFilteredInvoices();
    
    return filteredInvoices.find(inv => inv.id === invoiceId);
  };

  const getInvoicesByStatus = (status: InvoiceStatus) => {
    const filteredInvoices = getFilteredInvoices();
    return filteredInvoices.filter(inv => inv.status === status);
  };

  const getAllInvoices = () => {
    return allInvoices; // For admin access to all invoices
  };


  const getOverdueInvoices = () => {
    const now = new Date();
    const filteredInvoices = getFilteredInvoices();
    return filteredInvoices.filter(invoice => 
      invoice.status === 'unpaid' && 
      isAfter(now, new Date(invoice.dueDate))
    );
  };

  const sendReminder = (invoiceId: string) => {
    console.log(`📧 Sending reminder for invoice: ${invoiceId}`);
    const invoice = allInvoices.find(inv => inv.id === invoiceId);
    if (!invoice) return;

    const followUpResult = processInvoiceFollowUp(invoice);
    
    if (followUpResult.needsAction && followUpResult.updatedInvoice) {
      setAllInvoices(prev => 
        prev.map(inv => 
          inv.id === invoiceId 
            ? { ...inv, ...followUpResult.updatedInvoice }
            : inv
        )
      );

      if (followUpResult.reminderEmail) {
        console.log('📧 Manual reminder sent:', followUpResult.reminderEmail);
        toast.success('Herinnering verstuurd');
      }
    }
  };

  const getUserBillingDetailsFunc = () => {
    if (!isBillingDetailsLoaded) {
      // If billing details aren't loaded yet, try to load them
      const user = getCurrentUser();
      if (user && !user.isAdmin) {
        const savedBillingDetails = localStorage.getItem(`${STORAGE_KEY_BILLING_DETAILS_PREFIX}${user.id}`);
        if (savedBillingDetails) {
          try {
            return JSON.parse(savedBillingDetails);
          } catch (error) {
            console.error('Error loading billing details on demand:', error);
          }
        }
      }
    }
    return userBillingDetails;
  };

  const setUserBillingDetailsFunc = (details: any) => {
    console.log('💾 Setting user billing details');
    setUserBillingDetails(details);
    
    // Also save immediately to localStorage
    const user = getCurrentUser();
    if (user && !user.isAdmin && details) {
      try {
        localStorage.setItem(`${STORAGE_KEY_BILLING_DETAILS_PREFIX}${user.id}`, JSON.stringify(details));
      } catch (error) {
        console.error('Error saving billing details immediately:', error);
      }
    }
  };

  const value = {
    invoices: getFilteredInvoices(),
    generateInvoice,
    generateAllInvoices,
    markInvoiceAsPaid,
    markInvoiceAsUnpaid,
    getInvoiceById,
    getInvoicesByStatus,
    getUserBillingDetails: getUserBillingDetailsFunc,
    setUserBillingDetails: setUserBillingDetailsFunc,
    getAllInvoices,
    processFollowUps,
    getOverdueInvoices,
    sendReminder
  };

  return (
    <InvoiceContext.Provider value={value}>
      {children}
    </InvoiceContext.Provider>
  );
}

export function useInvoices() {
  const context = useContext(InvoiceContext);
  if (context === undefined) {
    throw new Error('useInvoices must be used within an InvoiceProvider');
  }
  return context;
}