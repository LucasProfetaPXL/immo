import React, { useState, useEffect } from 'react';
import { Search, Plus, Edit, Trash2, Eye, EyeOff, Copy, RefreshCw, DollarSign, Settings, Shield, UserPlus } from 'lucide-react';
import toast from 'react-hot-toast';
import ConfirmModal from '../common/ConfirmModal';
import { encryptData, decryptData } from '../../utils/encryption';
import { DEFAULT_PRICING, DEFAULT_BOARD_PRICING } from '../../utils/costCalculator';
import type { UserAccount, PricingSettings, BoardTypePricing } from '../../types';

const STORAGE_KEY = 'userAccounts_encrypted';
const ADMIN_CREDENTIALS_KEY = 'adminCredentials_encrypted';

// Board types for pricing configuration
const BOARD_TYPES = [
  { value: 'lichtbord-batterij', label: 'Lichtbord (batterij)' },
  { value: 'lichtbord-kabel', label: 'Lichtbord (kabel)' },
  { value: 'zomerbord', label: 'Zomerbord' }
];

function UserManagementTab() {
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [userToDelete, setUserToDelete] = useState<UserAccount | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  
  // Admin credentials state
  const [showAdminSettings, setShowAdminSettings] = useState(false);
  const [adminCredentials, setAdminCredentials] = useState({ username: 'admin', password: 'admin123' });
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const [isUpdatingAdmin, setIsUpdatingAdmin] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    companyName: '',
    username: '',
    password: '',
    role: 'user' as 'user' | 'employee',
    pricingSettings: {
      useCustomPricing: false,
      baseCost: DEFAULT_PRICING.baseCost,
      dailyCost: DEFAULT_PRICING.dailyCost,
      boardTypePricing: BOARD_TYPES.map(type => ({
        boardType: type.value,
        baseCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.baseCost || 0,
        dailyCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.dailyCost || 0
      }))
    } as PricingSettings
  });

  // Load users from encrypted localStorage - ALWAYS PERSISTENT
  const loadUsers = () => {
    console.log('📖 Loading users from storage...');
    const savedUsers = localStorage.getItem(STORAGE_KEY);
    if (savedUsers) {
      try {
        const encryptedData = JSON.parse(savedUsers);
        const decryptedData = decryptData(encryptedData);
        const parsedUsers = JSON.parse(decryptedData);
        
        console.log(`✅ Loaded ${parsedUsers.length} users from storage`);
        
        // Migrate users without pricing settings or role
        const migratedUsers = parsedUsers.map((user: any) => ({
          ...user,
          role: user.role || 'user', // Default to 'user' if no role
          pricingSettings: user.pricingSettings || {
            useCustomPricing: false,
            baseCost: DEFAULT_PRICING.baseCost,
            dailyCost: DEFAULT_PRICING.dailyCost,
            boardTypePricing: BOARD_TYPES.map(type => ({
              boardType: type.value,
              baseCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.baseCost || 0,
              dailyCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.dailyCost || 0
            }))
          }
        }));
        
        setUsers(migratedUsers);
        
        // Save migrated users back if needed
        if (JSON.stringify(migratedUsers) !== JSON.stringify(parsedUsers)) {
          console.log('🔄 Migrating user data...');
          saveUsers(migratedUsers);
        }
      } catch (error) {
        console.error('❌ Error loading users from localStorage:', error);
        setUsers([]);
      }
    } else {
      console.log('📝 No users found in storage, starting with empty array');
      setUsers([]);
    }
    setIsLoaded(true);
  };

  // Save users to encrypted localStorage - ALWAYS PERSISTENT
  const saveUsers = (usersToSave: UserAccount[]) => {
    console.log(`💾 Saving ${usersToSave.length} users to storage...`);
    try {
      const dataToEncrypt = JSON.stringify(usersToSave);
      const encryptedData = encryptData(dataToEncrypt);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(encryptedData));
      console.log('✅ Users saved successfully to encrypted storage');
    } catch (error) {
      console.error('❌ Error saving users to localStorage:', error);
    }
  };

  // Load admin credentials
  const loadAdminCredentials = () => {
    const saved = localStorage.getItem(ADMIN_CREDENTIALS_KEY);
    if (saved) {
      try {
        const encryptedData = JSON.parse(saved);
        const decryptedData = decryptData(encryptedData);
        const credentials = JSON.parse(decryptedData);
        setAdminCredentials(credentials);
      } catch (error) {
        console.error('Error loading admin credentials:', error);
        // Set default if error
        setAdminCredentials({ username: 'admin', password: 'admin123' });
      }
    }
  };

  // Save admin credentials
  const saveAdminCredentials = (credentials: { username: string; password: string }) => {
    try {
      const dataToEncrypt = JSON.stringify(credentials);
      const encryptedData = encryptData(dataToEncrypt);
      localStorage.setItem(ADMIN_CREDENTIALS_KEY, JSON.stringify(encryptedData));
    } catch (error) {
      console.error('Error saving admin credentials:', error);
    }
  };

  // Initialize on component mount
  useEffect(() => {
    if (!isLoaded) {
      console.log('🚀 UserManagementTab initializing...');
      loadUsers();
      loadAdminCredentials();
    }
  }, [isLoaded]);

  // Auto-save users whenever users state changes - FIXED DEPENDENCY
  useEffect(() => {
    if (isLoaded && users.length >= 0) { // Only save after initial load
      console.log('🔄 Auto-saving users due to state change...');
      saveUsers(users);
    }
  }, [users, isLoaded]); // CRITICAL: Added isLoaded dependency

  // Filter users by search query
  const filteredUsers = users.filter(user => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      user.companyName.toLowerCase().includes(query) ||
      user.username.toLowerCase().includes(query) ||
      (user.role && user.role.toLowerCase().includes(query))
    );
  });

  // Group users by company and role
  const usersByCompany = filteredUsers.reduce((acc, user) => {
    const key = user.role === 'employee' ? 
      'Werknemers (Admin)' : 
      user.companyName;
    
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(user);
    return acc;
  }, {} as Record<string, UserAccount[]>);

  const generateStrongPassword = () => {
    const length = 12;
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    let password = "";
    
    // Ensure at least one of each type
    password += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[Math.floor(Math.random() * 26)]; // Uppercase
    password += "abcdefghijklmnopqrstuvwxyz"[Math.floor(Math.random() * 26)]; // Lowercase
    password += "0123456789"[Math.floor(Math.random() * 10)]; // Number
    password += "!@#$%^&*"[Math.floor(Math.random() * 8)]; // Special char
    
    // Fill the rest
    for (let i = 4; i < length; i++) {
      password += charset[Math.floor(Math.random() * charset.length)];
    }
    
    // Shuffle the password
    return password.split('').sort(() => Math.random() - 0.5).join('');
  };

  const handleGeneratePassword = () => {
    const newPassword = generateStrongPassword();
    setFormData(prev => ({ ...prev, password: newPassword }));
    toast.success('Sterk wachtwoord gegenereerd');
  };

  const handleGenerateAdminPassword = () => {
    const newPassword = generateStrongPassword();
    setAdminCredentials(prev => ({ ...prev, password: newPassword }));
    toast.success('Sterk admin wachtwoord gegenereerd');
  };

  const handleUpdateAdminCredentials = () => {
    if (!adminCredentials.username || !adminCredentials.password) {
      toast.error('Vul alle velden in');
      return;
    }

    if (adminCredentials.username.length < 3) {
      toast.error('Gebruikersnaam moet minimaal 3 karakters zijn');
      return;
    }

    if (adminCredentials.password.length < 6) {
      toast.error('Wachtwoord moet minimaal 6 karakters zijn');
      return;
    }

    setIsUpdatingAdmin(true);
    
    setTimeout(() => {
      saveAdminCredentials(adminCredentials);
      
      // Update current session if needed
      const currentUser = localStorage.getItem('currentUser');
      if (currentUser) {
        const userData = JSON.parse(currentUser);
        if (userData.isAdmin) {
          localStorage.setItem('currentUser', JSON.stringify({
            username: adminCredentials.username,
            isAdmin: true
          }));
        }
      }
      
      setIsUpdatingAdmin(false);
      setShowAdminSettings(false);
      toast.success('Admin inloggegevens bijgewerkt');
    }, 800);
  };

  const handlePricingToggle = (useCustom: boolean) => {
    setFormData(prev => ({
      ...prev,
      pricingSettings: {
        ...prev.pricingSettings,
        useCustomPricing: useCustom,
        // Reset to defaults when switching to custom
        baseCost: useCustom ? DEFAULT_PRICING.baseCost : DEFAULT_PRICING.baseCost,
        dailyCost: useCustom ? DEFAULT_PRICING.dailyCost : DEFAULT_PRICING.dailyCost,
        boardTypePricing: BOARD_TYPES.map(type => ({
          boardType: type.value,
          baseCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.baseCost || 0,
          dailyCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.dailyCost || 0
        }))
      }
    }));
  };

  const handleBoardTypePricingChange = (boardType: string, field: 'baseCost' | 'dailyCost', value: string) => {
    const numValue = parseFloat(value) || 0;
    setFormData(prev => ({
      ...prev,
      pricingSettings: {
        ...prev.pricingSettings,
        boardTypePricing: prev.pricingSettings.boardTypePricing?.map(bp => 
          bp.boardType === boardType 
            ? { ...bp, [field]: numValue }
            : bp
        ) || []
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.username || !formData.password) {
      toast.error('Vul alle velden in');
      return;
    }

    // For regular users, company name is required
    if (formData.role === 'user' && !formData.companyName) {
      toast.error('Vul bedrijfsnaam in');
      return;
    }

    // Validate pricing if custom pricing is enabled and user is not employee
    if (formData.role !== 'employee' && formData.pricingSettings.useCustomPricing && formData.pricingSettings.boardTypePricing) {
      const invalidPricing = formData.pricingSettings.boardTypePricing.some(bp => 
        bp.baseCost < 0 || bp.dailyCost < 0
      );
      
      if (invalidPricing) {
        toast.error('Prijzen moeten geldig zijn (≥ 0)');
        return;
      }
    }

    // Check if username already exists
    const usernameExists = users.some(user => 
      user.username === formData.username && user.id !== editingUser?.id
    );
    
    if (usernameExists) {
      toast.error('Gebruikersnaam bestaat al');
      return;
    }

    if (editingUser) {
      // Update existing user
      console.log('✏️ Updating existing user:', editingUser.username);
      const updatedUsers = users.map(user => 
        user.id === editingUser.id 
          ? { 
              ...user, 
              ...formData,
              // For employees, set company name to 'Admin Werknemers'
              companyName: formData.role === 'employee' ? 'Admin Werknemers' : formData.companyName
            }
          : user
      );
      setUsers(updatedUsers);
      toast.success('Gebruiker bijgewerkt');
      setEditingUser(null);
    } else {
      // Add new user
      console.log('➕ Adding new user:', formData.username);
      const newUser: UserAccount = {
        id: Date.now().toString(),
        ...formData,
        // For employees, set company name to 'Admin Werknemers'
        companyName: formData.role === 'employee' ? 'Admin Werknemers' : formData.companyName,
        createdAt: new Date().toISOString()
      };
      setUsers(prev => {
        const newUsers = [...prev, newUser];
        console.log(`📊 Total users after add: ${newUsers.length}`);
        return newUsers;
      });
      toast.success(`Nieuwe ${formData.role === 'employee' ? 'werknemer' : 'gebruiker'} aangemaakt`);
    }

    // Reset form
    setFormData({ 
      companyName: '', 
      username: '', 
      password: '',
      role: 'user',
      pricingSettings: {
        useCustomPricing: false,
        baseCost: DEFAULT_PRICING.baseCost,
        dailyCost: DEFAULT_PRICING.dailyCost,
        boardTypePricing: BOARD_TYPES.map(type => ({
          boardType: type.value,
          baseCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.baseCost || 0,
          dailyCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.dailyCost || 0
        }))
      }
    });
    setShowAddForm(false);
  };

  const handleEdit = (user: UserAccount) => {
    setEditingUser(user);
    setFormData({
      companyName: user.role === 'employee' ? '' : user.companyName, // Don't show company name for employees
      username: user.username,
      password: user.password,
      role: user.role || 'user',
      pricingSettings: user.pricingSettings || {
        useCustomPricing: false,
        baseCost: DEFAULT_PRICING.baseCost,
        dailyCost: DEFAULT_PRICING.dailyCost,
        boardTypePricing: BOARD_TYPES.map(type => ({
          boardType: type.value,
          baseCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.baseCost || 0,
          dailyCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.dailyCost || 0
        }))
      }
    });
    setShowAddForm(true);
  };

  const handleDeleteClick = (user: UserAccount) => {
    setUserToDelete(user);
  };

  const confirmDelete = () => {
    if (userToDelete) {
      console.log('🗑️ Deleting user:', userToDelete.username);
      const updatedUsers = users.filter(user => user.id !== userToDelete.id);
      setUsers(updatedUsers);
      
      // Also clean up any user-specific data
      localStorage.removeItem(`userBillingDetails_${userToDelete.id}`);
      
      // Check if the deleted user is currently logged in
      const currentUser = localStorage.getItem('currentUser');
      if (currentUser) {
        const userData = JSON.parse(currentUser);
        if (userData.id === userToDelete.id) {
          localStorage.removeItem('currentUser'); // Force logout if current user is deleted
          window.location.reload(); // Reload to trigger logout
        }
      }
      
      toast.success(`${userToDelete.role === 'employee' ? 'Werknemer' : 'Gebruiker'} verwijderd`);
      setUserToDelete(null);
    }
  };

  const togglePasswordVisibility = (userId: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [userId]: !prev[userId]
    }));
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${type} gekopieerd naar klembord`);
  };

  const cancelEdit = () => {
    setEditingUser(null);
    setFormData({ 
      companyName: '', 
      username: '', 
      password: '',
      role: 'user',
      pricingSettings: {
        useCustomPricing: false,
        baseCost: DEFAULT_PRICING.baseCost,
        dailyCost: DEFAULT_PRICING.dailyCost,
        boardTypePricing: BOARD_TYPES.map(type => ({
          boardType: type.value,
          baseCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.baseCost || 0,
          dailyCost: DEFAULT_BOARD_PRICING[type.value as keyof typeof DEFAULT_BOARD_PRICING]?.dailyCost || 0
        }))
      }
    });
    setShowAddForm(false);
  };

  const handleRefresh = () => {
    console.log('🔄 Manual refresh triggered');
    setIsLoaded(false); // Reset loaded state to trigger reload
    loadUsers();
    loadAdminCredentials();
    toast.success('Gebruikersgegevens ververst');
  };

  // Show loading state while data is being loaded
  if (!isLoaded) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-bold mb-4">Gebruikersbeheer</h2>
        <div className="flex justify-center items-center py-10">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-blue"></div>
          <span className="ml-2 text-gray-500">Gebruikers laden...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Gebruikersbeheer</h2>
      
      {/* Admin Settings Section */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Shield size={20} className="text-blue-600 mr-2" />
            <h3 className="text-md font-semibold text-blue-800">Admin Inloggegevens</h3>
          </div>
          <button
            onClick={() => setShowAdminSettings(!showAdminSettings)}
            className="btn btn-sm btn-secondary flex items-center"
          >
            <Settings size={16} className="mr-1" />
            <span>{showAdminSettings ? 'Verberg' : 'Bewerken'}</span>
          </button>
        </div>
        
        {showAdminSettings && (
          <div className="mt-4 pt-4 border-t border-blue-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="form-label text-sm">Admin Gebruikersnaam</label>
                <input
                  type="text"
                  value={adminCredentials.username}
                  onChange={(e) => setAdminCredentials(prev => ({ ...prev, username: e.target.value }))}
                  className="form-input text-sm"
                  placeholder="Admin gebruikersnaam"
                />
              </div>
              
              <div>
                <label className="form-label text-sm">Admin Wachtwoord</label>
                <div className="flex space-x-2">
                  <div className="relative flex-1">
                    <input
                      type={showAdminPassword ? "text" : "password"}
                      value={adminCredentials.password}
                      onChange={(e) => setAdminCredentials(prev => ({ ...prev, password: e.target.value }))}
                      className="form-input text-sm pr-20"
                      placeholder="Admin wachtwoord"
                    />
                    <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
                      <button
                        type="button"
                        onClick={() => setShowAdminPassword(!showAdminPassword)}
                        className="text-gray-400 hover:text-gray-600"
                        title={showAdminPassword ? 'Verberg wachtwoord' : 'Toon wachtwoord'}
                      >
                        {showAdminPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(adminCredentials.password, 'Admin wachtwoord')}
                        className="text-gray-400 hover:text-gray-600"
                        title="Kopieer wachtwoord"
                      >
                        <Copy size={14} />
                      </button>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleGenerateAdminPassword}
                    className="btn btn-sm btn-secondary flex items-center"
                    title="Genereer sterk wachtwoord"
                  >
                    <RefreshCw size={14} />
                  </button>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end mt-4 space-x-2">
              <button
                onClick={() => setShowAdminSettings(false)}
                className="btn btn-sm btn-secondary"
              >
                Annuleren
              </button>
              <button
                onClick={handleUpdateAdminCredentials}
                disabled={isUpdatingAdmin}
                className={`btn btn-sm btn-primary ${isUpdatingAdmin ? 'opacity-75 cursor-wait' : ''}`}
              >
                {isUpdatingAdmin ? 'Bijwerken...' : 'Bijwerken'}
              </button>
            </div>
          </div>
        )}
      </div>
      
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Zoek gebruikers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-64"
            />
          </div>
          
          <div className="text-sm text-gray-500">
            {users.filter(u => u.role !== 'employee').length} bedrijven, {users.filter(u => u.role === 'employee').length} werknemers
            <span className="ml-2 text-xs text-gray-400">
              (Totaal: {users.length} accounts)
            </span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={handleRefresh}
            className="btn btn-secondary flex items-center"
            title="Ververs gebruikersgegevens"
          >
            <RefreshCw size={16} className="mr-1" />
            <span>Ververs</span>
          </button>
          
          <button
            onClick={() => setShowAddForm(true)}
            className="btn btn-primary flex items-center"
          >
            <Plus size={16} className="mr-1" />
            <span>Nieuwe Gebruiker</span>
          </button>
        </div>
      </div>

      {/* Add/Edit Form */}
      {showAddForm && (
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
          <h3 className="text-lg font-semibold mb-4">
            {editingUser ? 'Gebruiker Bewerken' : 'Nieuwe Gebruiker Toevoegen'}
          </h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Role Selection */}
            <div>
              <label className="form-label">Type Gebruiker</label>
              <div className="flex space-x-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="role"
                    value="user"
                    checked={formData.role === 'user'}
                    onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value as 'user' | 'employee' }))}
                    className="mr-2"
                  />
                  <span>Bedrijf</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="role"
                    value="employee"
                    checked={formData.role === 'employee'}
                    onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value as 'user' | 'employee' }))}
                    className="mr-2"
                  />
                  <span>Werknemer (Admin)</span>
                </label>
              </div>
            </div>

            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Only show company name field for regular users, not employees */}
              {formData.role === 'user' && (
                <div>
                  <label className="form-label">Ondernemingsnaam</label>
                  <input
                    type="text"
                    value={formData.companyName}
                    onChange={(e) => setFormData(prev => ({ ...prev, companyName: e.target.value }))}
                    className="form-input"
                    placeholder="Naam van de onderneming"
                    required
                  />
                </div>
              )}
              
              <div className={formData.role === 'employee' ? 'md:col-span-2' : ''}>
                <label className="form-label">Gebruikersnaam</label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                  className="form-input"
                  placeholder="Unieke gebruikersnaam"
                  required
                />
              </div>
              
              <div>
                <label className="form-label">Wachtwoord</label>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={formData.password}
                    onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                    className="form-input flex-1"
                    placeholder="Wachtwoord"
                    required
                  />
                  <button
                    type="button"
                    onClick={handleGeneratePassword}
                    className="btn btn-secondary flex items-center"
                    title="Genereer sterk wachtwoord"
                  >
                    <RefreshCw size={16} />
                  </button>
                </div>
              </div>
            </div>

            {/* Pricing Settings - Only for regular users, not employees */}
            {formData.role !== 'employee' && (
              <div className="border-t border-gray-200 pt-4">
                <div className="flex items-center mb-4">
                  <DollarSign size={20} className="text-primary-blue mr-2" />
                  <h4 className="text-md font-semibold">Prijsinstellingen</h4>
                </div>
                
                <div className="space-y-4">
                  {/* Pricing Type Selection */}
                  <div>
                    <label className="form-label">Prijstype</label>
                    <div className="flex space-x-4">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="pricingType"
                          checked={!formData.pricingSettings.useCustomPricing}
                          onChange={() => handlePricingToggle(false)}
                          className="mr-2"
                        />
                        <span>Standaard Prijzen</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="pricingType"
                          checked={formData.pricingSettings.useCustomPricing}
                          onChange={() => handlePricingToggle(true)}
                          className="mr-2"
                        />
                        <span>Aangepaste Prijzen</span>
                      </label>
                    </div>
                  </div>

                  {/* Board Type Pricing */}
                  {formData.pricingSettings.useCustomPricing && (
                    <div className="p-4 bg-blue-50 rounded-md">
                      <h5 className="font-medium mb-3">Prijzen per Bordtype</h5>
                      <div className="space-y-4">
                        {BOARD_TYPES.map(boardType => {
                          const pricing = formData.pricingSettings.boardTypePricing?.find(bp => bp.boardType === boardType.value);
                          const defaultPricing = DEFAULT_BOARD_PRICING[boardType.value as keyof typeof DEFAULT_BOARD_PRICING];
                          
                          return (
                            <div key={boardType.value} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-3 bg-white rounded border">
                              <div className="flex items-center">
                                <span className="font-medium">{boardType.label}</span>
                                {boardType.value === 'zomerbord' && (
                                  <span className="ml-2 text-xs text-orange-600 bg-orange-100 px-2 py-1 rounded">
                                    Nog geen prijzen
                                  </span>
                                )}
                              </div>
                              
                              <div>
                                <label className="form-label text-xs">Basisprijs (eerste 30 dagen)</label>
                                <div className="relative">
                                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">€</span>
                                  <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={pricing?.baseCost || 0}
                                    onChange={(e) => handleBoardTypePricingChange(boardType.value, 'baseCost', e.target.value)}
                                    className="form-input pl-8 text-sm"
                                    placeholder={defaultPricing?.baseCost?.toString() || '0'}
                                    disabled={boardType.value === 'zomerbord'}
                                  />
                                </div>
                              </div>
                              
                              <div>
                                <label className="form-label text-xs">Dagprijs (na 30 dagen)</label>
                                <div className="relative">
                                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">€</span>
                                  <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    value={pricing?.dailyCost || 0}
                                    onChange={(e) => handleBoardTypePricingChange(boardType.value, 'dailyCost', e.target.value)}
                                    className="form-input pl-8 text-sm"
                                    placeholder={defaultPricing?.dailyCost?.toString() || '0'}
                                    disabled={boardType.value === 'zomerbord'}
                                  />
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Standard Pricing Info */}
                  {!formData.pricingSettings.useCustomPricing && (
                    <div className="p-3 bg-gray-100 rounded-md">
                      <h5 className="font-medium mb-2">Standaard Prijzen</h5>
                      <div className="text-sm text-gray-600 space-y-1">
                        {BOARD_TYPES.map(boardType => {
                          const defaultPricing = DEFAULT_BOARD_PRICING[boardType.value as keyof typeof DEFAULT_BOARD_PRICING];
                          return (
                            <div key={boardType.value} className="flex justify-between">
                              <span>{boardType.label}:</span>
                              <span>
                                {defaultPricing?.baseCost > 0 
                                  ? `€${defaultPricing.baseCost} + €${defaultPricing.dailyCost}/dag`
                                  : 'Nog geen prijzen'
                                }
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            <div className="flex justify-end space-x-2 pt-4">
              <button
                type="button"
                onClick={cancelEdit}
                className="btn btn-secondary"
              >
                Annuleren
              </button>
              <button
                type="submit"
                className="btn btn-primary"
              >
                {editingUser ? 'Bijwerken' : 'Opslaan'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Users List */}
      {Object.keys(usersByCompany).length === 0 ? (
        <div className="text-center py-10 text-gray-500 border rounded-lg">
          <p>Geen gebruikers gevonden</p>
          {users.length === 0 && (
            <p className="mt-2 text-sm">Klik op "Nieuwe Gebruiker" om te beginnen</p>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(usersByCompany).map(([companyName, companyUsers]) => (
            <div key={companyName} className="border border-gray-200 rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
                <h3 className="font-semibold text-gray-900">{companyName}</h3>
                <p className="text-sm text-gray-500">
                  {companyUsers.length} {companyUsers[0]?.role === 'employee' ? 'werknemer(s)' : 'gebruiker(s)'}
                </p>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Gebruikersnaam
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Wachtwoord
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Prijsinstellingen
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Aangemaakt
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Laatste Login
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Acties
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {companyUsers.map(user => (
                      <tr key={user.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <span className="font-medium text-gray-900">{user.username}</span>
                            <button
                              onClick={() => copyToClipboard(user.username, 'Gebruikersnaam')}
                              className="ml-2 text-gray-400 hover:text-gray-600"
                              title="Kopieer gebruikersnaam"
                            >
                              <Copy size={14} />
                            </button>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <span className="font-mono text-sm">
                              {showPasswords[user.id] ? user.password : '••••••••••••'}
                            </span>
                            <button
                              onClick={() => togglePasswordVisibility(user.id)}
                              className="ml-2 text-gray-400 hover:text-gray-600"
                              title={showPasswords[user.id] ? 'Verberg wachtwoord' : 'Toon wachtwoord'}
                            >
                              {showPasswords[user.id] ? <EyeOff size={14} /> : <Eye size={14} />}
                            </button>
                            <button
                              onClick={() => copyToClipboard(user.password, 'Wachtwoord')}
                              className="ml-2 text-gray-400 hover:text-gray-600"
                              title="Kopieer wachtwoord"
                            >
                              <Copy size={14} />
                            </button>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            user.role === 'employee' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {user.role === 'employee' ? 'Werknemer' : 'Bedrijf'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm">
                            {user.role === 'employee' ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                N.v.t.
                              </span>
                            ) : user.pricingSettings?.useCustomPricing ? (
                              <div>
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                  Aangepast
                                </span>
                                <div className="text-xs text-gray-500 mt-1">
                                  Per bordtype
                                </div>
                              </div>
                            ) : (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                Standaard
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(user.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Nooit'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex justify-end space-x-2">
                            <button
                              onClick={() => handleEdit(user)}
                              className="btn btn-sm btn-secondary flex items-center"
                            >
                              <Edit size={14} className="mr-1" />
                              <span>Bewerken</span>
                            </button>
                            <button
                              onClick={() => handleDeleteClick(user)}
                              className="btn btn-sm btn-danger flex items-center"
                            >
                              <Trash2 size={14} className="mr-1" />
                              <span>Verwijderen</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={!!userToDelete}
        onClose={() => setUserToDelete(null)}
        onConfirm={confirmDelete}
        title={`${userToDelete?.role === 'employee' ? 'Werknemer' : 'Gebruiker'} Verwijderen`}
        message={`Weet u zeker dat u ${userToDelete?.role === 'employee' ? 'de werknemer' : 'de gebruiker'} "${userToDelete?.username}" wilt verwijderen?\n\nDeze actie kan niet ongedaan worden gemaakt en alle gerelateerde data wordt verwijderd.`}
        confirmText="Ja, Verwijderen"
        cancelText="Annuleren"
        type="danger"
        icon="trash"
      />
    </div>
  );
}

export default UserManagementTab;