import { differenceInDays } from 'date-fns';
import { SignData, PricingSettings, BoardTypePricing } from '../types';
import { decryptData } from './encryption';

// Default pricing per board type
export const DEFAULT_BOARD_PRICING = {
  'lichtbord-batterij': {
    baseCost: 220,
    dailyCost: 4
  },
  'lichtbord-kabel': {
    baseCost: 180,
    dailyCost: 3
  },
  'zomerbord': {
    baseCost: 0, // Not yet defined
    dailyCost: 0 // Not yet defined
  }
};

// Legacy default pricing (for backwards compatibility)
export const DEFAULT_PRICING = {
  baseCost: 220,
  dailyCost: 4
};

/**
 * Get pricing settings for a specific user and board type
 */
export function getUserPricingForBoardType(userId: string, boardType?: string): { baseCost: number; dailyCost: number } {
  try {
    const savedUsers = localStorage.getItem('userAccounts_encrypted');
    if (savedUsers) {
      const encryptedData = JSON.parse(savedUsers);
      const decryptedData = decryptData(encryptedData);
      const users = JSON.parse(decryptedData);
      const user = users.find((u: any) => u.id === userId);
      
      if (user && user.pricingSettings) {
        const pricing = user.pricingSettings;
        
        // If custom pricing is enabled and board type pricing exists
        if (pricing.useCustomPricing && pricing.boardTypePricing && boardType) {
          const boardPricing = pricing.boardTypePricing.find((bp: BoardTypePricing) => bp.boardType === boardType);
          if (boardPricing) {
            return {
              baseCost: boardPricing.baseCost,
              dailyCost: boardPricing.dailyCost
            };
          }
        }
        
        // Fallback to general custom pricing
        if (pricing.useCustomPricing) {
          return {
            baseCost: pricing.baseCost,
            dailyCost: pricing.dailyCost
          };
        }
      }
    }
  } catch (error) {
    console.error('Error loading user pricing:', error);
  }
  
  // Return default pricing for the board type
  if (boardType && DEFAULT_BOARD_PRICING[boardType as keyof typeof DEFAULT_BOARD_PRICING]) {
    return DEFAULT_BOARD_PRICING[boardType as keyof typeof DEFAULT_BOARD_PRICING];
  }
  
  // Final fallback to legacy default pricing
  return {
    baseCost: DEFAULT_PRICING.baseCost,
    dailyCost: DEFAULT_PRICING.dailyCost
  };
}

/**
 * Get pricing settings for a specific user (legacy function for backwards compatibility)
 */
export function getUserPricing(userId: string): PricingSettings {
  try {
    const savedUsers = localStorage.getItem('userAccounts_encrypted');
    if (savedUsers) {
      const encryptedData = JSON.parse(savedUsers);
      const decryptedData = decryptData(encryptedData);
      const users = JSON.parse(decryptedData);
      const user = users.find((u: any) => u.id === userId);
      
      if (user && user.pricingSettings) {
        return user.pricingSettings;
      }
    }
  } catch (error) {
    console.error('Error loading user pricing:', error);
  }
  
  // Return default pricing if user not found or no custom pricing
  return {
    useCustomPricing: false,
    baseCost: DEFAULT_PRICING.baseCost,
    dailyCost: DEFAULT_PRICING.dailyCost
  };
}

/**
 * Bereken de kosten van een bord op basis van de actieve dagen en gebruiker-specifieke prijzen
 * Formule: baseCost voor de eerste 30 dagen, daarna dailyCost per dag
 */
export function calculateSignCost(sign: SignData): number {
  if (!sign.placedAt) {
    return 0;
  }
  
  const placedDate = new Date(sign.placedAt);
  const removalDate = sign.removalRequestedAt 
    ? new Date(sign.removalRequestedAt)
    : new Date();
  
  // Bereken het aantal dagen tussen plaatsing en verwijderingsaanvraag (inclusief beide dagen)
  // +1 omdat we beide dagen meetellen
  const daysActive = differenceInDays(removalDate, placedDate) + 1;
  
  // Get user-specific pricing for the board type
  const pricing = getUserPricingForBoardType(sign.userId || '', sign.boardType);
  const baseCost = pricing.baseCost;
  const dailyCost = pricing.dailyCost;
  
  let totalCost = 0;
  
  if (daysActive <= 30) {
    totalCost = baseCost; // Vast bedrag voor eerste 30 dagen
  } else {
    totalCost = baseCost + ((daysActive - 30) * dailyCost); // Extra dagen
  }
  
  return totalCost;
}

/**
 * Calculate cost with specific pricing (for invoice generation)
 */
export function calculateSignCostWithPricing(
  daysActive: number, 
  baseCost: number, 
  dailyCost: number
): number {
  if (daysActive <= 30) {
    return baseCost;
  } else {
    return baseCost + ((daysActive - 30) * dailyCost);
  }
}