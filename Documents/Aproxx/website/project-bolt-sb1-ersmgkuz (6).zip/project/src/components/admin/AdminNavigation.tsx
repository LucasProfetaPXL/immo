import React from 'react';
import { MapPin, Trash2, Building2, Users, PieChart } from 'lucide-react';

type AdminTabType = 'place-signs' | 'remove-signs' | 'company-overview' | 'user-management' | 'income';

interface AdminNavigationProps {
  activeTab: AdminTabType;
  onTabChange: (tab: AdminTabType) => void;
}

function AdminNavigation({ activeTab, onTabChange }: AdminNavigationProps) {
  return (
    <nav className="flex space-x-4 overflow-x-auto pb-2">
      <button
        className={`nav-link flex items-center ${activeTab === 'place-signs' ? 'active' : ''}`}
        onClick={() => onTabChange('place-signs')}
      >
        <MapPin size={18} className="mr-2" />
        <span>Borden Plaatsen</span>
      </button>
      
      <button
        className={`nav-link flex items-center ${activeTab === 'remove-signs' ? 'active' : ''}`}
        onClick={() => onTabChange('remove-signs')}
      >
        <Trash2 size={18} className="mr-2" />
        <span>Borden Verwijderen</span>
      </button>
      
      <button
        className={`nav-link flex items-center ${activeTab === 'company-overview' ? 'active' : ''}`}
        onClick={() => onTabChange('company-overview')}
      >
        <Building2 size={18} className="mr-2" />
        <span>Bedrijfsoverzicht</span>
      </button>
      
      <button
        className={`nav-link flex items-center ${activeTab === 'income' ? 'active' : ''}`}
        onClick={() => onTabChange('income')}
      >
        <PieChart size={18} className="mr-2" />
        <span>Inkomsten</span>
      </button>
      
      <button
        className={`nav-link flex items-center ${activeTab === 'user-management' ? 'active' : ''}`}
        onClick={() => onTabChange('user-management')}
      >
        <Users size={18} className="mr-2" />
        <span>Gebruikersbeheer</span>
      </button>
    </nav>
  );
}

export default AdminNavigation;