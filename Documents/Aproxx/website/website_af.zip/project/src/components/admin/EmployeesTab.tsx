import React, { useState, useEffect } from 'react';
import { useSigns } from '../../context/SignsContext';
import { distributeWorkAmongEmployees, getAllEmployees } from '../../utils/workDistribution';
import { Users, MapPin, Trash2, TrendingUp, Eye, Download } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { downloadImage } from '../../utils/imageUtils';
import { formatAddress } from '../../utils/addressFormatter.tsx';
import ImageViewerModal from '../common/ImageViewerModal';

function EmployeesTab() {
  const { signs } = useSigns();
  const [workDistribution, setWorkDistribution] = useState<any[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const [imageViewerState, setImageViewerState] = useState<{
    isOpen: boolean;
    images: string[];
    currentIndex: number;
    title: string;
    description: string;
  }>({
    isOpen: false,
    images: [],
    currentIndex: 0,
    title: '',
    description: ''
  });

  // Calculate work distribution
  useEffect(() => {
    const confirmedSigns = signs.filter(sign => sign.status === 'confirmed');
    const removalSigns = signs.filter(sign => sign.status === 'removal-confirmed');
    const soldSigns = signs.filter(sign => sign.soldStatus === 'confirmed');
    
    if (confirmedSigns.length > 0 || removalSigns.length > 0 || soldSigns.length > 0) {
      const distribution = distributeWorkAmongEmployees(confirmedSigns, removalSigns, soldSigns);
      setWorkDistribution(distribution);
    } else {
      setWorkDistribution([]);
    }
  }, [signs]);

  const employees = getAllEmployees();

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  const handleDownloadImage = (imageUrl: string, address: string) => {
    downloadImage(imageUrl, `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}`);
  };

  const handleViewProofImage = (imageUrl: string, type: 'placed' | 'removed' | 'sold', address: string) => {
    const titles = {
      placed: 'Bewijs van Plaatsing',
      removed: 'Bewijs van Ophaling',
      sold: 'Bewijs van Verkocht Bordje'
    };
    
    setImageViewerState({
      isOpen: true,
      images: [imageUrl],
      currentIndex: 0,
      title: titles[type],
      description: address
    });
  };

  const closeImageViewer = () => {
    setImageViewerState({
      isOpen: false,
      images: [],
      currentIndex: 0,
      title: '',
      description: ''
    });
  };

  const selectedAssignment = selectedEmployee 
    ? workDistribution.find(a => a.employeeId === selectedEmployee)
    : null;

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Werknemers / Taakverdeling</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Employees Overview */}
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold">Werknemers Overzicht</h3>
            <p className="text-sm text-gray-500">{employees.length} actieve werknemers</p>
          </div>
          
          <div className="p-4">
            {employees.length === 0 ? (
              <div className="text-center py-10 text-gray-500">
                <Users size={48} className="mx-auto text-gray-300 mb-4" />
                <p>Geen werknemers gevonden</p>
                <p className="text-sm mt-2">Ga naar Gebruikersbeheer om werknemers aan te maken</p>
              </div>
            ) : (
              <div className="space-y-3">
                {workDistribution.map(assignment => (
                  <div 
                    key={assignment.employeeId}
                    className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                      selectedEmployee === assignment.employeeId
                        ? 'border-primary-blue bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedEmployee(
                      selectedEmployee === assignment.employeeId ? null : assignment.employeeId
                    )}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-gray-900">{assignment.employeeName}</h4>
                        <div className="text-sm text-gray-600 mt-1 space-y-1">
                          <div className="flex items-center">
                            <MapPin size={14} className="text-green-600 mr-1" />
                            <span>{assignment.placementSigns.length} borden plaatsen</span>
                          </div>
                          <div className="flex items-center">
                            <Trash2 size={14} className="text-orange-600 mr-1" />
                            <span>{assignment.removalSigns.length} borden ophalen</span>
                          </div>
                          <div className="flex items-center">
                            <TrendingUp size={14} className="text-purple-600 mr-1" />
                            <span>{assignment.soldSigns.length} verkocht bordjes</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-lg">{assignment.totalSigns}</div>
                        <div className="text-xs text-gray-500">totaal taken</div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {employees.filter(emp => !workDistribution.some(a => a.employeeId === emp.id)).map(employee => (
                  <div 
                    key={employee.id}
                    className="p-4 border border-gray-200 rounded-lg bg-gray-50"
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-medium text-gray-600">{employee.username}</h4>
                        <p className="text-sm text-gray-500">Geen taken toegewezen</p>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-lg text-gray-400">0</div>
                        <div className="text-xs text-gray-400">taken</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Employee Task Details */}
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold">
              {selectedAssignment ? `Taken voor ${selectedAssignment.employeeName}` : 'Selecteer een werknemer'}
            </h3>
            {selectedAssignment && (
              <p className="text-sm text-gray-500">{selectedAssignment.totalSigns} taken toegewezen</p>
            )}
          </div>
          
          <div className="p-4">
            {!selectedAssignment ? (
              <div className="text-center py-10 text-gray-500">
                <Users size={48} className="mx-auto text-gray-300 mb-4" />
                <p>Selecteer een werknemer om taken te bekijken</p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Placement Tasks */}
                {selectedAssignment.placementSigns.length > 0 && (
                  <div>
                    <h4 className="font-medium text-green-700 mb-2 flex items-center">
                      <MapPin size={16} className="mr-2" />
                      Borden Plaatsen ({selectedAssignment.placementSigns.length})
                    </h4>
                    <div className="space-y-2">
                      {selectedAssignment.placementSigns.map((sign: any) => (
                        <div key={sign.id} className="p-3 bg-green-50 border border-green-200 rounded-md">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <p className="text-sm font-medium">{sign.address}</p>
                              <p className="text-xs text-gray-500">{sign.companyName}</p>
                            </div>
                            {sign.imageUrl && (
                              <div className="w-10 h-10 rounded overflow-hidden border border-gray-200">
                                <div 
                                  style={{
                                    width: '100%',
                                    height: '100%',
                                    backgroundImage: `url(${sign.imageUrl})`,
                                    backgroundSize: 'cover',
                                    backgroundPosition: 'center',
                                  }}
                                ></div>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Removal Tasks */}
                {selectedAssignment.removalSigns.length > 0 && (
                  <div>
                    <h4 className="font-medium text-orange-700 mb-2 flex items-center">
                      <Trash2 size={16} className="mr-2" />
                      Borden Ophalen ({selectedAssignment.removalSigns.length})
                    </h4>
                    <div className="space-y-2">
                      {selectedAssignment.removalSigns.map((sign: any) => (
                        <div key={sign.id} className="p-3 bg-orange-50 border border-orange-200 rounded-md">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <p className="text-sm font-medium">{sign.address}</p>
                              <p className="text-xs text-gray-500">{sign.companyName}</p>
                            </div>
                            {sign.imageUrl && (
                              <div className="w-10 h-10 rounded overflow-hidden border border-gray-200">
                                <div 
                                  style={{
                                    width: '100%',
                                    height: '100%',
                                    backgroundImage: `url(${sign.imageUrl})`,
                                    backgroundSize: 'cover',
                                    backgroundPosition: 'center',
                                  }}
                                ></div>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Sold Tasks */}
                {selectedAssignment.soldSigns.length > 0 && (
                  <div>
                    <h4 className="font-medium text-purple-700 mb-2 flex items-center">
                      <TrendingUp size={16} className="mr-2" />
                      Verkocht Bordjes ({selectedAssignment.soldSigns.length})
                    </h4>
                    <div className="space-y-2">
                      {selectedAssignment.soldSigns.map((sign: any) => (
                        <div key={sign.id} className="p-3 bg-purple-50 border border-purple-200 rounded-md">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <p className="text-sm font-medium">{formatAddress(sign.address)}</p>
                              <p className="text-xs text-gray-500">{sign.companyName}</p>
                              {sign.proofImages?.sold && (
                                <div className="flex items-center mt-1">
                                  <button
                                    onClick={() => handleViewProofImage(sign.proofImages.sold, 'sold', sign.address)}
                                    className="text-purple-600 hover:text-purple-800 text-xs flex items-center"
                                  >
                                    <Eye size={12} className="mr-1" />
                                    Bewijs beschikbaar
                                  </button>
                                </div>
                              )}
                            </div>
                            {sign.imageUrl && (
                              <div className="w-10 h-10 rounded overflow-hidden border border-gray-200">
                                <div 
                                  style={{
                                    width: '100%',
                                    height: '100%',
                                    backgroundImage: `url(${sign.imageUrl})`,
                                    backgroundSize: 'cover',
                                    backgroundPosition: 'center',
                                  }}
                                ></div>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {selectedAssignment.totalSigns === 0 && (
                  <div className="text-center py-6 text-gray-500">
                    <p>Geen taken toegewezen aan deze werknemer</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Image Viewer Modal */}
      <ImageViewerModal
        isOpen={imageViewerState.isOpen}
        onClose={closeImageViewer}
        images={imageViewerState.images}
        currentIndex={imageViewerState.currentIndex}
        onIndexChange={(index) => setImageViewerState(prev => ({ ...prev, currentIndex: index }))}
        title={imageViewerState.title}
        description={imageViewerState.description}
      />
    </div>
  );
}

export default EmployeesTab;