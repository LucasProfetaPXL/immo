import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { v4 as uuidv4 } from '../../utils/uuid';
import { useSigns } from '../../context/SignsContext';
import toast from 'react-hot-toast';
import AddressSearch from '../common/AddressSearch';
import SignMap from '../common/SignMap';
import { Upload, X, Image as ImageIcon, Info, Download, ChevronDown } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';

// Fix Leaflet icon issue
import L from 'leaflet';
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

// Belgium bounds
const belgiumBounds = [[49.5, 2.5], [51.5, 6.4]] as L.LatLngBoundsExpression;
const defaultCenter = [50.8503, 4.3517] as [number, number]; // Brussels

function SetBounds() {
  const map = useMap();
  
  useEffect(() => {
    map.setMaxBounds(belgiumBounds);
    map.on('drag', () => {
      map.panInsideBounds(belgiumBounds, { animate: false });
    });
  }, [map]);
  
  return null;
}

// Convert mm to pixels (assuming 96 DPI)
const mmToPixels = (mm: number) => Math.round((mm * 96) / 25.4);

// Corrected minimum and maximum dimensions in mm (height x width)
const MIN_HEIGHT_MM = 1140;
const MIN_WIDTH_MM = 540;
const MAX_HEIGHT_MM = 1200;
const MAX_WIDTH_MM = 600;

// Convert to pixels
const MIN_HEIGHT_PX = mmToPixels(MIN_HEIGHT_MM);
const MIN_WIDTH_PX = mmToPixels(MIN_WIDTH_MM);
const MAX_HEIGHT_PX = mmToPixels(MAX_HEIGHT_MM);
const MAX_WIDTH_PX = mmToPixels(MAX_WIDTH_MM);

// Board types
const BOARD_TYPES = [
  { value: 'lichtbord-batterij', label: 'Lichtbord (batterij)' },
  { value: 'lichtbord-kabel', label: 'Lichtbord (kabel)' },
  { value: 'zomerbord', label: 'Zomerbord', disabled: true }
];

function PlaceOrderTab() {
  const { addSign, signs } = useSigns();
  const [selectedAddress, setSelectedAddress] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<[number, number] | null>(null);
  const [selectedBoardType, setSelectedBoardType] = useState('lichtbord-batterij');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [addresses, setAddresses] = useState<{address: string, lat: number, lng: number, boardType: string, imageUrl?: string}[]>([]);
  const [imageError, setImageError] = useState<string | null>(null);
  const [isValidatingImage, setIsValidatingImage] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  // Download image function
  const handleDownloadImage = (imageUrl: string, address: string) => {
    try {
      // Create a temporary link element
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success('Afbeelding download gestart');
    } catch (error) {
      console.error('Download error:', error);
      // Fallback: open in new tab
      window.open(imageUrl, '_blank');
      toast.success('Afbeelding geopend in nieuw tabblad');
    }
  };

  const validateImageDimensions = (file: File): Promise<boolean> => {
    return new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      
      img.onload = () => {
        URL.revokeObjectURL(url);
        
        const width = img.naturalWidth;
        const height = img.naturalHeight;
        
        // Check if dimensions are within acceptable range
        const isWidthValid = width >= MIN_WIDTH_PX && width <= MAX_WIDTH_PX;
        const isHeightValid = height >= MIN_HEIGHT_PX && height <= MAX_HEIGHT_PX;
        
        if (!isWidthValid || !isHeightValid) {
          // Convert current dimensions back to mm for error message
          const currentWidthMm = Math.round((width * 25.4) / 96);
          const currentHeightMm = Math.round((height * 25.4) / 96);
          
          setImageError(
            `Afbeelding afmetingen (${currentHeightMm}mm x ${currentWidthMm}mm) zijn niet toegestaan. ` +
            `Vereiste afmetingen: ${MIN_HEIGHT_MM}mm x ${MIN_WIDTH_MM}mm t.e.m. ${MAX_HEIGHT_MM}mm x ${MAX_WIDTH_MM}mm`
          );
          resolve(false);
        } else {
          setImageError(null);
          resolve(true);
        }
      };
      
      img.onerror = () => {
        URL.revokeObjectURL(url);
        setImageError('Kon afbeelding niet laden voor validatie');
        resolve(false);
      };
      
      img.src = url;
    });
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check file type
      if (!file.type.match('image/jpeg') && !file.type.match('image/png')) {
        setImageError('Alleen JPG of PNG afbeeldingen zijn toegestaan');
        return;
      }
      
      setIsValidatingImage(true);
      setImageError(null);
      
      // Validate dimensions
      const isValid = await validateImageDimensions(file);
      
      if (isValid) {
        // Create preview
        const reader = new FileReader();
        reader.onload = (event) => {
          setImagePreview(event.target?.result as string);
        };
        reader.readAsDataURL(file);
        setImage(file);
      } else {
        // Clear the file input
        e.target.value = '';
        setImage(null);
        setImagePreview(null);
      }
      
      setIsValidatingImage(false);
    }
  };

  const handleAddAddress = () => {
    if (!selectedLocation || !selectedAddress) {
      toast.error('Selecteer een adres uit de zoekresultaten');
      return;
    }
    
    if (!imagePreview) {
      setImageError('Een afbeelding is verplicht');
      return;
    }

    // Check if Zomerbord is selected (disabled option)
    if (selectedBoardType === 'zomerbord') {
      toast.error('Zomerbord is momenteel niet beschikbaar');
      return;
    }
    
    setAddresses([...addresses, {
      address: selectedAddress,
      lat: selectedLocation[0],
      lng: selectedLocation[1],
      boardType: selectedBoardType,
      imageUrl: imagePreview || undefined
    }]);
    
    // Reset fields
    setSelectedAddress('');
    setSelectedLocation(null);
    setSelectedBoardType('lichtbord-batterij'); // Reset to default
    setImage(null);
    setImagePreview(null);
    setImageError(null);
    
    toast.success('Adres toegevoegd aan bestelling');
  };

  const handleRemoveAddress = (index: number) => {
    const newAddresses = [...addresses];
    newAddresses.splice(index, 1);
    setAddresses(newAddresses);
  };

  const handleSubmitOrder = () => {
    if (!currentUser || !currentUser.companyName) {
      toast.error('Gebruikersgegevens niet gevonden');
      return;
    }
    
    if (addresses.length === 0) {
      toast.error('Voeg ten minste één adres toe');
      return;
    }
    
    setIsSubmitting(true);
    
    // Add each address as a separate sign
    addresses.forEach(addr => {
      addSign({
        id: uuidv4(),
        companyName: currentUser.companyName, // Use company name from user account
        address: addr.address,
        category: 'B',
        boardType: addr.boardType, // Add board type to sign data
        lat: addr.lat,
        lng: addr.lng,
        imageUrl: addr.imageUrl,
        status: 'pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        statusHistory: [
          { status: 'pending', date: new Date().toISOString() }
        ]
      });
    });
    
    // Reset form
    setSelectedAddress('');
    setSelectedLocation(null);
    setSelectedBoardType('lichtbord-batterij');
    setImage(null);
    setImagePreview(null);
    setAddresses([]);
    setIsSubmitting(false);
    
    toast.success('Bestelling succesvol geplaatst!');
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Plaats Bestelling</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Map Section */}
        <div className="rounded-lg overflow-hidden border border-gray-200 h-[500px]">
          <MapContainer 
            center={defaultCenter} 
            zoom={8} 
            style={{ height: '100%', width: '100%' }}
            zoomControl={true}
            scrollWheelZoom={true}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            <SetBounds />
            <SignMap signs={signs} showPreview={false} />
          </MapContainer>
        </div>
        
        {/* Form Section */}
        <div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h3 className="text-lg font-semibold mb-2">Bestelgegevens</h3>
            
            <div className="mb-4">
              <label className="form-label">Locatie</label>
              <AddressSearch 
                onAddressSelect={(address, lat, lng) => {
                  setSelectedAddress(address);
                  setSelectedLocation([lat, lng]);
                }}
              />
            </div>

            {selectedAddress && (
              <div className="mb-4 p-3 bg-gray-50 rounded-md">
                <p className="text-sm font-medium">{selectedAddress}</p>
              </div>
            )}

            {/* Board Type Dropdown */}
            <div className="mb-4">
              <label className="form-label">Bordtype</label>
              <div className="relative">
                <select
                  value={selectedBoardType}
                  onChange={(e) => setSelectedBoardType(e.target.value)}
                  className="form-input appearance-none pr-10"
                >
                  {BOARD_TYPES.map(type => (
                    <option 
                      key={type.value} 
                      value={type.value}
                      disabled={type.disabled}
                    >
                      {type.label}
                      {type.disabled ? ' (Niet beschikbaar)' : ''}
                    </option>
                  ))}
                </select>
                <ChevronDown size={16} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
              </div>
            </div>
            
            <div className="mb-4">
              <div className="flex items-center mb-2">
                <label className="form-label mb-0 mr-2">Bord Afbeelding</label>
                <div className="relative">
                  <Info 
                    size={16} 
                    className="text-gray-400 cursor-help"
                    onMouseEnter={() => setShowTooltip(true)}
                    onMouseLeave={() => setShowTooltip(false)}
                  />
                  {showTooltip && (
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-800 text-white text-xs rounded-md whitespace-nowrap z-10">
                      <div className="text-center">
                        <div>De poster voor het lichtbord zal</div>
                        <div>1140mm x 540mm zijn.</div>
                        <div>Alles hoger zal aan de linker en</div>
                        <div>rechter zijdes worden bijgeknipt.</div>
                      </div>
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-800"></div>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <label className={`flex items-center justify-center w-32 h-32 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
                  isValidatingImage 
                    ? 'border-blue-300 bg-blue-50' 
                    : imageError 
                      ? 'border-red-300 bg-red-50' 
                      : 'border-gray-300 hover:bg-gray-50'
                }`}>
                  <div className="space-y-1 text-center">
                    {isValidatingImage ? (
                      <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                    ) : (
                      <Upload className={`mx-auto h-8 w-8 ${imageError ? 'text-red-400' : 'text-gray-400'}`} />
                    )}
                    <div className={`text-xs ${imageError ? 'text-red-500' : 'text-gray-500'}`}>
                      {isValidatingImage ? 'Valideren...' : 'JPG of PNG'}
                    </div>
                  </div>
                  <input 
                    type="file" 
                    className="hidden" 
                    onChange={handleImageChange}
                    accept="image/jpeg,image/png"
                    disabled={isValidatingImage}
                  />
                </label>
                
                {imagePreview && (
                  <div className="relative">
                    <div className="w-32 h-32 border border-gray-300 rounded-lg overflow-hidden">
                      <div 
                        style={{
                          width: '100%',
                          height: '100%',
                          backgroundImage: `url(${imagePreview})`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center',
                        }}
                      ></div>
                    </div>
                    <button 
                      onClick={() => { 
                        setImage(null); 
                        setImagePreview(null); 
                        setImageError(null);
                      }}
                      className="absolute -top-2 -right-2 p-1 bg-white rounded-full border border-gray-300 shadow-sm hover:bg-gray-50"
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}
              </div>
              <div className="mt-2">
                <p className="text-xs text-gray-500">
                  Vereiste afmetingen: {MIN_HEIGHT_MM}mm x {MIN_WIDTH_MM}mm t.e.m. {MAX_HEIGHT_MM}mm x {MAX_WIDTH_MM}mm
                </p>
                <p className="text-xs text-gray-400">
                  Alleen JPG en PNG bestanden zijn toegestaan
                </p>
              </div>
              {imageError && (
                <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded-md">
                  <p className="text-xs text-red-600">{imageError}</p>
                </div>
              )}
            </div>
            
            <button 
              onClick={handleAddAddress}
              disabled={!selectedAddress || !imagePreview || isValidatingImage || selectedBoardType === 'zomerbord'}
              className={`btn w-full ${
                !selectedAddress || !imagePreview || isValidatingImage || selectedBoardType === 'zomerbord'
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
                  : 'btn-primary'
              }`}
            >
              {isValidatingImage ? 'Valideren...' : 
               selectedBoardType === 'zomerbord' ? 'Bordtype niet beschikbaar' :
               'Adres Toevoegen'}
            </button>
          </div>
          
          {/* Added Addresses */}
          {addresses.length > 0 && (
            <div className="mt-4 bg-white p-6 rounded-lg border border-gray-200">
              <h3 className="text-lg font-semibold mb-3">Geselecteerde Adressen</h3>
              
              <div className="space-y-3 max-h-[200px] overflow-y-auto mb-4">
                {addresses.map((addr, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                    <div className="flex items-center space-x-3">
                      {addr.imageUrl ? (
                        <div className="flex items-center space-x-2">
                          <div className="w-10 h-10 rounded overflow-hidden border border-gray-200">
                            <div 
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundImage: `url(${addr.imageUrl})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                              }}
                            ></div>
                          </div>
                          <button
                            onClick={() => handleDownloadImage(addr.imageUrl!, addr.address)}
                            className="text-gray-500 hover:text-gray-700"
                            title="Download afbeelding"
                          >
                            <Download size={14} />
                          </button>
                        </div>
                      ) : (
                        <div className="w-10 h-10 bg-gray-200 rounded flex items-center justify-center">
                          <ImageIcon size={16} className="text-gray-400" />
                        </div>
                      )}
                      <div>
                        <p className="text-sm font-medium">{addr.address}</p>
                        <p className="text-xs text-gray-500">
                          {BOARD_TYPES.find(type => type.value === addr.boardType)?.label}
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => handleRemoveAddress(index)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <X size={16} />
                    </button>
                  </div>
                ))}
              </div>
              
              <button 
                onClick={handleSubmitOrder}
                disabled={isSubmitting}
                className={`btn btn-success w-full ${isSubmitting ? 'opacity-75 cursor-wait' : ''}`}
              >
                {isSubmitting ? 'Bestelling Plaatsen...' : 'Bestelling Plaatsen'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Recent Orders Section */}
      {signs.length > 0 && (
        <div className="mt-8 bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg font-semibold mb-4">Recente Bestellingen</h3>
          <div className="space-y-3 max-h-[300px] overflow-y-auto">
            {signs.slice(0, 5).map(sign => (
              <div key={sign.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
                <div className="flex items-center space-x-3">
                  {sign.imageUrl && (
                    <div className="flex items-center space-x-2">
                      <div className="w-12 h-12 rounded overflow-hidden border border-gray-200">
                        <div 
                          style={{
                            width: '100%',
                            height: '100%',
                            backgroundImage: `url(${sign.imageUrl})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                          }}
                        ></div>
                      </div>
                      <button
                        onClick={() => handleDownloadImage(sign.imageUrl!, sign.address)}
                        className="text-gray-500 hover:text-gray-700"
                        title="Download afbeelding"
                      >
                        <Download size={14} />
                      </button>
                    </div>
                  )}
                  <div>
                    <p className="font-medium text-sm">{sign.address}</p>
                    <div className="flex items-center mt-1">
                      <span className={`status-badge status-${sign.status}`}>
                        {sign.status === 'pending' ? 'In afwachting' : 
                         sign.status === 'confirmed' ? 'Bevestigd' : 
                         sign.status === 'placed' ? 'Geplaatst' : 
                         sign.status === 'removal-requested' ? 'Verwijdering aangevraagd' : 
                         sign.status === 'removal-confirmed' ? 'Verwijderd' :
                         sign.status === 'removed' ? 'Verwijderd' : sign.status.replace('-', ' ')}
                      </span>
                      <span className="text-xs text-gray-500 ml-2">
                        Aangemaakt {formatDateInDutch(new Date(sign.createdAt))}
                      </span>
                    </div>
                    {/* Show board type if available */}
                    {sign.boardType && (
                      <p className="text-xs text-blue-600 mt-1">
                        {BOARD_TYPES.find(type => type.value === sign.boardType)?.label}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default PlaceOrderTab;