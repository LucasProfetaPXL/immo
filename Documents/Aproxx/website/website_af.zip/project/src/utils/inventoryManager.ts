// Inventory management utilities
import { SignData } from '../types';

const INVENTORY_STORAGE_KEY = 'inventorySettings';

export interface InventorySettings {
  totalBoards: number;
  exclusiveAllocations: Record<string, number>; // userId -> exclusive allocation count
}

// Default inventory settings
const DEFAULT_INVENTORY: InventorySettings = {
  totalBoards: 100,
  exclusiveAllocations: {}
};

/**
 * Get current inventory settings
 */
export const getInventorySettings = (): InventorySettings => {
  try {
    const saved = localStorage.getItem(INVENTORY_STORAGE_KEY);
    if (saved) {
      const settings = JSON.parse(saved);
      // Migrate old format if needed
      if (settings.allocatedBoards && !settings.exclusiveAllocations) {
        return {
          totalBoards: settings.totalBoards,
          exclusiveAllocations: settings.allocatedBoards
        };
      }
      return settings;
    }
  } catch (error) {
    console.error('Error loading inventory settings:', error);
  }
  return DEFAULT_INVENTORY;
};

/**
 * Save inventory settings
 */
export const saveInventorySettings = (settings: InventorySettings): void => {
  try {
    localStorage.setItem(INVENTORY_STORAGE_KEY, JSON.stringify(settings));
    console.log('💾 Inventory settings saved');
  } catch (error) {
    console.error('Error saving inventory settings:', error);
  }
};

/**
 * Calculate total exclusive allocations
 */
export const getTotalExclusiveAllocations = (): number => {
  const settings = getInventorySettings();
  return Object.values(settings.exclusiveAllocations).reduce((sum, count) => sum + count, 0);
};

/**
 * Calculate shared pool size (total - exclusive allocations)
 */
export const getSharedPoolSize = (): number => {
  const settings = getInventorySettings();
  const totalExclusive = getTotalExclusiveAllocations();
  return Math.max(0, settings.totalBoards - totalExclusive);
};

/**
 * Get user's exclusive allocation
 */
export const getUserExclusiveAllocation = (userId: string): number => {
  const settings = getInventorySettings();
  return settings.exclusiveAllocations[userId] || 0;
};

/**
 * Set user's exclusive allocation
 */
export const setUserExclusiveAllocation = (userId: string, count: number): void => {
  const settings = getInventorySettings();
  const oldAllocation = settings.exclusiveAllocations[userId] || 0;
  const newAllocation = Math.max(0, count);
  
  // Check if new allocation would exceed total boards
  const otherExclusiveTotal = Object.entries(settings.exclusiveAllocations)
    .filter(([id]) => id !== userId)
    .reduce((sum, [, allocation]) => sum + allocation, 0);
  
  if (otherExclusiveTotal + newAllocation > settings.totalBoards) {
    throw new Error(`Exclusieve toewijzing zou totale voorraad overschrijden. Beschikbaar: ${settings.totalBoards - otherExclusiveTotal} borden.`);
  }
  
  if (newAllocation === 0) {
    delete settings.exclusiveAllocations[userId];
  } else {
    settings.exclusiveAllocations[userId] = newAllocation;
  }
  
  saveInventorySettings(settings);
  console.log(`📦 User ${userId} exclusive allocation: ${oldAllocation} → ${newAllocation}`);
};

/**
 * Get available boards for a user (exclusive + share of pool)
 */
export const getUserAvailableBoards = (userId: string): number => {
  const exclusiveAllocation = getUserExclusiveAllocation(userId);
  
  // If user has exclusive allocation, they only get that amount
  if (exclusiveAllocation > 0) {
    return exclusiveAllocation;
  }
  
  // Otherwise, user has access to the shared pool
  return getSharedPoolSize();
};

/**
 * Update total boards in system
 */
export const setTotalBoards = (total: number): void => {
  const settings = getInventorySettings();
  const totalExclusive = getTotalExclusiveAllocations();
  
  if (total < totalExclusive) {
    throw new Error(`Totaal aantal borden kan niet lager zijn dan exclusieve toewijzingen (${totalExclusive}).`);
  }
  
  settings.totalBoards = Math.max(0, total);
  saveInventorySettings(settings);
};

/**
 * Calculate boards in use by counting active signs
 */
export const calculateBoardsInUse = (signs: SignData[]): Record<string, number> => {
  const inUse: Record<string, number> = {};
  
  signs.forEach(sign => {
    if (sign.userId && (sign.status === 'placed' || sign.status === 'confirmed')) {
      inUse[sign.userId] = (inUse[sign.userId] || 0) + 1;
    }
  });
  
  return inUse;
};

/**
 * Check if user can place a new board
 */
export const canUserPlaceBoard = (userId: string, signs: SignData[]): boolean => {
  const exclusiveAllocation = getUserExclusiveAllocation(userId);
  const inUse = calculateBoardsInUse(signs);
  const userInUse = inUse[userId] || 0;
  
  // If user has exclusive allocation, check against that
  if (exclusiveAllocation > 0) {
    return userInUse < exclusiveAllocation;
  }
  
  // Otherwise, check against shared pool
  const sharedPoolSize = getSharedPoolSize();
  const sharedPoolInUse = Object.entries(inUse)
    .filter(([uid]) => getUserExclusiveAllocation(uid) === 0)
    .reduce((sum, [, count]) => sum + count, 0);
  
  return sharedPoolInUse < sharedPoolSize;
};

/**
 * Use a board (when placing)
 */
export const useBoardFromInventory = (userId: string): boolean => {
  // This is handled automatically by counting active signs
  // No need to modify allocation as it's calculated dynamically
  return true;
};

/**
 * Return a board to inventory (when removed)
 */
export const returnBoardToInventory = (userId: string): boolean => {
  // This is handled automatically by counting active signs
  // No need to modify allocation as it's calculated dynamically
  return true;
};

/**
 * Get inventory summary for admin
 */
export const getInventorySummary = (signs: SignData[]): {
  totalBoards: number;
  totalInUse: number;
  totalAvailable: number;
  totalExclusiveAllocations: number;
  sharedPoolSize: number;
  sharedPoolInUse: number;
  userBreakdown: Array<{
    userId: string;
    exclusiveAllocation: number;
    inUse: number;
    available: number;
    hasExclusiveAccess: boolean;
  }>;
} => {
  const settings = getInventorySettings();
  const inUse = calculateBoardsInUse(signs);
  
  const totalInUse = Object.values(inUse).reduce((sum, count) => sum + count, 0);
  const totalExclusiveAllocations = getTotalExclusiveAllocations();
  const sharedPoolSize = getSharedPoolSize();
  
  // Calculate shared pool usage (users without exclusive allocations)
  const sharedPoolInUse = Object.entries(inUse)
    .filter(([userId]) => getUserExclusiveAllocation(userId) === 0)
    .reduce((sum, [, count]) => sum + count, 0);
  
  // Create breakdown for all users who have either exclusive allocations or are using boards
  const allUserIds = new Set([
    ...Object.keys(settings.exclusiveAllocations),
    ...Object.keys(inUse)
  ]);
  
  const userBreakdown = Array.from(allUserIds).map(userId => {
    const exclusiveAllocation = getUserExclusiveAllocation(userId);
    const userInUse = inUse[userId] || 0;
    const hasExclusiveAccess = exclusiveAllocation > 0;
    
    let available = 0;
    if (hasExclusiveAccess) {
      available = exclusiveAllocation - userInUse;
    } else {
      available = sharedPoolSize - sharedPoolInUse;
    }
    
    return {
    userId,
    exclusiveAllocation,
    inUse: userInUse,
    available: Math.max(0, available),
    hasExclusiveAccess
  };
  });
  
  return {
    totalBoards: settings.totalBoards,
    totalInUse,
    totalAvailable: settings.totalBoards - totalInUse,
    totalExclusiveAllocations,
    sharedPoolSize,
    sharedPoolInUse,
    userBreakdown
  };
};