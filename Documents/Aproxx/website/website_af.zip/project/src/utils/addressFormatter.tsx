/**
 * Address formatting utilities
 * Formats addresses to show only: Street Number PostalCode City
 * Example: "De Slogen 47 3550 Heusden-Zolder"
 */

/**
 * Format a full address to show only essential parts
 * Input: "47, De Slogen, Bolderberg, Zolder, Heusden-Zolder, Hasselt, Limburg, 3550, België"
 * Output: "De Slogen 47 3550 Heusden-Zolder"
 */
export const formatAddress = (fullAddress: string): string => {
  if (!fullAddress) return '';
  
  // Split by comma and clean up parts
  const parts = fullAddress.split(',').map(part => part.trim()).filter(part => part.length > 0);
  
  if (parts.length === 0) return fullAddress;
  
  // Try to identify components
  let houseNumber = '';
  let streetName = '';
  let postalCode = '';
  let city = '';
  
  // Look for postal code (4 digits)
  const postalCodePart = parts.find(part => /^\d{4}$/.test(part));
  if (postalCodePart) {
    postalCode = postalCodePart;
  }
  
  // Look for house number (starts with digits)
  const houseNumberPart = parts.find(part => /^\d+/.test(part));
  if (houseNumberPart) {
    houseNumber = houseNumberPart;
  }
  
  // Find the main city name (usually the longest meaningful part or contains hyphen)
  const cityParts = parts.filter(part => 
    part !== houseNumber && 
    part !== postalCode && 
    !part.match(/^[A-Z][a-z]+$/) && // Skip single words like "België", "Limburg"
    part.length > 2
  );
  
  // Prefer parts with hyphens (like "Heusden-Zolder") or longer parts
  if (cityParts.length > 0) {
    city = cityParts.find(part => part.includes('-')) || 
           cityParts.reduce((longest, current) => 
             current.length > longest.length ? current : longest
           );
  }
  
  // Find street name (usually the part that's not house number, postal code, or city)
  const streetParts = parts.filter(part => 
    part !== houseNumber && 
    part !== postalCode && 
    part !== city &&
    !part.match(/^(België|Belgique|Belgium|Vlaanderen|Wallonie|Limburg|Antwerpen|Brabant|Oost-Vlaanderen|West-Vlaanderen|Henegouwen|Luik|Namen|Luxemburg)$/i)
  );
  
  if (streetParts.length > 0) {
    // Take the first meaningful street part
    streetName = streetParts[0];
  }
  
  // If we couldn't parse properly, try a different approach
  if (!streetName || !houseNumber || !postalCode || !city) {
    // Fallback: try to extract from common patterns
    
    // Pattern 1: "Number, Street, ..., PostalCode, City, ..."
    if (parts.length >= 4) {
      const potentialNumber = parts[0];
      const potentialStreet = parts[1];
      const potentialPostal = parts.find(p => /^\d{4}$/.test(p));
      const potentialCity = parts[parts.length - 3] || parts[parts.length - 2]; // Often near the end
      
      if (/^\d+/.test(potentialNumber) && potentialStreet && potentialPostal) {
        houseNumber = potentialNumber;
        streetName = potentialStreet;
        postalCode = potentialPostal;
        
        // Find city near postal code
        const postalIndex = parts.indexOf(potentialPostal);
        if (postalIndex >= 0 && postalIndex < parts.length - 1) {
          city = parts[postalIndex + 1];
        }
      }
    }
  }
  
  // Build formatted address
  const formattedParts = [];
  
  if (streetName) {
    if (houseNumber) {
      formattedParts.push(`${streetName} ${houseNumber}`);
    } else {
      formattedParts.push(streetName);
    }
  } else if (houseNumber) {
    formattedParts.push(houseNumber);
  }
  
  if (postalCode) {
    formattedParts.push(postalCode);
  }
  
  if (city) {
    formattedParts.push(city);
  }
  
  // If we have all components, return formatted address
  if (formattedParts.length >= 3) {
    return formattedParts.join(' ');
  }
  
  // Fallback: return original address if parsing failed
  return fullAddress;
};

/**
 * Format address for display in tables and lists
 * Ensures consistent formatting across the application
 */
export const formatAddressForDisplay = (address: string): string => {
  return formatAddress(address);
};

/**
 * Format address with line breaks for better display in narrow spaces
 */
export const formatAddressWithBreaks = (address: string): JSX.Element => {
  const formatted = formatAddress(address);
  
  // If formatted address is long, try to break it intelligently
  if (formatted.length > 30) {
    const parts = formatted.split(' ');
    if (parts.length >= 4) {
      // Break after street name and house number
      const streetAndNumber = parts.slice(0, 2).join(' ');
      const postalAndCity = parts.slice(2).join(' ');
      
      return (
        <div>
          <div>{streetAndNumber}</div>
          <div>{postalAndCity}</div>
        </div>
      );
    }
  }
  
  return <div>{formatted}</div>;
};

/**
 * Extract just the street name and house number
 */
export const getStreetAndNumber = (fullAddress: string): string => {
  const formatted = formatAddress(fullAddress);
  const parts = formatted.split(' ');
  
  // Return first two parts (street name and house number)
  if (parts.length >= 2) {
    return parts.slice(0, 2).join(' ');
  }
  
  return formatted;
};

/**
 * Extract just the postal code and city
 */
export const getPostalAndCity = (fullAddress: string): string => {
  const formatted = formatAddress(fullAddress);
  const parts = formatted.split(' ');
  
  // Return last parts (postal code and city)
  if (parts.length >= 2) {
    return parts.slice(-2).join(' ');
  }
  
  return formatted;
};