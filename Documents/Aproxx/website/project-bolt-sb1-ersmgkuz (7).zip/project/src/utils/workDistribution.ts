// Work distribution utility for employees
import { SignData } from '../types';
import { decryptData } from './encryption';

export interface Employee {
  id: string;
  username: string;
  companyName: string;
}

export interface WorkAssignment {
  employeeId: string;
  employeeName: string;
  placementSigns: SignData[];
  removalSigns: SignData[];
  totalSigns: number;
  centerLat: number;
  centerLng: number;
}

/**
 * Calculate distance between two coordinates using Haversine formula
 */
export const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

/**
 * Calculate the center point of a group of signs
 */
export const calculateCenter = (signs: SignData[]): { lat: number; lng: number } => {
  if (signs.length === 0) return { lat: 50.8503, lng: 4.3517 }; // Brussels default
  
  const totalLat = signs.reduce((sum, sign) => sum + sign.lat, 0);
  const totalLng = signs.reduce((sum, sign) => sum + sign.lng, 0);
  
  return {
    lat: totalLat / signs.length,
    lng: totalLng / signs.length
  };
};

/**
 * Get all employees from encrypted storage
 */
export const getAllEmployees = (): Employee[] => {
  try {
    const savedUsers = localStorage.getItem('userAccounts_encrypted');
    if (savedUsers) {
      const encryptedData = JSON.parse(savedUsers);
      const decryptedData = decryptData(encryptedData);
      const users = JSON.parse(decryptedData);
      
      return users
        .filter((user: any) => user.role === 'employee')
        .map((user: any) => ({
          id: user.id,
          username: user.username,
          companyName: user.companyName
        }));
    }
  } catch (error) {
    console.error('Error loading employees:', error);
  }
  
  return [];
};

/**
 * Create a persistent work assignment storage key
 */
const getWorkAssignmentKey = () => 'workAssignments_v2';

/**
 * Save work assignments to localStorage
 */
const saveWorkAssignments = (assignments: WorkAssignment[]) => {
  try {
    localStorage.setItem(getWorkAssignmentKey(), JSON.stringify(assignments));
    console.log('💾 Work assignments saved to localStorage');
  } catch (error) {
    console.error('Error saving work assignments:', error);
  }
};

/**
 * Load work assignments from localStorage
 */
const loadWorkAssignments = (): WorkAssignment[] => {
  try {
    const saved = localStorage.getItem(getWorkAssignmentKey());
    if (saved) {
      const assignments = JSON.parse(saved);
      console.log(`📋 Loaded ${assignments.length} work assignments from localStorage`);
      return assignments;
    }
  } catch (error) {
    console.error('Error loading work assignments:', error);
  }
  return [];
};

/**
 * Check if work assignments are still valid (signs still exist and have correct status)
 */
const areAssignmentsValid = (assignments: WorkAssignment[], currentSigns: SignData[]): boolean => {
  if (assignments.length === 0) return false;
  
  // Check if all assigned signs still exist and have the correct status
  for (const assignment of assignments) {
    for (const sign of [...assignment.placementSigns, ...assignment.removalSigns]) {
      const currentSign = currentSigns.find(s => s.id === sign.id);
      if (!currentSign) {
        console.log(`❌ Sign ${sign.id} no longer exists, assignments invalid`);
        return false;
      }
      
      // Check if placement signs are still confirmed
      if (assignment.placementSigns.some(s => s.id === sign.id) && currentSign.status !== 'confirmed') {
        console.log(`❌ Placement sign ${sign.id} status changed from confirmed to ${currentSign.status}, assignments invalid`);
        return false;
      }
      
      // Check if removal signs are still removal-confirmed
      if (assignment.removalSigns.some(s => s.id === sign.id) && currentSign.status !== 'removal-confirmed') {
        console.log(`❌ Removal sign ${sign.id} status changed from removal-confirmed to ${currentSign.status}, assignments invalid`);
        return false;
      }
    }
  }
  
  return true;
};

/**
 * Group signs by location using improved clustering algorithm
 */
export const clusterSignsByLocation = (signs: SignData[], numClusters: number): SignData[][] => {
  if (signs.length === 0 || numClusters <= 0) return [];
  if (numClusters >= signs.length) {
    // Each sign gets its own cluster
    return signs.map(sign => [sign]);
  }
  
  // K-means clustering with multiple iterations for better results
  let bestClusters: SignData[][] = [];
  let bestInertia = Infinity;
  
  // Try multiple random initializations
  for (let attempt = 0; attempt < 5; attempt++) {
    const clusters: SignData[][] = Array(numClusters).fill(null).map(() => []);
    
    // Initialize cluster centers using k-means++ method for better distribution
    const centers = [];
    
    // First center is random
    const firstSign = signs[Math.floor(Math.random() * signs.length)];
    centers.push({ lat: firstSign.lat, lng: firstSign.lng });
    
    // Subsequent centers are chosen based on distance from existing centers
    for (let i = 1; i < numClusters; i++) {
      const distances = signs.map(sign => {
        const minDistToCenter = Math.min(...centers.map(center => 
          calculateDistance(sign.lat, sign.lng, center.lat, center.lng)
        ));
        return minDistToCenter * minDistToCenter; // Square for probability weighting
      });
      
      const totalDistance = distances.reduce((sum, d) => sum + d, 0);
      const random = Math.random() * totalDistance;
      
      let cumulative = 0;
      for (let j = 0; j < signs.length; j++) {
        cumulative += distances[j];
        if (cumulative >= random) {
          centers.push({ lat: signs[j].lat, lng: signs[j].lng });
          break;
        }
      }
    }
    
    // Perform k-means iterations
    for (let iteration = 0; iteration < 10; iteration++) {
      // Clear clusters
      clusters.forEach(cluster => cluster.length = 0);
      
      // Assign each sign to the nearest cluster center
      signs.forEach(sign => {
        let minDistance = Infinity;
        let closestCluster = 0;
        
        centers.forEach((center, index) => {
          const distance = calculateDistance(sign.lat, sign.lng, center.lat, center.lng);
          if (distance < minDistance) {
            minDistance = distance;
            closestCluster = index;
          }
        });
        
        clusters[closestCluster].push(sign);
      });
      
      // Update cluster centers
      let centersChanged = false;
      centers.forEach((center, index) => {
        if (clusters[index].length > 0) {
          const newCenter = calculateCenter(clusters[index]);
          if (Math.abs(newCenter.lat - center.lat) > 0.001 || Math.abs(newCenter.lng - center.lng) > 0.001) {
            center.lat = newCenter.lat;
            center.lng = newCenter.lng;
            centersChanged = true;
          }
        }
      });
      
      if (!centersChanged) break; // Converged
    }
    
    // Calculate inertia (sum of squared distances from points to their cluster centers)
    let inertia = 0;
    clusters.forEach((cluster, index) => {
      cluster.forEach(sign => {
        const distance = calculateDistance(sign.lat, sign.lng, centers[index].lat, centers[index].lng);
        inertia += distance * distance;
      });
    });
    
    if (inertia < bestInertia) {
      bestInertia = inertia;
      bestClusters = clusters.map(cluster => [...cluster]); // Deep copy
    }
  }
  
  // Remove empty clusters
  const nonEmptyClusters = bestClusters.filter(cluster => cluster.length > 0);
  
  console.log(`🗺️ Created ${nonEmptyClusters.length} location clusters with inertia ${bestInertia.toFixed(2)}`);
  
  return nonEmptyClusters;
};

/**
 * Distribute work among employees based on location and workload
 */
export const distributeWorkAmongEmployees = (
  placementSigns: SignData[],
  removalSigns: SignData[]
): WorkAssignment[] => {
  const employees = getAllEmployees();
  
  if (employees.length === 0) {
    console.log('📋 No employees found for work distribution');
    return [];
  }
  
  console.log(`👥 Distributing work among ${employees.length} employees`);
  console.log(`📍 ${placementSigns.length} placement signs, ${removalSigns.length} removal signs`);
  
  // Check if we have valid cached assignments
  const cachedAssignments = loadWorkAssignments();
  const allCurrentSigns = [...placementSigns, ...removalSigns];
  
  if (cachedAssignments.length > 0 && areAssignmentsValid(cachedAssignments, allCurrentSigns)) {
    console.log('✅ Using valid cached work assignments');
    return cachedAssignments;
  }
  
  console.log('🔄 Creating new work assignments...');
  
  // Combine all signs for clustering
  const allSigns = [...placementSigns, ...removalSigns];
  
  if (allSigns.length === 0) {
    const emptyAssignments = employees.map(emp => ({
      employeeId: emp.id,
      employeeName: emp.username,
      placementSigns: [],
      removalSigns: [],
      totalSigns: 0,
      centerLat: 50.8503,
      centerLng: 4.3517
    }));
    saveWorkAssignments(emptyAssignments);
    return emptyAssignments;
  }
  
  // Cluster signs by location
  const signClusters = clusterSignsByLocation(allSigns, employees.length);
  
  console.log(`🗺️ Created ${signClusters.length} location clusters`);
  
  // Assign clusters to employees
  const assignments: WorkAssignment[] = [];
  
  employees.forEach((employee, index) => {
    const cluster = signClusters[index] || [];
    
    // Separate placement and removal signs within this cluster
    const clusterPlacementSigns = cluster.filter(sign => 
      placementSigns.some(ps => ps.id === sign.id)
    );
    const clusterRemovalSigns = cluster.filter(sign => 
      removalSigns.some(rs => rs.id === sign.id)
    );
    
    const center = calculateCenter(cluster);
    
    const assignment: WorkAssignment = {
      employeeId: employee.id,
      employeeName: employee.username,
      placementSigns: clusterPlacementSigns,
      removalSigns: clusterRemovalSigns,
      totalSigns: cluster.length,
      centerLat: center.lat,
      centerLng: center.lng
    };
    
    assignments.push(assignment);
    
    console.log(`👤 ${employee.username}: ${clusterPlacementSigns.length} placements, ${clusterRemovalSigns.length} removals (total: ${cluster.length})`);
  });
  
  // Balance workload if there's significant imbalance
  balanceWorkload(assignments, placementSigns, removalSigns);
  
  // Save assignments to cache
  saveWorkAssignments(assignments);
  
  return assignments;
};

/**
 * Balance workload among employees if there's significant imbalance
 */
const balanceWorkload = (
  assignments: WorkAssignment[],
  allPlacementSigns: SignData[],
  allRemovalSigns: SignData[]
): void => {
  if (assignments.length <= 1) return;
  
  const totalSigns = allPlacementSigns.length + allRemovalSigns.length;
  const averageLoad = totalSigns / assignments.length;
  const maxImbalance = Math.ceil(averageLoad * 0.4); // Allow 40% imbalance
  
  console.log(`⚖️ Balancing workload - average: ${averageLoad.toFixed(1)}, max imbalance: ${maxImbalance}`);
  
  // Find overloaded and underloaded employees
  const overloaded = assignments.filter(a => a.totalSigns > averageLoad + maxImbalance);
  const underloaded = assignments.filter(a => a.totalSigns < averageLoad - maxImbalance);
  
  if (overloaded.length === 0 || underloaded.length === 0) {
    console.log('✅ Workload is already balanced');
    return;
  }
  
  // Redistribute signs from overloaded to underloaded employees
  overloaded.forEach(overloadedEmp => {
    while (overloadedEmp.totalSigns > averageLoad + maxImbalance && underloaded.length > 0) {
      const underloadedEmp = underloaded.find(u => u.totalSigns < averageLoad - maxImbalance);
      if (!underloadedEmp) break;
      
      // Find the sign in overloaded employee that's closest to underloaded employee
      const allOverloadedSigns = [...overloadedEmp.placementSigns, ...overloadedEmp.removalSigns];
      if (allOverloadedSigns.length === 0) break;
      
      let closestSign = allOverloadedSigns[0];
      let minDistance = calculateDistance(
        closestSign.lat, closestSign.lng,
        underloadedEmp.centerLat, underloadedEmp.centerLng
      );
      
      allOverloadedSigns.forEach(sign => {
        const distance = calculateDistance(
          sign.lat, sign.lng,
          underloadedEmp.centerLat, underloadedEmp.centerLng
        );
        if (distance < minDistance) {
          minDistance = distance;
          closestSign = sign;
        }
      });
      
      // Move the closest sign
      const isPlacementSign = overloadedEmp.placementSigns.some(s => s.id === closestSign.id);
      
      if (isPlacementSign) {
        overloadedEmp.placementSigns = overloadedEmp.placementSigns.filter(s => s.id !== closestSign.id);
        underloadedEmp.placementSigns.push(closestSign);
      } else {
        overloadedEmp.removalSigns = overloadedEmp.removalSigns.filter(s => s.id !== closestSign.id);
        underloadedEmp.removalSigns.push(closestSign);
      }
      
      overloadedEmp.totalSigns--;
      underloadedEmp.totalSigns++;
      
      // Recalculate centers
      const overloadedAllSigns = [...overloadedEmp.placementSigns, ...overloadedEmp.removalSigns];
      const underloadedAllSigns = [...underloadedEmp.placementSigns, ...underloadedEmp.removalSigns];
      
      const overloadedCenter = calculateCenter(overloadedAllSigns);
      const underloadedCenter = calculateCenter(underloadedAllSigns);
      
      overloadedEmp.centerLat = overloadedCenter.lat;
      overloadedEmp.centerLng = overloadedCenter.lng;
      underloadedEmp.centerLat = underloadedCenter.lat;
      underloadedEmp.centerLng = underloadedCenter.lng;
      
      console.log(`🔄 Moved sign from ${overloadedEmp.employeeName} to ${underloadedEmp.employeeName}`);
    }
  });
  
  console.log('✅ Workload balancing completed');
};

/**
 * Get work assignment for a specific employee
 */
export const getEmployeeWorkAssignment = (employeeId: string): WorkAssignment | null => {
  // Get confirmed signs for placement and removal-confirmed signs for removal
  const allSigns = JSON.parse(localStorage.getItem('allSigns') || '[]');
  const placementSigns = allSigns.filter((sign: SignData) => sign.status === 'confirmed');
  const removalSigns = allSigns.filter((sign: SignData) => sign.status === 'removal-confirmed');
  
  console.log(`🔍 Getting work assignment for employee ${employeeId}`);
  console.log(`📊 Available signs: ${placementSigns.length} placement, ${removalSigns.length} removal`);
  
  const assignments = distributeWorkAmongEmployees(placementSigns, removalSigns);
  const assignment = assignments.find(assignment => assignment.employeeId === employeeId);
  
  if (assignment) {
    console.log(`✅ Found assignment for employee: ${assignment.placementSigns.length} placement, ${assignment.removalSigns.length} removal`);
  } else {
    console.log(`❌ No assignment found for employee ${employeeId}`);
  }
  
  return assignment || null;
};

/**
 * Clear cached work assignments (call when signs are updated)
 */
export const clearWorkAssignments = (): void => {
  localStorage.removeItem(getWorkAssignmentKey());
  console.log('🗑️ Cleared cached work assignments');
};

/**
 * Add test data for work distribution
 */
export const addTestDataForWorkDistribution = (): void => {
  console.log('🧪 Adding test data for work distribution...');
  
  // Clear existing assignments to force recalculation
  clearWorkAssignments();
  
  // Test coordinates around Belgium
  const testLocations = [
    // Brussels area
    { lat: 50.8503, lng: 4.3517, area: 'Brussels' },
    { lat: 50.8467, lng: 4.3525, area: 'Brussels' },
    { lat: 50.8485, lng: 4.3490, area: 'Brussels' },
    { lat: 50.8520, lng: 4.3550, area: 'Brussels' },
    
    // Antwerp area
    { lat: 51.2194, lng: 4.4025, area: 'Antwerp' },
    { lat: 51.2150, lng: 4.4100, area: 'Antwerp' },
    { lat: 51.2230, lng: 4.3950, area: 'Antwerp' },
    
    // Ghent area
    { lat: 51.0543, lng: 3.7174, area: 'Ghent' },
    { lat: 51.0500, lng: 3.7200, area: 'Ghent' },
    { lat: 51.0580, lng: 3.7150, area: 'Ghent' },
    
    // Leuven area
    { lat: 50.8798, lng: 4.7005, area: 'Leuven' },
    { lat: 50.8750, lng: 4.7050, area: 'Leuven' },
    
    // Liège area
    { lat: 50.6326, lng: 5.5797, area: 'Liège' },
    { lat: 50.6300, lng: 5.5850, area: 'Liège' }
  ];
  
  const allSigns = JSON.parse(localStorage.getItem('allSigns') || '[]');
  const newSigns: SignData[] = [];
  
  // Create test signs for placement (confirmed status)
  testLocations.slice(0, 8).forEach((location, index) => {
    const sign: SignData = {
      id: `test-placement-${Date.now()}-${index}`,
      userId: 'test-user',
      companyName: 'Test Vastgoed',
      address: `${location.area} Teststraat ${index + 1}, Belgium`,
      category: 'B',
      boardType: 'lichtbord-batterij',
      lat: location.lat,
      lng: location.lng,
      status: 'confirmed',
      imageUrl: 'https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg?auto=compress&cs=tinysrgb&w=600',
      createdAt: new Date(Date.now() - (index * 24 * 60 * 60 * 1000)).toISOString(),
      updatedAt: new Date().toISOString(),
      statusHistory: [
        { status: 'pending', date: new Date(Date.now() - (index * 24 * 60 * 60 * 1000)).toISOString() },
        { status: 'confirmed', date: new Date().toISOString() }
      ]
    };
    newSigns.push(sign);
  });
  
  // Create test signs for removal (removal-confirmed status)
  testLocations.slice(8).forEach((location, index) => {
    const sign: SignData = {
      id: `test-removal-${Date.now()}-${index}`,
      userId: 'test-user',
      companyName: 'Test Vastgoed',
      address: `${location.area} Verwijderstraat ${index + 1}, Belgium`,
      category: 'B',
      boardType: 'lichtbord-batterij',
      lat: location.lat,
      lng: location.lng,
      status: 'removal-confirmed',
      imageUrl: 'https://images.pexels.com/photos/159306/construction-site-build-construction-work-159306.jpeg?auto=compress&cs=tinysrgb&w=600',
      createdAt: new Date(Date.now() - ((index + 20) * 24 * 60 * 60 * 1000)).toISOString(),
      updatedAt: new Date().toISOString(),
      placedAt: new Date(Date.now() - ((index + 15) * 24 * 60 * 60 * 1000)).toISOString(),
      removalRequestedAt: new Date(Date.now() - (2 * 24 * 60 * 60 * 1000)).toISOString(),
      statusHistory: [
        { status: 'pending', date: new Date(Date.now() - ((index + 20) * 24 * 60 * 60 * 1000)).toISOString() },
        { status: 'confirmed', date: new Date(Date.now() - ((index + 18) * 24 * 60 * 60 * 1000)).toISOString() },
        { status: 'placed', date: new Date(Date.now() - ((index + 15) * 24 * 60 * 60 * 1000)).toISOString() },
        { status: 'removal-requested', date: new Date(Date.now() - (5 * 24 * 60 * 60 * 1000)).toISOString() },
        { status: 'removal-confirmed', date: new Date().toISOString() }
      ]
    };
    newSigns.push(sign);
  });
  
  // Save test signs
  const updatedSigns = [...allSigns, ...newSigns];
  localStorage.setItem('allSigns', JSON.stringify(updatedSigns));
  
  console.log(`✅ Added ${newSigns.length} test signs (${testLocations.slice(0, 8).length} for placement, ${testLocations.slice(8).length} for removal)`);
};