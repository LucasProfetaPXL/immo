/*
  # Initial Schema for Sign Management System

  1. New Tables
    - users
      - id (uuid, primary key)
      - email (text, unique)
      - created_at (timestamp)
      - role (text)
    - signs
      - id (uuid, primary key)
      - company_name (text)
      - address (text)
      - lat (float8)
      - lng (float8)
      - status (text)
      - image_url (text)
      - created_at (timestamp)
      - updated_at (timestamp)
      - user_id (uuid, foreign key)
    - billing_details
      - id (uuid, primary key)
      - user_id (uuid, foreign key)
      - company_name (text)
      - address (text)
      - city (text)
      - postal_code (text)
      - country (text)
      - vat_number (text)
      - email (text)
      - created_at (timestamp)
    - invoices
      - id (uuid, primary key)
      - sign_id (uuid, foreign key)
      - billing_details_id (uuid, foreign key)
      - amount (float8)
      - status (text)
      - due_date (timestamp)
      - created_at (timestamp)
      - paid_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for user access control
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now(),
  role text NOT NULL CHECK (role IN ('admin', 'user'))
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Create signs table
CREATE TABLE IF NOT EXISTS signs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  address text NOT NULL,
  lat float8 NOT NULL,
  lng float8 NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'confirmed', 'placed', 'removal-requested', 'removal-confirmed', 'removed', 'trashed')),
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES users(id) NOT NULL
);

ALTER TABLE signs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own signs"
  ON signs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own signs"
  ON signs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own signs"
  ON signs
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create billing_details table
CREATE TABLE IF NOT EXISTS billing_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  company_name text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL,
  vat_number text NOT NULL,
  email text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE billing_details ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own billing details"
  ON billing_details
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own billing details"
  ON billing_details
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create invoices table
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sign_id uuid REFERENCES signs(id) NOT NULL,
  billing_details_id uuid REFERENCES billing_details(id) NOT NULL,
  amount float8 NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'unpaid', 'paid')),
  due_date timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  paid_at timestamptz
);

ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own invoices"
  ON invoices
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM signs
      WHERE signs.id = sign_id
      AND signs.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own invoices"
  ON invoices
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM signs
      WHERE signs.id = sign_id
      AND signs.user_id = auth.uid()
    )
  );

-- Create functions
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER signs_updated_at
  BEFORE UPDATE ON signs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();