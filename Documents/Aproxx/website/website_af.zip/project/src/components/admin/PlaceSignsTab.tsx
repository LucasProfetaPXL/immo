import React, { useState, useEffect } from 'react';
import { useSigns } from '../../context/SignsContext';
import { Search, Check, X, Tag, Download, Users } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import toast from 'react-hot-toast';
import { distributeWorkAmongEmployees, getAllEmployees } from '../../utils/workDistribution';
import { downloadImage } from '../../utils/imageUtils';
import { formatAddress } from '../../utils/addressFormatter.tsx';

type SubTabType = 'pending' | 'confirmed';

function PlaceSignsTab() {
  const { signs, updateSignStatus } = useSigns();
  const [activeSubTab, setActiveSubTab] = useState<SubTabType>('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSigns, setSelectedSigns] = useState<string[]>([]);
  const [adminNotes, setAdminNotes] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [workDistribution, setWorkDistribution] = useState<any[]>([]);
  const [showDistribution, setShowDistribution] = useState(false);
  
  // Filter signs by status and search query
  const filteredSigns = signs.filter(sign => {
    const statusMatch = 
      (activeSubTab === 'pending' && sign.status === 'pending') ||
      (activeSubTab === 'confirmed' && sign.status === 'confirmed');
    
    if (!statusMatch) return false;
    
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  // Calculate work distribution when confirmed signs change
  useEffect(() => {
    const confirmedSigns = signs.filter(sign => sign.status === 'confirmed');
    const removalSigns = signs.filter(sign => sign.status === 'removal-confirmed');
    
    if (confirmedSigns.length > 0 || removalSigns.length > 0) {
      const distribution = distributeWorkAmongEmployees(confirmedSigns, removalSigns);
      setWorkDistribution(distribution);
    } else {
      setWorkDistribution([]);
    }
  }, [signs]);

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  // Download image function
  const handleDownloadImage = (imageUrl: string, address: string) => {
    downloadImage(imageUrl, `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}`);
  };

  const handleToggleSelect = (id: string) => {
    setSelectedSigns(prev => {
      if (prev.includes(id)) {
        return prev.filter(signId => signId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedSigns.length === filteredSigns.length) {
      // Deselect all
      setSelectedSigns([]);
    } else {
      // Select all
      setSelectedSigns(filteredSigns.map(sign => sign.id));
    }
  };

  const handleNoteChange = (id: string, note: string) => {
    setAdminNotes(prev => ({
      ...prev,
      [id]: note
    }));
  };

  const handleConfirmSigns = () => {
    if (selectedSigns.length === 0) {
      toast.error('Selecteer ten minste één bord');
      return;
    }
    
    setIsSubmitting(true);
    
    // Update status for each selected sign
    setTimeout(() => {
      selectedSigns.forEach(id => {
        updateSignStatus(id, 'confirmed');
      });
      
      setSelectedSigns([]);
      setIsSubmitting(false);
      toast.success('Borden succesvol bevestigd! Werk wordt automatisch verdeeld onder werknemers.');
    }, 800);
  };

  const handleMarkPlaced = () => {
    if (selectedSigns.length === 0) {
      toast.error('Selecteer ten minste één bord');
      return;
    }
    
    setIsSubmitting(true);
    
    // Update status for each selected sign
    setTimeout(() => {
      selectedSigns.forEach(id => {
        updateSignStatus(id, 'placed');
      });
      
      setSelectedSigns([]);
      setIsSubmitting(false);
      toast.success('Borden succesvol gemarkeerd als geplaatst!');
    }, 800);
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Borden Plaatsen</h2>
      
      {/* Work Distribution Overview */}
      {workDistribution.length > 0 && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Users size={20} className="text-green-600 mr-2" />
              <div>
                <h3 className="font-medium text-green-800">Werkverdeling Actief</h3>
                <p className="text-sm text-green-600">
                  Werk is verdeeld onder {workDistribution.length} werknemers op basis van locatie
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowDistribution(!showDistribution)}
              className="btn btn-sm btn-secondary"
            >
              {showDistribution ? 'Verberg' : 'Toon'} Verdeling
            </button>
          </div>
          
          {showDistribution && (
            <div className="mt-4 pt-4 border-t border-green-200">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {workDistribution.map(assignment => (
                  <div key={assignment.employeeId} className="bg-white p-3 rounded border border-green-200">
                    <h4 className="font-medium text-green-800">{assignment.employeeName}</h4>
                    <div className="text-sm text-green-600 mt-1">
                      <div>📍 {assignment.placementSigns.length} borden plaatsen</div>
                      <div>🔄 {assignment.removalSigns.length} borden ophalen</div>
                      <div className="font-medium">Totaal: {assignment.totalSigns} borden</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
      
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-2 px-4">
            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'pending'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => {
                setActiveSubTab('pending');
                setSelectedSigns([]);
              }}
            >
              <span>In Afwachting</span>
              <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs bg-gray-100">
                {signs.filter(sign => sign.status === 'pending').length}
              </span>
            </button>
            
            <button
              className={`py-3 px-4 flex items-center border-b-2 font-medium text-sm ${
                activeSubTab === 'confirmed'
                  ? 'border-primary-blue text-primary-blue'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => {
                setActiveSubTab('confirmed');
                setSelectedSigns([]);
              }}
            >
              <span>Bevestigd</span>
              <span className="ml-2 px-2.5 py-0.5 rounded-full text-xs bg-gray-100">
                {signs.filter(sign => sign.status === 'confirmed').length}
              </span>
            </button>
          </nav>
        </div>
        
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className="relative mr-2">
                <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Zoek borden..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>
              
              <button
                onClick={handleSelectAll}
                className="text-sm text-primary-blue hover:text-blue-700 mr-2"
              >
                {selectedSigns.length === filteredSigns.length && filteredSigns.length > 0 
                  ? 'Deselecteer Alles' 
                  : 'Selecteer Alles'}
              </button>
              
            </div>
            
            <div>
              {activeSubTab === 'pending' ? (
                <button
                  onClick={handleConfirmSigns}
                  disabled={selectedSigns.length === 0 || isSubmitting}
                  className={`btn ${
                    selectedSigns.length === 0
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'btn-primary'
                  } ${isSubmitting ? 'opacity-75 cursor-wait' : ''}`}
                >
                  {isSubmitting 
                    ? 'Verwerken...' 
                    : `Bevestig Geselecteerde (${selectedSigns.length})`}
                </button>
              ) : (
                <button
                  onClick={handleMarkPlaced}
                  disabled={selectedSigns.length === 0 || isSubmitting}
                  className={`btn ${
                    selectedSigns.length === 0
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'btn-success'
                  } ${isSubmitting ? 'opacity-75 cursor-wait' : ''}`}
                >
                  {isSubmitting 
                    ? 'Verwerken...' 
                    : `Markeer als Geplaatst (${selectedSigns.length})`}
                </button>
              )}
            </div>
          </div>
          
          {filteredSigns.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              <p>Geen {activeSubTab === 'pending' ? 'in afwachting' : 'bevestigde'} borden gevonden</p>
              {activeSubTab === 'pending' && signs.filter(s => s.status === 'pending').length === 0 && (
                <p className="text-sm mt-2">Klik op "Test Data" om voorbeelddata toe te voegen</p>
              )}
            </div>
          ) : (
            <div className="fixed-height-container">
              <div className="space-y-2 p-2">
                {filteredSigns.map(sign => (
                  <div 
                    key={sign.id}
                    className={`p-4 rounded-md border transition-colors ${
                      selectedSigns.includes(sign.id)
                        ? 'border-primary-blue bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            className="mr-3 h-5 w-5 text-primary-blue rounded border-gray-300 focus:ring-primary-blue"
                            checked={selectedSigns.includes(sign.id)}
                            onChange={() => handleToggleSelect(sign.id)}
                          />
                          <div>
                            <p className="font-medium">{sign.companyName}</p>
                            <p className="text-sm text-gray-600">{formatAddress(sign.address)}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center mt-2 ml-8">
                          <span className={`status-badge status-${sign.status}`}>
                            {sign.status === 'pending' ? 'In afwachting' : 'Bevestigd'}
                          </span>
                          <span className="text-xs text-gray-500 ml-2">
                            Aangemaakt {formatDateInDutch(new Date(sign.createdAt))}
                          </span>
                        </div>
                        
                        <div className="ml-8 mt-3 flex items-start">
                          <Tag size={14} className="text-gray-400 mt-1 mr-2 flex-shrink-0" />
                          <input
                            type="text"
                            placeholder="Voeg admin notities toe..."
                            className="text-sm border-b border-dashed border-gray-300 focus:border-primary-blue focus:outline-none bg-transparent w-full py-1"
                            value={adminNotes[sign.id] || ''}
                            onChange={(e) => handleNoteChange(sign.id, e.target.value)}
                          />
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        {sign.imageUrl && (
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDownloadImage(sign.imageUrl!, sign.address);
                              }}
                              className="text-gray-500 hover:text-gray-700"
                              title="Download afbeelding"
                            >
                              <Download size={16} />
                            </button>
                            <div className="w-16 h-16 rounded-md overflow-hidden border border-gray-200">
                              <div 
                                style={{
                                  width: '100%',
                                  height: '100%',
                                  backgroundImage: `url(${sign.imageUrl})`,
                                  backgroundSize: 'cover',
                                  backgroundPosition: 'center',
                                }}
                              ></div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default PlaceSignsTab;