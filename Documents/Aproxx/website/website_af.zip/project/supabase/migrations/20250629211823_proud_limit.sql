/*
  # Create Images Table for Metadata Storage

  1. New Table
    - `images`
      - `id` (bigint, primary key, auto-generated)
      - `url` (text, not null) - stores the image URL
      - `description` (text, nullable) - optional description
      - `user_id` (uuid, foreign key) - links to auth.users
      - `created_at` (timestamp) - when the image was uploaded
      - `updated_at` (timestamp) - when metadata was last updated
      - `file_size` (bigint, nullable) - file size in bytes
      - `mime_type` (text, nullable) - image MIME type
      - `bucket_id` (text, nullable) - which storage bucket
      - `object_path` (text, nullable) - path within the bucket

  2. Security
    - Enable RLS on images table
    - Add policies for user access control
    - Users can only access their own images
*/

-- Create the images table
CREATE TABLE IF NOT EXISTS public.images (
    id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    url text NOT NULL,
    description text,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now(),
    file_size bigint,
    mime_type text,
    bucket_id text DEFAULT 'images',
    object_path text
);

-- Enable Row Level Security
ALTER TABLE public.images ENABLE ROW LEVEL SECURITY;

-- Create RLS Policies

-- Policy: Users can select their own images
CREATE POLICY "Allow users to select their own images" 
ON public.images 
FOR SELECT 
TO authenticated 
USING (auth.uid() = user_id);

-- Policy: Users can insert images (with user_id check)
CREATE POLICY "Allow users to insert images" 
ON public.images 
FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = user_id);

-- Policy: Users can update their own images
CREATE POLICY "Allow users to update their own images" 
ON public.images 
FOR UPDATE 
TO authenticated 
USING (auth.uid() = user_id) 
WITH CHECK (auth.uid() = user_id);

-- Policy: Users can delete their own images
CREATE POLICY "Allow users to delete their own images" 
ON public.images 
FOR DELETE 
TO authenticated 
USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_images_user_id ON public.images(user_id);
CREATE INDEX IF NOT EXISTS idx_images_created_at ON public.images(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_images_bucket_path ON public.images(bucket_id, object_path);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_images_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updated_at
CREATE TRIGGER images_updated_at
  BEFORE UPDATE ON public.images
  FOR EACH ROW
  EXECUTE FUNCTION update_images_updated_at();

-- Add helpful comments
COMMENT ON TABLE public.images IS 'Stores metadata for uploaded images';
COMMENT ON COLUMN public.images.url IS 'Public URL to access the image';
COMMENT ON COLUMN public.images.description IS 'Optional description of the image';
COMMENT ON COLUMN public.images.user_id IS 'ID of the user who uploaded the image';
COMMENT ON COLUMN public.images.file_size IS 'File size in bytes';
COMMENT ON COLUMN public.images.mime_type IS 'MIME type of the image (e.g., image/jpeg)';
COMMENT ON COLUMN public.images.bucket_id IS 'Storage bucket where the image is stored';
COMMENT ON COLUMN public.images.object_path IS 'Path to the object within the storage bucket';