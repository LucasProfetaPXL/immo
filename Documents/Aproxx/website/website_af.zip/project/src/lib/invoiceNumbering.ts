// Invoice numbering system
// Format: YYNNNNN where YY = last 2 digits of year, NNNNN = sequential number

interface InvoiceCounter {
  year: number;
  counter: number;
}

const STORAGE_KEY = 'invoiceCounter';

export const getNextInvoiceNumber = (): string => {
  const currentYear = new Date().getFullYear();
  const yearSuffix = currentYear.toString().slice(-2);
  
  // Get stored counter or initialize
  const stored = localStorage.getItem(STORAGE_KEY);
  let invoiceCounter: InvoiceCounter;
  
  if (stored) {
    invoiceCounter = JSON.parse(stored);
    
    // Reset counter if new year
    if (invoiceCounter.year !== currentYear) {
      invoiceCounter = {
        year: currentYear,
        counter: 1
      };
    } else {
      invoiceCounter.counter += 1;
    }
  } else {
    // First invoice ever
    invoiceCounter = {
      year: currentYear,
      counter: 1
    };
  }
  
  // Save updated counter
  localStorage.setItem(STORAGE_KEY, JSON.stringify(invoiceCounter));
  
  // Format: YYNNNNN (e.g., 2500001)
  const paddedCounter = invoiceCounter.counter.toString().padStart(5, '0');
  return `${yearSuffix}${paddedCounter}`;
};

export const getCurrentYearInvoiceCount = (): number => {
  const currentYear = new Date().getFullYear();
  const stored = localStorage.getItem(STORAGE_KEY);
  
  if (stored) {
    const invoiceCounter: InvoiceCounter = JSON.parse(stored);
    return invoiceCounter.year === currentYear ? invoiceCounter.counter : 0;
  }
  
  return 0;
};

export const getInvoicesByYear = (invoices: any[]): Record<string, any[]> => {
  const invoicesByYear: Record<string, any[]> = {};
  
  invoices.forEach(invoice => {
    const year = new Date(invoice.createdAt).getFullYear().toString();
    if (!invoicesByYear[year]) {
      invoicesByYear[year] = [];
    }
    invoicesByYear[year].push(invoice);
  });
  
  // Sort invoices within each year by creation date (newest first)
  Object.keys(invoicesByYear).forEach(year => {
    invoicesByYear[year].sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  });
  
  return invoicesByYear;
};