/*
  # Create images storage bucket and policies

  1. Storage Setup
    - Create 'images' storage bucket for file uploads
    - Configure bucket as public for easy access
    - Set file size limit to 10MB
    - Allow specific image mime types

  2. Security Policies
    - Allow authenticated users to upload images (INSERT)
    - Allow public access to view images (SELECT)
    - Allow authenticated users to delete their uploads (DELETE)
    - Allow authenticated users to update their uploads (UPDATE)

  3. Configuration
    - Public bucket for direct URL access
    - File size limit: 10MB per file
    - Allowed formats: JPEG, JPG, PNG, GIF, WebP
*/

-- Create the images storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'images',
  'images',
  true,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 10485760,
  allowed_mime_types = ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];

-- Remove any existing policies to avoid conflicts
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated deletes" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated updates" ON storage.objects;

-- Create policy for authenticated users to upload images
CREATE POLICY "Allow authenticated uploads"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'images');

-- Create policy for public access to view images
CREATE POLICY "Allow public downloads"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'images');

-- Create policy for authenticated users to delete images
CREATE POLICY "Allow authenticated deletes"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'images');

-- Create policy for authenticated users to update images
CREATE POLICY "Allow authenticated updates"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'images')
WITH CHECK (bucket_id = 'images');