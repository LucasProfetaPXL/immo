import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import UserNavigation from './UserNavigation';
import UserDashboardTab from './UserDashboardTab';
import PlaceOrderTab from './PlaceOrderTab';
import RemoveSignsTab from './RemoveSignsTab';
import SoldSignsTab from './SoldSignsTab';
import CostsTab from './CostsTab';
import StatusOverviewTab from './StatusOverviewTab';
import { LogOut, Menu, X } from 'lucide-react';

type UserTabType = 'dashboard' | 'place-order' | 'remove-signs' | 'sold-signs' | 'costs' | 'status-overview';

function UserDashboard() {
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState<UserTabType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };
  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Header */}
      <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <button
              onClick={toggleSidebar}
              className="mobile-menu-toggle mr-3 lg:hidden"
              aria-label="Toggle menu"
            >
              {sidebarCollapsed ? <Menu size={24} /> : <X size={24} />}
            </button>
            <h1 className="text-xl font-bold text-gray-900">Bordbeheer Systeem</h1>
            {currentUser && currentUser.companyName && (
              <>
                <span className="mx-3 text-gray-400">•</span>
                <span className="text-lg font-medium text-primary-blue">{currentUser.companyName}</span>
              </>
            )}
          </div>
          <button
            onClick={logout}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <LogOut size={16} className="mr-1" />
            <span>Uitloggen</span>
          </button>
        </div>
      </header>

      {/* Sidebar Overlay for mobile */}
      <div 
        className={`sidebar-overlay ${!sidebarCollapsed ? 'active' : ''} lg:hidden`}
        onClick={toggleSidebar}
      />
      {/* Sidebar */}
      <div className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''} fixed left-0 top-16 bottom-0 z-20`}>
        <UserNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>

      {/* Main Content */}
      <main className={`flex-1 mt-16 p-6 ${sidebarCollapsed ? 'sidebar-collapsed' : 'ml-64'}`}>
        <div className="bg-white rounded-lg shadow">
          <div style={{ display: activeTab === 'dashboard' ? 'block' : 'none' }}>
            <UserDashboardTab />
          </div>
          <div style={{ display: activeTab === 'place-order' ? 'block' : 'none' }}>
            <PlaceOrderTab />
          </div>
          <div style={{ display: activeTab === 'remove-signs' ? 'block' : 'none' }}>
            <RemoveSignsTab />
          </div>
          <div style={{ display: activeTab === 'sold-signs' ? 'block' : 'none' }}>
            <SoldSignsTab />
          </div>
          <div style={{ display: activeTab === 'costs' ? 'block' : 'none' }}>
            <CostsTab />
          </div>
          <div style={{ display: activeTab === 'status-overview' ? 'block' : 'none' }}>
            <StatusOverviewTab />
          </div>
        </div>
      </main>
    </div>
  );
}

export default UserDashboard;