import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { SignData, SignStatus, Company } from '../types';
import { mockSigns } from '../data/mockData';
import { differenceInHours } from 'date-fns';
import { clearWorkAssignments } from '../utils/workDistribution';

interface SignsContextType {
  signs: SignData[];
  companies: Company[];
  addSign: (sign: SignData) => void;
  updateSign: (id: string, updates: Partial<SignData>) => void;
  updateSignStatus: (id: string, newStatus: SignStatus) => void;
  deleteSign: (id: string) => void;
  getSigns: (status?: SignStatus, companyName?: string, search?: string) => SignData[];
  getSignById: (id: string) => SignData | undefined;
  markSendToTrash: (id: string) => void;
  restoreFromTrash: (id: string) => void;
  emptyTrash: () => void;
  trashedSigns: SignData[];
  getAllSigns: () => SignData[]; // For admin access
  getVisibleSigns: () => SignData[]; // For map and general display (excludes old removed signs)
  getAllSignsIncludingHidden: () => SignData[]; // For invoices and costs (includes all signs)
}

const SignsContext = createContext<SignsContextType | undefined>(undefined);

export function SignsProvider({ children }: { children: ReactNode }) {
  const [allSigns, setAllSigns] = useState<SignData[]>([]);
  const [allTrashedSigns, setAllTrashedSigns] = useState<SignData[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  // Check if a removed sign should be hidden (after 24 hours)
  const shouldHideRemovedSign = (sign: SignData): boolean => {
    if (sign.status !== 'removed') return false;
    
    // Find when the sign was marked as removed
    const removedStatusEntry = sign.statusHistory
      .slice()
      .reverse()
      .find(entry => entry.status === 'removed');
    
    if (!removedStatusEntry) return false;
    
    const removedDate = new Date(removedStatusEntry.date);
    const hoursSinceRemoved = differenceInHours(new Date(), removedDate);
    
    return hoursSinceRemoved >= 24;
  };

  // Filter signs for current user (unless admin) and exclude old removed signs
  const getFilteredSigns = (includeHiddenRemoved = false) => {
    const user = getCurrentUser();
    if (!user) return [];
    
    let signs = allSigns;
    
    // Filter by user unless admin
    if (!user.isAdmin) {
      signs = signs.filter(sign => sign.userId === user.id);
    }
    
    // Filter out old removed signs unless specifically requested
    if (!includeHiddenRemoved) {
      signs = signs.filter(sign => !shouldHideRemovedSign(sign));
    }
    
    return signs;
  };

  // Get visible signs (for map and general display)
  const getVisibleSigns = () => {
    return getFilteredSigns(false);
  };

  // Get all signs including hidden ones (for invoices and costs)
  const getAllSignsIncludingHidden = () => {
    const user = getCurrentUser();
    if (!user) return [];
    
    if (user.isAdmin) {
      return allSigns; // Admin sees all signs including hidden
    }
    
    // Regular users see their own signs including hidden removed ones
    return allSigns.filter(sign => sign.userId === user.id);
  };

  const getFilteredTrashedSigns = () => {
    const user = getCurrentUser();
    if (!user) return [];
    
    if (user.isAdmin) {
      return allTrashedSigns; // Admin sees all trashed signs
    }
    
    // Regular users only see their own trashed signs
    return allTrashedSigns.filter(sign => sign.userId === user.id);
  };

  // Initialize with mock data
  useEffect(() => {
    // Load signs from localStorage or use mock data
    const savedSigns = localStorage.getItem('allSigns');
    if (savedSigns) {
      try {
        setAllSigns(JSON.parse(savedSigns));
      } catch (error) {
        console.error('Error loading signs:', error);
        setAllSigns(mockSigns);
      }
    } else {
      setAllSigns(mockSigns);
    }

    // Load trashed signs
    const savedTrashedSigns = localStorage.getItem('allTrashedSigns');
    if (savedTrashedSigns) {
      try {
        setAllTrashedSigns(JSON.parse(savedTrashedSigns));
      } catch (error) {
        console.error('Error loading trashed signs:', error);
      }
    }
  }, []);

  // Save signs to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('allSigns', JSON.stringify(allSigns));
  }, [allSigns]);

  useEffect(() => {
    localStorage.setItem('allTrashedSigns', JSON.stringify(allTrashedSigns));
  }, [allTrashedSigns]);

  // Update companies when signs change
  useEffect(() => {
    const visibleSigns = getVisibleSigns();
    const uniqueCompanies = Array.from(
      new Set(visibleSigns.map(sign => sign.companyName))
    ).map(name => {
      const companySignsCount = visibleSigns.filter(sign => 
        sign.companyName === name && 
        sign.status !== 'trashed' && 
        sign.status !== 'deleted'
      ).length;
      
      return {
        name,
        signsCount: companySignsCount
      };
    });
    
    setCompanies(uniqueCompanies);
  }, [allSigns]);

  const addSign = (sign: SignData) => {
    const user = getCurrentUser();
    if (!user || user.isAdmin) return; // Only regular users can add signs
    
    const newSign = {
      ...sign,
      userId: user.id, // Associate sign with current user
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      statusHistory: [
        { status: sign.status, date: new Date().toISOString() }
      ]
    };
    
    setAllSigns(prevSigns => [...prevSigns, newSign]);
    
    // Clear work assignments when new signs are added
    clearWorkAssignments();
  };

  const updateSign = (id: string, updates: Partial<SignData>) => {
    setAllSigns(prevSigns => 
      prevSigns.map(sign => 
        sign.id === id 
          ? { 
              ...sign, 
              ...updates, 
              updatedAt: new Date().toISOString() 
            } 
          : sign
      )
    );
    
    // Clear work assignments when signs are updated
    clearWorkAssignments();
  };

  const updateSignStatus = (id: string, newStatus: SignStatus) => {
    setAllSigns(prevSigns => 
      prevSigns.map(sign => {
        if (sign.id === id) {
          const updatedSign = { 
            ...sign, 
            status: newStatus, 
            updatedAt: new Date().toISOString(),
            statusHistory: [
              ...sign.statusHistory,
              { status: newStatus, date: new Date().toISOString() }
            ]
          };
          
          // If status is changing to placed, record placedAt time
          if (newStatus === 'placed' && !sign.placedAt) {
            updatedSign.placedAt = new Date().toISOString();
          }
          
          // If status is changing to removal-requested, record removalRequestedAt time
          if (newStatus === 'removal-requested' && !sign.removalRequestedAt) {
            updatedSign.removalRequestedAt = new Date().toISOString();
          }
          
          return updatedSign;
        }
        return sign;
      })
    );
    
    // Clear work assignments when sign status changes
    clearWorkAssignments();
  };

  const markSendToTrash = (id: string) => {
    setAllSigns(prevSigns => {
      const signToTrash = prevSigns.find(sign => sign.id === id);
      if (!signToTrash) return prevSigns;
      
      const trashedSign = {
        ...signToTrash,
        status: 'trashed' as SignStatus,
        trashedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        statusHistory: [
          ...signToTrash.statusHistory,
          { status: 'trashed', date: new Date().toISOString() }
        ]
      };
      
      setAllTrashedSigns(prev => [...prev, trashedSign]);
      
      // Clear work assignments when signs are trashed
      clearWorkAssignments();
      
      return prevSigns.filter(sign => sign.id !== id);
    });
  };

  const restoreFromTrash = (id: string) => {
    setAllTrashedSigns(prevTrashed => {
      const signToRestore = prevTrashed.find(sign => sign.id === id);
      if (!signToRestore) return prevTrashed;
      
      const previousStatus = signToRestore.statusHistory[signToRestore.statusHistory.length - 2]?.status || 'removed';
      
      const restoredSign = {
        ...signToRestore,
        status: previousStatus as SignStatus,
        trashedAt: undefined,
        updatedAt: new Date().toISOString(),
        statusHistory: [
          ...signToRestore.statusHistory,
          { status: previousStatus, date: new Date().toISOString() }
        ]
      };
      
      setAllSigns(prev => [...prev, restoredSign]);
      
      // Clear work assignments when signs are restored
      clearWorkAssignments();
      
      return prevTrashed.filter(sign => sign.id !== id);
    });
  };

  const emptyTrash = () => {
    const user = getCurrentUser();
    if (!user) return;
    
    if (user.isAdmin) {
      setAllTrashedSigns([]);
    } else {
      // Only empty current user's trash
      setAllTrashedSigns(prev => prev.filter(sign => sign.userId !== user.id));
    }
    
    // Clear work assignments when trash is emptied
    clearWorkAssignments();
  };

  const deleteSign = (id: string) => {
    setAllSigns(prevSigns => prevSigns.filter(sign => sign.id !== id));
    setAllTrashedSigns(prevTrashed => prevTrashed.filter(sign => sign.id !== id));
    
    // Clear work assignments when signs are deleted
    clearWorkAssignments();
  };

  const getSigns = (status?: SignStatus, companyName?: string, search?: string) => {
    const visibleSigns = getVisibleSigns();
    
    return visibleSigns.filter(sign => {
      let match = true;
      
      if (status && sign.status !== status) {
        match = false;
      }
      
      if (companyName && sign.companyName !== companyName) {
        match = false;
      }
      
      if (search) {
        const searchLower = search.toLowerCase();
        const addressMatch = sign.address.toLowerCase().includes(searchLower);
        const companyMatch = sign.companyName.toLowerCase().includes(searchLower);
        
        if (!addressMatch && !companyMatch) {
          match = false;
        }
      }
      
      return match;
    });
  };

  const getSignById = (id: string) => {
    const allSignsIncludingHidden = getAllSignsIncludingHidden();
    const filteredTrashedSigns = getFilteredTrashedSigns();
    
    return allSignsIncludingHidden.find(sign => sign.id === id) || 
           filteredTrashedSigns.find(sign => sign.id === id);
  };

  const getAllSigns = () => {
    return getVisibleSigns(); // For general admin access, exclude old removed signs
  };

  const value = {
    signs: getVisibleSigns(),
    companies,
    addSign,
    updateSign,
    updateSignStatus,
    deleteSign,
    getSigns,
    getSignById,
    markSendToTrash,
    restoreFromTrash,
    emptyTrash,
    trashedSigns: getFilteredTrashedSigns(),
    getAllSigns,
    getVisibleSigns,
    getAllSignsIncludingHidden
  };

  return (
    <SignsContext.Provider value={value}>
      {children}
    </SignsContext.Provider>
  );
}

export function useSigns() {
  const context = useContext(SignsContext);
  if (context === undefined) {
    throw new Error('useSigns must be used within a SignsProvider');
  }
  return context;
}