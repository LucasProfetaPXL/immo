// Address validation utilities

/**
 * Check if an address is in Belgian Limburg
 * 
 * This function checks if the address contains Limburg postal codes or city names
 * 
 * @param address The full address string to check
 * @returns boolean True if the address is in Belgian Limburg
 */
export const isAddressInLimburg = (address: string): boolean => {
  // Convert address to lowercase for case-insensitive matching
  const lowerAddress = address.toLowerCase();

  // If address is empty, return false
  if (!lowerAddress) return false;
  
  // Check for "Limburg" or "Limbourg" in the address
  if (lowerAddress.includes('limburg') || lowerAddress.includes('limbourg')) {
    // Make sure it's Belgian Limburg, not Dutch Limburg
    if (lowerAddress.includes('nederland') || lowerAddress.includes('netherlands') || 
        lowerAddress.includes('holland') || lowerAddress.includes('nl-')) {
      return false;
    }
    return true;
  }
  
  // Check for Belgian postal codes in Limburg (3500-3999)
  const postalCodeMatch = lowerAddress.match(/\b(3[5-9]\d\d)\b/);
  if (postalCodeMatch) {
    return true;
  }
  
  // Check for major cities and towns in Belgian Limburg
  const limburgCities = [
    'hasselt', 'genk', 'sint-truiden', 'tongeren', 'beringen', 
    'lommel', 'maasmechelen', 'heusden', 'zolder', 'heusden-zolder', 'leopoldsburg', 
    'dilsen-stokkem', 'houthalen-helchteren', 'lanaken', 'bilzen', 
    'peer', 'bree', 'overpelt', 'neerpelt', 'pelt', 'hamont-achel', 'hamont', 'achel', 'ham', 
    'herk-de-stad', 'alken', 'borgloon', 'heers', 'hoeselt', 
    'kortessem', 'wellen', 'zonhoven', 'zutendaal', 'riemst', 
    'voeren', 'herstappe', 'gingelom', 'nieuwerkerken', 'diepenbeek', 'lummen',
    'as', 'opglabbeek', 'meeuwen-gruitrode', 'meeuwen', 'gruitrode', 'oudsbergen', 'tessenderlo'
  ];
  
  // Check if any Limburg city is in the address
  for (const city of limburgCities) {
    if (lowerAddress.includes(city)) {
      return true;
    }
  }
  
  // Check for specific Limburg regions
  const limburgRegions = ['haspengouw', 'kempen', 'maasland', 'mijnstreek'];
  for (const region of limburgRegions) {
    if (lowerAddress.includes(region)) {
      return true;
    }
  }
  
  // If none of the above conditions are met, assume it's not in Limburg
  return false;
};

/**
 * Get the province from an address
 * 
 * @param address The full address string
 * @returns string The detected province or "Unknown"
 */
export const getProvinceFromAddress = (address: string): string => {
  const lowerAddress = address.toLowerCase();
  
  // Check for Belgian provinces
  const provinces = [
    { name: 'Limburg', keywords: ['limburg', 'limbourg'] },
    { name: 'Antwerpen', keywords: ['antwerpen', 'antwerp', 'anvers'] },
    { name: 'Vlaams-Brabant', keywords: ['vlaams-brabant', 'vlaams brabant', 'flemish brabant'] },
    { name: 'Waals-Brabant', keywords: ['waals-brabant', 'waals brabant', 'brabant wallon'] },
    { name: 'Oost-Vlaanderen', keywords: ['oost-vlaanderen', 'oost vlaanderen', 'east flanders'] },
    { name: 'West-Vlaanderen', keywords: ['west-vlaanderen', 'west vlaanderen', 'west flanders'] },
    { name: 'Henegouwen', keywords: ['henegouwen', 'hainaut'] },
    { name: 'Luik', keywords: ['luik', 'liège', 'liege', 'lüttich'] },
    { name: 'Luxemburg', keywords: ['luxemburg', 'luxembourg'] },
    { name: 'Namen', keywords: ['namen', 'namur'] },
  ];
  
  for (const province of provinces) {
    for (const keyword of province.keywords) {
      if (lowerAddress.includes(keyword)) {
        return province.name;
      }
    }
  }
  
  // Check postal codes
  const postalCodeMatch = lowerAddress.match(/\b([0-9]{4})\b/);
  if (postalCodeMatch) {
    const postalCode = parseInt(postalCodeMatch[1]);
    
    if (postalCode >= 1000 && postalCode <= 1299) return 'Brussels';
    if (postalCode >= 1300 && postalCode <= 1499) return 'Waals-Brabant';
    if (postalCode >= 1500 && postalCode <= 1999) return 'Vlaams-Brabant';
    if (postalCode >= 2000 && postalCode <= 2999) return 'Antwerpen';
    if (postalCode >= 3000 && postalCode <= 3499) return 'Vlaams-Brabant';
    if (postalCode >= 3500 && postalCode <= 3999) return 'Limburg';
    if (postalCode >= 4000 && postalCode <= 4999) return 'Luik';
    if (postalCode >= 5000 && postalCode <= 5999) return 'Namen';
    if (postalCode >= 6000 && postalCode <= 6599) return 'Henegouwen';
    if (postalCode >= 6600 && postalCode <= 6999) return 'Luxemburg';
    if (postalCode >= 7000 && postalCode <= 7999) return 'Henegouwen';
    if (postalCode >= 8000 && postalCode <= 8999) return 'West-Vlaanderen';
    if (postalCode >= 9000 && postalCode <= 9999) return 'Oost-Vlaanderen';
  }
  
  return 'Onbekend';
};