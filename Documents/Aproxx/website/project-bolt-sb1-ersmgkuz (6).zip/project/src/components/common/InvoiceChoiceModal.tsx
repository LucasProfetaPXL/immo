import React from 'react';
import { X, FileText, Edit } from 'lucide-react';

interface InvoiceChoiceModalProps {
  onClose: () => void;
  onUseStandard: () => void;
  onUseCustom: () => void;
  standardBillingDetails: any;
  isGeneratingAll?: boolean;
}

function InvoiceChoiceModal({ onClose, onUseStandard, onUseCustom, standardBillingDetails, isGeneratingAll = false }: InvoiceChoiceModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-lg font-semibold">
            {isGeneratingAll ? 'Alle Facturen Genereren' : 'Factuur Genereren'}
          </h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6">
          <p className="text-gray-600 mb-6">
            {isGeneratingAll 
              ? 'Kies hoe u alle facturen wilt genereren:'
              : 'Kies hoe u de factuur wilt genereren:'
            }
          </p>
          
          <div className="space-y-4">
            {/* Standard Billing Option */}
            <div className="border border-gray-200 rounded-lg p-4 hover:border-primary-blue transition-colors">
              <button
                onClick={onUseStandard}
                className="w-full text-left"
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <FileText size={20} className="text-primary-blue" />
                  </div>
                  <div className="ml-3 flex-1">
                    <h4 className="font-medium text-gray-900">Standaard Factuurgegevens</h4>
                    <p className="text-sm text-gray-500 mt-1">
                      {isGeneratingAll 
                        ? 'Gebruik opgeslagen factuurgegevens voor alle facturen en download automatisch'
                        : 'Gebruik opgeslagen factuurgegevens en download automatisch'
                      }
                    </p>
                    {standardBillingDetails && (
                      <div className="mt-2 text-xs text-gray-400">
                        <p>{standardBillingDetails.name}</p>
                        <p>{standardBillingDetails.email}</p>
                      </div>
                    )}
                  </div>
                </div>
              </button>
            </div>
            
            {/* Custom Billing Option */}
            <div className="border border-gray-200 rounded-lg p-4 hover:border-primary-blue transition-colors">
              <button
                onClick={onUseCustom}
                className="w-full text-left"
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Edit size={20} className="text-orange-500" />
                  </div>
                  <div className="ml-3 flex-1">
                    <h4 className="font-medium text-gray-900">Specifieke Factuurgegevens</h4>
                    <p className="text-sm text-gray-500 mt-1">
                      {isGeneratingAll 
                        ? 'Voer aangepaste factuurgegevens in voor alle facturen'
                        : 'Voer aangepaste factuurgegevens in voor deze factuur'
                      }
                    </p>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end p-4 border-t">
          <button 
            onClick={onClose}
            className="btn btn-secondary"
          >
            Annuleren
          </button>
        </div>
      </div>
    </div>
  );
}

export default InvoiceChoiceModal;