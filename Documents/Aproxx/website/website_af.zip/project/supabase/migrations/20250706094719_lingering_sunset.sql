/*
  # Complete Database Schema for Sign Management System
  # Bevat ALLE functionaliteiten van het huidige systeem
  
  Dit script zet het volledige database schema op voor een nieuw Supabase account.
  Alle huidige functionaliteiten worden behouden:
  
  - Multi-user support (admin/user/employee)
  - Custom pricing per user
  - Belgian invoice follow-up system
  - Work distribution among employees
  - Image management with metadata
  - Placement details and proof images
  - Row Level Security voor data veiligheid
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- =====================================================
-- USERS TABLE - Gebruikersaccounts met rollen en pricing
-- =====================================================
CREATE TABLE IF NOT EXISTS public.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  username text UNIQUE,
  company_name text,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user', 'employee')),
  parent_user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_login timestamptz,
  pricing_settings jsonb DEFAULT '{
    "useCustomPricing": false,
    "baseCost": 220,
    "dailyCost": 4,
    "boardTypePricing": [
      {"boardType": "lichtbord-batterij", "baseCost": 220, "dailyCost": 4},
      {"boardType": "lichtbord-kabel", "baseCost": 180, "dailyCost": 3},
      {"boardType": "zomerbord", "baseCost": 0, "dailyCost": 0}
    ]
  }'::jsonb
);

-- =====================================================
-- SIGNS TABLE - Borden met volledige functionaliteit
-- =====================================================
CREATE TABLE IF NOT EXISTS public.signs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  company_name text NOT NULL,
  address text NOT NULL,
  category text DEFAULT 'B',
  board_type text DEFAULT 'lichtbord-batterij' CHECK (board_type IN ('lichtbord-batterij', 'lichtbord-kabel', 'zomerbord')),
  lat float8 NOT NULL,
  lng float8 NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending', 'confirmed', 'placed', 'removal-requested', 
    'removal-confirmed', 'removed', 'trashed', 'deleted'
  )),
  invoice_status text CHECK (invoice_status IN ('pending', 'invoiced')),
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  placed_at timestamptz,
  removal_requested_at timestamptz,
  trashed_at timestamptz,
  status_history jsonb DEFAULT '[]'::jsonb,
  admin_notes text,
  placement_details jsonb DEFAULT '{}'::jsonb,
  proof_images jsonb DEFAULT '{}'::jsonb
);

-- =====================================================
-- BILLING DETAILS TABLE - Factuurgegevens
-- =====================================================
CREATE TABLE IF NOT EXISTS public.billing_details (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL DEFAULT 'België',
  vat_number text NOT NULL,
  email text NOT NULL,
  reference text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- =====================================================
-- INVOICES TABLE - Facturen met Belgisch opvolgsysteem
-- =====================================================
CREATE TABLE IF NOT EXISTS public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text UNIQUE,
  sign_id text NOT NULL, -- Can be 'combined' for multiple signs
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  company_name text NOT NULL,
  address text NOT NULL,
  billing_details jsonb NOT NULL,
  amount float8 NOT NULL,
  status text NOT NULL DEFAULT 'unpaid' CHECK (status IN ('unpaid', 'paid')),
  reminder_status text NOT NULL DEFAULT 'none' CHECK (reminder_status IN ('none', 'first', 'second', 'final')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  due_date timestamptz NOT NULL,
  paid_at timestamptz,
  deleted_at timestamptz,
  last_reminder_sent timestamptz,
  days integer DEFAULT 0,
  sign_details jsonb,
  -- Belgian follow-up system fields
  first_reminder_sent timestamptz,
  waiting_period_end timestamptz,
  interest_start_date timestamptz,
  total_interest float8 DEFAULT 0,
  forfaitary_compensation float8 DEFAULT 0,
  total_amount_due float8,
  pricing_used jsonb
);

-- =====================================================
-- IMAGES TABLE - Metadata voor afbeeldingen
-- =====================================================
CREATE TABLE IF NOT EXISTS public.images (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  url text NOT NULL,
  description text,
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  file_size bigint,
  mime_type text,
  bucket_id text DEFAULT 'images',
  object_path text
);

-- =====================================================
-- STORAGE BUCKET CONFIGURATION
-- =====================================================
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'images',
  'images',
  true,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 10485760,
  allowed_mime_types = ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];

-- =====================================================
-- ROW LEVEL SECURITY SETUP
-- =====================================================

-- Enable RLS on all tables
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.signs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.billing_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.images ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- RLS POLICIES FOR USERS TABLE
-- =====================================================
CREATE POLICY "Users can read own data" ON public.users
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON public.users
  FOR UPDATE TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own data" ON public.users
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

-- =====================================================
-- RLS POLICIES FOR SIGNS TABLE
-- =====================================================
CREATE POLICY "Users can read own signs" ON public.signs
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own signs" ON public.signs
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own signs" ON public.signs
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own signs" ON public.signs
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- =====================================================
-- RLS POLICIES FOR BILLING DETAILS TABLE
-- =====================================================
CREATE POLICY "Users can read own billing details" ON public.billing_details
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own billing details" ON public.billing_details
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own billing details" ON public.billing_details
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own billing details" ON public.billing_details
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- =====================================================
-- RLS POLICIES FOR INVOICES TABLE
-- =====================================================
CREATE POLICY "Users can read own invoices" ON public.invoices
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own invoices" ON public.invoices
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own invoices" ON public.invoices
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own invoices" ON public.invoices
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- =====================================================
-- RLS POLICIES FOR IMAGES TABLE
-- =====================================================
CREATE POLICY "Users can read own images" ON public.images
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own images" ON public.images
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own images" ON public.images
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own images" ON public.images
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- =====================================================
-- STORAGE POLICIES
-- =====================================================

-- Remove any existing storage policies to avoid conflicts
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated deletes" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated updates" ON storage.objects;
DROP POLICY IF EXISTS "Give users access to own folder" ON storage.objects;
DROP POLICY IF EXISTS "Allow public access" ON storage.objects;

-- Create storage policies for images bucket
CREATE POLICY "Allow authenticated uploads" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow public downloads" ON storage.objects
  FOR SELECT TO public
  USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated deletes" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated updates" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'images')
  WITH CHECK (bucket_id = 'images');

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON public.users(username);
CREATE INDEX IF NOT EXISTS idx_users_role ON public.users(role);
CREATE INDEX IF NOT EXISTS idx_signs_user_id ON public.signs(user_id);
CREATE INDEX IF NOT EXISTS idx_signs_status ON public.signs(status);
CREATE INDEX IF NOT EXISTS idx_signs_created_at ON public.signs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_signs_lat_lng ON public.signs(lat, lng);
CREATE INDEX IF NOT EXISTS idx_signs_board_type ON public.signs(board_type);
CREATE INDEX IF NOT EXISTS idx_billing_details_user_id ON public.billing_details(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_user_id ON public.invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON public.invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_created_at ON public.invoices(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_invoices_due_date ON public.invoices(due_date);
CREATE INDEX IF NOT EXISTS idx_invoices_invoice_number ON public.invoices(invoice_number);
CREATE INDEX IF NOT EXISTS idx_images_user_id ON public.images(user_id);
CREATE INDEX IF NOT EXISTS idx_images_created_at ON public.images(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_images_bucket_path ON public.images(bucket_id, object_path);

-- =====================================================
-- FUNCTIONS AND TRIGGERS
-- =====================================================

-- Function for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at columns
CREATE TRIGGER users_updated_at
  BEFORE UPDATE ON public.users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER signs_updated_at
  BEFORE UPDATE ON public.signs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER billing_details_updated_at
  BEFORE UPDATE ON public.billing_details
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER invoices_updated_at
  BEFORE UPDATE ON public.invoices
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER images_updated_at
  BEFORE UPDATE ON public.images
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- =====================================================
-- TABLE COMMENTS FOR DOCUMENTATION
-- =====================================================
COMMENT ON TABLE public.users IS 'User accounts with roles and custom pricing settings';
COMMENT ON TABLE public.signs IS 'Sign placement and management data with full lifecycle tracking';
COMMENT ON TABLE public.billing_details IS 'Billing information for invoice generation';
COMMENT ON TABLE public.invoices IS 'Invoice management with Belgian follow-up system';
COMMENT ON TABLE public.images IS 'Image metadata and storage references';

COMMENT ON COLUMN public.users.pricing_settings IS 'Custom pricing configuration per user with board type specific pricing';
COMMENT ON COLUMN public.signs.status_history IS 'JSON array of status changes with timestamps and employee tracking';
COMMENT ON COLUMN public.signs.placement_details IS 'JSON object with specific location, orientation, and placement images';
COMMENT ON COLUMN public.signs.proof_images IS 'JSON object with proof images for placement and removal';
COMMENT ON COLUMN public.invoices.billing_details IS 'JSON snapshot of billing information at time of invoice creation';
COMMENT ON COLUMN public.invoices.sign_details IS 'JSON array for combined invoices with multiple signs';
COMMENT ON COLUMN public.invoices.pricing_used IS 'JSON object with pricing information used for this specific invoice';

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Verify all tables exist
SELECT 
  table_name,
  table_type
FROM information_schema.tables 
WHERE table_schema = 'public'
AND table_name IN ('users', 'signs', 'billing_details', 'invoices', 'images')
ORDER BY table_name;

-- Verify storage bucket exists
SELECT 
  id,
  name,
  public,
  file_size_limit,
  allowed_mime_types
FROM storage.buckets 
WHERE id = 'images';

-- Verify RLS is enabled
SELECT 
  schemaname,
  tablename,
  rowsecurity
FROM pg_tables 
WHERE schemaname = 'public'
AND tablename IN ('users', 'signs', 'billing_details', 'invoices', 'images')
ORDER BY tablename;

-- Success message
SELECT 'Database schema successfully installed! All tables, policies, and storage configuration are ready.' AS status;