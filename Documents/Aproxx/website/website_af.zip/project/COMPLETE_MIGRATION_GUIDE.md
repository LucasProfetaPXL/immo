# Complete Supabase Migration Guide

Dit document bevat alle stappen om je Sign Management System volledig over te zetten naar een nieuw Supabase account.

## 🎯 Wat wordt overgezet

### Database Schema
- **Users table** - Gebruikersaccounts met rollen (admin/user/employee)
- **Signs table** - Borden met locatie, status, afbeeldingen en placement details
- **Billing Details table** - Factuurgegevens per gebruiker
- **Invoices table** - Facturen met Belgisch opvolgsysteem
- **Images table** - Metadata voor geüploade afbeeldingen

### Storage Configuration
- **Images bucket** - Voor alle afbeeldingen (borden, placement photos, proof images)
- **Storage policies** - Veilige upload/download rechten
- **File size limits** - 10MB per bestand
- **MIME type restrictions** - Alleen afbeeldingen toegestaan

### Security Features
- **Row Level Security (RLS)** - Gebruikers zien alleen eigen data
- **Authentication policies** - Veilige toegang per rol
- **Storage policies** - Authenticated uploads, public downloads

### Application Features
- **Multi-user support** - Admin, regular users, employees
- **Custom pricing per user** - Verschillende tarieven per klant
- **Belgian invoice system** - Automatische herinneringen en rente
- **Work distribution** - Automatische verdeling van werk onder werknemers
- **Image management** - Upload, view, download van afbeeldingen
- **Placement details** - Specifieke locatie en oriëntatie informatie
- **Proof images** - Bewijs van plaatsing en ophaling

## 🚀 Migratie Stappen

### Stap 1: Nieuw Supabase Project
1. Ga naar [https://supabase.com/dashboard](https://supabase.com/dashboard)
2. Klik **"New Project"**
3. Vul project details in:
   - **Name**: `sign-management-system`
   - **Database Password**: Kies een sterk wachtwoord
   - **Region**: West EU (Ireland) of dichtstbijzijnde regio
4. Wacht tot project volledig is opgezet

### Stap 2: Database Schema Installeren
1. Ga naar **SQL Editor** in je nieuwe Supabase Dashboard
2. Klik **"New query"**
3. Kopieer de volledige inhoud van `COMPLETE_DATABASE_SCHEMA.sql`
4. Plak in de editor en klik **"Run"**
5. Controleer dat er geen errors zijn

### Stap 3: Environment Variables Updaten
1. Ga naar **Settings** → **API** in je nieuwe Supabase Dashboard
2. Kopieer de nieuwe waarden:
   - **Project URL**
   - **anon public key**
   - **service_role key**
3. Update je `.env` bestand met de nieuwe waarden

### Stap 4: Storage Verificatie
1. Ga naar **Storage** in je Supabase Dashboard
2. Controleer dat de **"images"** bucket bestaat en **Public** is
3. Ga naar **Storage** → **Policies**
4. Controleer dat alle 4 storage policies bestaan

### Stap 5: Applicatie Testen
1. Start de applicatie: `npm run dev`
2. Test alle functionaliteiten:
   - Login (admin/admin123)
   - Gebruiker aanmaken
   - Bord plaatsing
   - Afbeelding upload
   - Factuur generatie
   - Werknemer functionaliteiten

## 🔧 Troubleshooting

### Storage Upload Errors
Als je errors krijgt bij afbeelding uploads, voer dan `STORAGE_POLICIES_FIX.sql` uit.

### Authentication Errors
Controleer je environment variables en Site URL instellingen.

### Database Connection Errors
Controleer je `VITE_SUPABASE_URL` en internetverbinding.

## ✅ Verificatie Checklist

- [ ] Database schema volledig geïnstalleerd
- [ ] Storage bucket "images" bestaat en is public
- [ ] Alle 4 storage policies actief
- [ ] Environment variables bijgewerkt
- [ ] Admin login werkt (admin/admin123)
- [ ] Gebruiker kan worden aangemaakt
- [ ] Bord kan worden geplaatst
- [ ] Afbeelding upload werkt
- [ ] Factuur kan worden gegenereerd
- [ ] Werknemer functionaliteiten werken

## 📊 Data Migratie (Optioneel)

Als je bestaande data wilt overzetten:
1. Exporteer data uit oude account via SQL Editor
2. Importeer in nieuwe account na schema installatie
3. Update user IDs en foreign keys indien nodig

De nieuwe setup behoudt alle functionaliteiten van je huidige systeem!