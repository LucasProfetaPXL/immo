import React, { useState } from 'react';
import { useSigns } from '../../../context/SignsContext';
import { useInvoices } from '../../../context/InvoiceContext';
import { Search, Check, Filter, FileText, Settings } from 'lucide-react';
import { calculateSignCost } from '../../../utils/costCalculator';
import InvoiceModal from '../../common/InvoiceModal';
import InvoiceChoiceModal from '../../common/InvoiceChoiceModal';
import toast from 'react-hot-toast';
import { differenceInDays } from 'date-fns';

type StatusFilter = 'all' | 'placed' | 'removal-requested' | 'removed';

interface CostsMainTabProps {
  onInvoiceGenerated?: () => void;
}

function CostsMainTab({ onInvoiceGenerated }: CostsMainTabProps) {
  const { getAllSignsIncludingHidden } = useSigns(); // Use hidden signs for costs
  const { generateInvoice, generateAllInvoices, getUserBillingDetails, setUserBillingDetails } = useInvoices();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [selectedSignIds, setSelectedSignIds] = useState<string[]>([]);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showBillingModal, setShowBillingModal] = useState(false);
  const [showChoiceModal, setShowChoiceModal] = useState(false);
  const [currentSignId, setCurrentSignId] = useState<string | null>(null);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Get saved billing details
  const savedBillingDetails = getUserBillingDetails();
  
  // Get all signs including hidden ones for costs calculation
  const allSigns = getAllSignsIncludingHidden();
  
  // Filter signs that are eligible for cost calculation and haven't been invoiced
  const eligibleSigns = allSigns.filter(sign => 
    sign.status !== 'pending' && 
    sign.status !== 'confirmed' && 
    sign.status !== 'trashed' && 
    sign.status !== 'deleted' &&
    !sign.invoiceStatus // Only show signs that haven't been invoiced
  );
  
  // Apply search and status filters
  const filteredSigns = eligibleSigns.filter(sign => {
    let matchesSearch = true;
    let matchesStatus = true;
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      matchesSearch = 
        sign.address.toLowerCase().includes(query) ||
        sign.companyName.toLowerCase().includes(query);
    }
    
    if (statusFilter !== 'all') {
      matchesStatus = sign.status === statusFilter;
    }
    
    return matchesSearch && matchesStatus;
  });
  
  // Sort by status: removal-requested first, then placed, then removed
  const sortedSigns = [...filteredSigns].sort((a, b) => {
    const statusOrder = {
      'removal-requested': 1,
      'placed': 2,
      'removal-confirmed': 3,
      'removed': 4
    };
    
    return statusOrder[a.status] - statusOrder[b.status];
  });

  // Function to format address with line break
  const formatAddressWithBreak = (address: string) => {
    // Find a good place to break the address (after comma, space, or around middle)
    const midPoint = Math.floor(address.length / 2);
    let breakPoint = midPoint;
    
    // Look for comma or space near the middle
    for (let i = midPoint - 10; i <= midPoint + 10; i++) {
      if (i >= 0 && i < address.length) {
        if (address[i] === ',' || address[i] === ' ') {
          breakPoint = i + 1;
          break;
        }
      }
    }
    
    // If address is short, don't break
    if (address.length < 30) {
      return address;
    }
    
    const firstPart = address.substring(0, breakPoint).trim();
    const secondPart = address.substring(breakPoint).trim();
    
    return (
      <div>
        <div>{firstPart}</div>
        <div>{secondPart}</div>
      </div>
    );
  };

  const handleToggleSelect = (id: string) => {
    setSelectedSignIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(signId => signId !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  const handleSelectAll = () => {
    if (selectedSignIds.length === filteredSigns.length) {
      // Deselect all
      setSelectedSignIds([]);
    } else {
      // Select all
      setSelectedSignIds(filteredSigns.map(sign => sign.id));
    }
  };

  const handleGenerateInvoice = (signId: string) => {
    setCurrentSignId(signId);
    setIsGeneratingAll(false);
    
    if (savedBillingDetails) {
      // Show choice modal if we have saved billing details
      setShowChoiceModal(true);
    } else {
      // No saved billing details, go directly to manual entry
      setShowInvoiceModal(true);
    }
  };

  const handleGenerateAllInvoices = () => {
    // Only generate invoices for signs that can be invoiced and haven't been invoiced
    const eligibleForInvoicing = allSigns.filter(sign => 
      (sign.status === 'removal-requested' || sign.status === 'removal-confirmed' || sign.status === 'removed') && 
      !sign.invoiceStatus
    );
    
    if (eligibleForInvoicing.length === 0) {
      toast.error('Geen borden beschikbaar voor facturering');
      return;
    }
    
    setIsGeneratingAll(true);
    
    if (savedBillingDetails) {
      // Show choice modal if we have saved billing details
      setShowChoiceModal(true);
    } else {
      // No saved billing details, show error
      toast.error('Stel eerst factuurgegevens in via de instellingen knop');
    }
  };

  const handleUseStandardBilling = async () => {
    if (savedBillingDetails) {
      setIsGenerating(true);
      try {
        if (isGeneratingAll) {
          // Generate combined invoice for all eligible signs
          const invoiceIds = await generateAllInvoices(savedBillingDetails);
          if (invoiceIds.length > 0) {
            toast.success('Gecombineerde factuur succesvol gegenereerd en gedownload');
            
            // Switch to invoices tab if any invoices were generated
            if (onInvoiceGenerated) {
              onInvoiceGenerated();
            }
          } else {
            toast.error('Geen borden beschikbaar voor facturering');
          }
        } else if (currentSignId) {
          // Generate single invoice
          await generateInvoice(currentSignId, savedBillingDetails);
          toast.success('Factuur succesvol gegenereerd en gedownload');
          
          // Switch to invoices tab
          if (onInvoiceGenerated) {
            onInvoiceGenerated();
          }
        }
        
        setShowChoiceModal(false);
        setCurrentSignId(null);
        setIsGeneratingAll(false);
      } catch (error) {
        toast.error('Factuur genereren mislukt');
      } finally {
        setIsGenerating(false);
      }
    }
  };

  const handleUseCustomBilling = () => {
    setShowChoiceModal(false);
    setShowInvoiceModal(true);
  };

  const handleSubmitInvoice = async (billingDetails: any) => {
    setIsGenerating(true);
    try {
      if (isGeneratingAll) {
        // Generate combined invoice for all eligible signs with custom billing details
        const invoiceIds = await generateAllInvoices(billingDetails);
        if (invoiceIds.length > 0) {
          toast.success('Gecombineerde factuur succesvol gegenereerd en gedownload');
          
          // Switch to invoices tab if any invoices were generated
          if (onInvoiceGenerated) {
            onInvoiceGenerated();
          }
        } else {
          toast.error('Geen borden beschikbaar voor facturering');
        }
      } else if (currentSignId) {
        // Generate single invoice with custom billing details
        await generateInvoice(currentSignId, billingDetails);
        toast.success('Factuur succesvol gegenereerd en gedownload');
        
        // Switch to invoices tab
        if (onInvoiceGenerated) {
          onInvoiceGenerated();
        }
      }
      
      setShowInvoiceModal(false);
      setCurrentSignId(null);
      setIsGeneratingAll(false);
    } catch (error) {
      toast.error('Factuur genereren mislukt');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUpdateBillingDetails = (billingDetails: any) => {
    setUserBillingDetails(billingDetails);
    setShowBillingModal(false);
    toast.success('Factuurgegevens bijgewerkt');
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 space-y-2 sm:space-y-0">
        <h3 className="text-lg font-semibold">Bord Kosten</h3>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowBillingModal(true)}
            className="btn btn-secondary flex items-center"
          >
            <Settings size={16} className="mr-1" />
            <span>Factuurgegevens</span>
          </button>
          
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Zoek borden..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
            />
          </div>
          
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
              className="py-2 pl-9 pr-3 border border-gray-300 rounded-md text-sm appearance-none w-36"
            >
              <option value="all">Alle</option>
              <option value="placed">Actief</option>
              <option value="removal-requested">Verwijdering Aangevraagd</option>
              <option value="removed">Verwijderd</option>
            </select>
            <Filter size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </div>
          
          <button
            onClick={handleGenerateAllInvoices}
            className="btn btn-primary flex items-center"
            disabled={allSigns.filter(sign => 
              (sign.status === 'removal-requested' || sign.status === 'removal-confirmed' || sign.status === 'removed') && 
              !sign.invoiceStatus
            ).length === 0 || isGenerating}
          >
            <FileText size={16} className="mr-1" />
            <span>{isGenerating && isGeneratingAll ? 'Genereren...' : 'Genereer Alle'}</span>
          </button>
        </div>
      </div>
      
      {sortedSigns.length === 0 ? (
        <div className="text-center py-10 text-gray-500">
          <p>Geen borden gevonden die aan uw criteria voldoen</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-gray-200">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Adres
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Duur & Kosten
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acties
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sortedSigns.map(sign => {
                  // Calculate cost
                  const cost = calculateSignCost(sign);
                  
                  // Calculate days active
                  let daysActive = 0;
                  let activePeriod = '';
                  
                  if (sign.placedAt) {
                    const placedDate = new Date(sign.placedAt);
                    const endDate = sign.removalRequestedAt 
                      ? new Date(sign.removalRequestedAt) 
                      : new Date();
                    
                    // +1 omdat we beide dagen meetellen
                    daysActive = Math.max(0, differenceInDays(endDate, placedDate) + 1);
                    
                    activePeriod = `${new Date(sign.placedAt).toLocaleDateString()} - ${
                      sign.removalRequestedAt 
                        ? new Date(sign.removalRequestedAt).toLocaleDateString()
                        : 'Heden'
                    }`;
                  }
                  
                  // Calculate base cost and extra days cost
                  const baseCost = 220;
                  const extraDays = Math.max(0, daysActive - 30);
                  const extraDaysCost = extraDays * 4;
                  
                  return (
                    <tr key={sign.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900 text-sm leading-tight">
                          {formatAddressWithBreak(sign.address)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`status-badge status-${sign.status}`}>
                          {sign.status === 'placed' ? 'Geplaatst' : 
                           sign.status === 'removal-requested' ? 'Verwijdering Aangevraagd' : 
                           sign.status === 'removal-confirmed' ? 'Verwijderd' :
                           sign.status === 'removed' ? 'Verwijderd' : sign.status.replace('-', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {daysActive} dagen actief
                        </div>
                        <div className="text-xs text-gray-500">{activePeriod}</div>
                        <div className="font-medium text-gray-900 mt-1">
                          €{cost.toFixed(2)}
                          {extraDays > 0 && (
                            <span className="text-xs text-gray-500 ml-2">
                              (€{baseCost.toFixed(2)} + {extraDays} dagen × €4)
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        {/* Show generate invoice button for removal-related statuses */}
                        {(sign.status === 'removal-requested' || sign.status === 'removal-confirmed' || sign.status === 'removed') && (
                          <button 
                            onClick={() => handleGenerateInvoice(sign.id)}
                            className="btn btn-sm btn-primary"
                            disabled={isGenerating}
                          >
                            {isGenerating && currentSignId === sign.id ? 'Genereren...' : 'Genereer Factuur'}
                          </button>
                        )}
                        {/* Show status text for placed status */}
                        {sign.status === 'placed' && (
                          <span className="text-gray-400">
                            Actief
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Invoice Choice Modal */}
      {showChoiceModal && (
        <InvoiceChoiceModal 
          onClose={() => {
            setShowChoiceModal(false);
            setCurrentSignId(null);
            setIsGeneratingAll(false);
          }}
          onUseStandard={handleUseStandardBilling}
          onUseCustom={handleUseCustomBilling}
          standardBillingDetails={savedBillingDetails}
          isGeneratingAll={isGeneratingAll}
        />
      )}
      
      {/* Invoice Modal */}
      {showInvoiceModal && (
        <InvoiceModal 
          onClose={() => {
            setShowInvoiceModal(false);
            setCurrentSignId(null);
            setIsGeneratingAll(false);
          }}
          onSubmit={handleSubmitInvoice}
          existingBillingDetails={savedBillingDetails}
        />
      )}

      {/* Billing Details Modal */}
      {showBillingModal && (
        <InvoiceModal 
          onClose={() => setShowBillingModal(false)}
          onSubmit={handleUpdateBillingDetails}
          existingBillingDetails={savedBillingDetails}
          isBillingInfoUpdate={true}
        />
      )}
    </div>
  );
}

export default CostsMainTab;