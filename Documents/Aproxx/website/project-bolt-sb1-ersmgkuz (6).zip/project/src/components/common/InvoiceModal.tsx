import React, { useState } from 'react';
import { X } from 'lucide-react';

interface InvoiceModalProps {
  onClose: () => void;
  onSubmit: (billingDetails: any) => void;
  existingBillingDetails?: any;
  isBillingInfoUpdate?: boolean;
}

function InvoiceModal({ onClose, onSubmit, existingBillingDetails, isBillingInfoUpdate = false }: InvoiceModalProps) {
  const [formData, setFormData] = useState({
    name: existingBillingDetails?.name || '',
    address: existingBillingDetails?.address || '',
    city: existingBillingDetails?.city || '',
    postalCode: existingBillingDetails?.postalCode || '',
    country: existingBillingDetails?.country || 'België',
    vatNumber: existingBillingDetails?.vatNumber || '',
    email: existingBillingDetails?.email || '',
    reference: existingBillingDetails?.reference || ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    // Required fields
    const requiredFields = ['name', 'address', 'city', 'postalCode', 'country', 'vatNumber', 'email'];
    requiredFields.forEach(field => {
      if (!formData[field]) {
        newErrors[field] = 'Dit veld is verplicht';
      }
    });
    
    // Email validation
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Voer een geldig e-mailadres in';
    }
    
    // VAT number validation (basic format check)
    if (formData.vatNumber && !/^[A-Z]{2}[0-9A-Z]{6,12}$/.test(formData.vatNumber)) {
      newErrors.vatNumber = 'Voer een geldig BTW-nummer in (bijv. BE0123456789)';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) {
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate a short delay
    setTimeout(() => {
      onSubmit(formData);
      setIsSubmitting(false);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-lg font-semibold">
            {isBillingInfoUpdate ? 'Factuurgegevens Bijwerken' : 'Factuur Genereren'}
          </h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-4">
          <div className="space-y-4">
            <div>
              <label htmlFor="name" className="form-label">Bedrijfsnaam</label>
              <input 
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className={`form-input ${errors.name ? 'border-red-500' : ''}`}
              />
              {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
            </div>
            
            <div>
              <label htmlFor="address" className="form-label">Adres</label>
              <input 
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                className={`form-input ${errors.address ? 'border-red-500' : ''}`}
              />
              {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="city" className="form-label">Plaats</label>
                <input 
                  type="text"
                  id="city"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  className={`form-input ${errors.city ? 'border-red-500' : ''}`}
                />
                {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city}</p>}
              </div>
              
              <div>
                <label htmlFor="postalCode" className="form-label">Postcode</label>
                <input 
                  type="text"
                  id="postalCode"
                  name="postalCode"
                  value={formData.postalCode}
                  onChange={handleChange}
                  className={`form-input ${errors.postalCode ? 'border-red-500' : ''}`}
                />
                {errors.postalCode && <p className="text-red-500 text-xs mt-1">{errors.postalCode}</p>}
              </div>
            </div>
            
            <div>
              <label htmlFor="country" className="form-label">Land</label>
              <input 
                type="text"
                id="country"
                name="country"
                value={formData.country}
                onChange={handleChange}
                className={`form-input ${errors.country ? 'border-red-500' : ''}`}
              />
              {errors.country && <p className="text-red-500 text-xs mt-1">{errors.country}</p>}
            </div>
            
            <div>
              <label htmlFor="vatNumber" className="form-label">BTW Nummer</label>
              <input 
                type="text"
                id="vatNumber"
                name="vatNumber"
                value={formData.vatNumber}
                onChange={handleChange}
                className={`form-input ${errors.vatNumber ? 'border-red-500' : ''}`}
                placeholder="bijv. BE0123456789"
              />
              {errors.vatNumber && <p className="text-red-500 text-xs mt-1">{errors.vatNumber}</p>}
            </div>
            
            <div>
              <label htmlFor="email" className="form-label">E-mail</label>
              <input 
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className={`form-input ${errors.email ? 'border-red-500' : ''}`}
              />
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
            </div>
            
            <div>
              <label htmlFor="reference" className="form-label">Opmerking (Optioneel)</label>
              <textarea 
                id="reference"
                name="reference"
                value={formData.reference}
                onChange={handleChange}
                className="form-input resize-none"
                rows={3}
                placeholder="Eventuele opmerkingen voor op de factuur..."
              />
            </div>
          </div>
          
          <div className="flex justify-end mt-6 space-x-2">
            <button 
              type="button" 
              onClick={onClose}
              className="btn btn-secondary"
            >
              Annuleren
            </button>
            
            <button 
              type="submit"
              className={`btn btn-primary ${isSubmitting ? 'opacity-75 cursor-wait' : ''}`}
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Verwerken...' : isBillingInfoUpdate ? 'Bijwerken' : 'Genereer Factuur'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default InvoiceModal;