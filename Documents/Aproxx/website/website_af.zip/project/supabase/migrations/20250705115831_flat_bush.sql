-- Database Schema Verification
-- Voer deze SQL uit om te controleren of alle tabellen correct zijn aangemaakt

-- 1. Controleer alle tabellen
SELECT 
  table_name,
  table_type
FROM information_schema.tables 
WHERE table_schema = 'public'
ORDER BY table_name;

-- 2. Controleer users tabel structuur
SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns 
WHERE table_name = 'users' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- 3. Controleer signs tabel structuur
SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns 
WHERE table_name = 'signs' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- 4. Controleer invoices tabel structuur
SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns 
WHERE table_name = 'invoices' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- 5. Controleer billing_details tabel structuur
SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns 
WHERE table_name = 'billing_details' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- 6. Controleer images tabel structuur
SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns 
WHERE table_name = 'images' 
AND table_schema = 'public'
ORDER BY ordinal_position;

-- 7. Controleer RLS status voor alle tabellen
SELECT 
  schemaname,
  tablename,
  rowsecurity
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY tablename;

-- 8. Controleer alle RLS policies
SELECT 
  schemaname,
  tablename,
  policyname,
  cmd,
  roles
FROM pg_policies 
WHERE schemaname = 'public'
ORDER BY tablename, policyname;

-- 9. Controleer indexes
SELECT 
  indexname,
  tablename,
  indexdef
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- 10. Controleer triggers
SELECT 
  trigger_name,
  event_manipulation,
  event_object_table,
  action_statement
FROM information_schema.triggers 
WHERE trigger_schema = 'public'
ORDER BY event_object_table, trigger_name;

-- 11. Test data insert (optioneel - voor verificatie)
-- Uncomment de volgende regels om test data in te voegen:

/*
-- Test user insert
INSERT INTO public.users (email, role, company_name, username) 
VALUES ('test@example.com', 'user', 'Test Company', 'testuser')
ON CONFLICT (email) DO NOTHING;

-- Controleer of de insert werkte
SELECT id, email, role, company_name, username, created_at 
FROM public.users 
WHERE email = 'test@example.com';
*/