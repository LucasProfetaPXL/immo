import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const serviceRoleKey = import.meta.env.VITE_SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables:', {
    hasUrl: !!supabaseUrl,
    hasAnonKey: !!supabaseAnonKey,
    hasServiceRole: !!serviceRoleKey
  });
  throw new Error(`Missing Supabase environment variables. Please check your .env file.
  
REQUIRED VARIABLES:
- VITE_SUPABASE_URL: ${supabaseUrl ? '✅ Set' : '❌ Missing'}
- VITE_SUPABASE_ANON_KEY: ${supabaseAnonKey ? '✅ Set' : '❌ Missing'}
- VITE_SUPABASE_SERVICE_ROLE_KEY: ${serviceRoleKey ? '✅ Set' : '❌ Missing'}

Get these from your Supabase Dashboard → Settings → API`);
}

// Validate URL format
try {
  new URL(supabaseUrl);
} catch (error) {
  throw new Error(`Invalid Supabase URL format: ${supabaseUrl}
  
Expected format: https://yourprojectid.supabase.co
Make sure there's no trailing slash and it's a valid URL.`);
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Create service role client for storage operations
const supabaseServiceRole = serviceRoleKey ? createClient(supabaseUrl, serviceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
}) : null;

// Test Supabase connection
export const testSupabaseConnection = async (): Promise<boolean> => {
  try {
    console.log('Testing Supabase connection...', { url: supabaseUrl });
    
    // Test with a simple query that doesn't require specific tables
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error('Supabase connection test failed:', error);
      return false;
    }
    
    console.log('Supabase connection test successful');
    return true;
  } catch (error) {
    console.error('Supabase connection test error:', error);
    return false;
  }
};

// Upload image to Supabase Storage using service role
export const uploadImage = async (file: File, folder: string = 'signs'): Promise<string> => {
  try {
    console.log('🖼️ Starting image upload...', { 
      fileName: file.name, 
      fileSize: file.size, 
      folder,
      supabaseUrl: supabaseUrl,
      hasServiceRole: !!supabaseServiceRole
    });

    // Validate file
    if (!file || file.size === 0) {
      throw new Error('Invalid file: File is empty or undefined');
    }

    // Check file size (limit to 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      throw new Error('File too large. Maximum size is 10MB.');
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      throw new Error(`Invalid file type: ${file.type}. Allowed types: ${allowedTypes.join(', ')}`);
    }

    // Generate unique filename
    const fileExt = file.name.split('.').pop()?.toLowerCase();
    if (!fileExt) {
      throw new Error('File must have a valid extension');
    }

    const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
    const filePath = `${folder}/${fileName}`;

    console.log('📁 Uploading to path:', filePath);

    // Use service role client if available, otherwise fallback to regular client
    const clientToUse = supabaseServiceRole || supabase;
    const clientType = supabaseServiceRole ? 'service-role' : 'anon';
    
    console.log(`🔑 Using ${clientType} client for upload...`);

    // Upload file with timeout
    const uploadPromise = clientToUse.storage
      .from('images')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false
      });

    // Add timeout to prevent hanging
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Upload timeout after 30 seconds')), 30000);
    });

    const { data, error } = await Promise.race([uploadPromise, timeoutPromise]) as any;

    if (error) {
      console.error('❌ Storage upload error:', error);
      
      // Handle specific error cases
      if (error.message.includes('Bucket not found') || error.message.includes('bucket_id')) {
        throw new Error(`Storage bucket "images" not found or not accessible. 

OPLOSSING:
1. Ga naar je Supabase Dashboard
2. Ga naar Storage → Buckets
3. Maak een bucket aan genaamd "images" (als deze niet bestaat)
4. Zet de bucket op PUBLIC
5. Ga naar Storage → Policies
6. Voer deze SQL uit in de SQL Editor:

DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;

CREATE POLICY "Allow authenticated uploads"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow public downloads"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'images');

Error details: ${error.message}`);
      }
      
      if (error.message.includes('not allowed') || error.message.includes('unauthorized') || error.message.includes('row-level security policy')) {
        
        // If we're already using service role and still getting auth errors, the policies are wrong
        if (clientType === 'service-role') {
          throw new Error(`Service role upload failed - storage policies are incorrect. 

OPLOSSING - Voer deze SQL uit in je Supabase SQL Editor:

-- Schakel RLS uit voor storage.objects (tijdelijk voor testing)
ALTER TABLE storage.objects DISABLE ROW LEVEL SECURITY;

-- Of maak correcte policies:
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;

CREATE POLICY "Allow all uploads"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow all downloads"
ON storage.objects FOR SELECT
USING (bucket_id = 'images');

Error details: ${error.message}`);
        }
        
        throw new Error(`Upload not allowed due to storage policies. 

OPLOSSING - Voer deze SQL uit in je Supabase SQL Editor:

-- Verwijder oude policies
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated deletes" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated updates" ON storage.objects;

-- Maak nieuwe policies
CREATE POLICY "Allow authenticated uploads"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow public downloads"
ON storage.objects FOR SELECT TO public
USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated deletes"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated updates"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'images') WITH CHECK (bucket_id = 'images');

Error details: ${error.message}`);
      }

      if (error.message.includes('Duplicate')) {
        throw new Error('A file with this name already exists. Please try again.');
      }
      
      if (error.message.includes('payload too large')) {
        throw new Error('File too large for upload. Please reduce file size and try again.');
      }

      throw new Error(`Upload failed: ${error.message}`);
    }

    console.log('✅ Upload successful:', data);

    // Get public URL using the same client
    const { data: { publicUrl } } = clientToUse.storage
      .from('images')
      .getPublicUrl(filePath);

    console.log('🔗 Public URL generated:', publicUrl);

    if (!publicUrl) {
      throw new Error('Failed to generate public URL for uploaded image');
    }

    // Verify the URL is accessible
    try {
      const response = await fetch(publicUrl, { method: 'HEAD' });
      if (!response.ok) {
        console.warn('⚠️ Public URL may not be immediately accessible:', response.status);
      }
    } catch (error) {
      console.warn('⚠️ Could not verify public URL accessibility:', error);
    }

    return publicUrl;
  } catch (error) {
    console.error('❌ Error uploading image:', error);
    
    // Provide more specific error messages
    if (error instanceof Error) {
      if (error.message.includes('Failed to fetch')) {
        throw new Error('Network error: Unable to connect to Supabase. Please check your internet connection and verify your Supabase project is active.');
      }
      
      if (error.message.includes('NetworkError')) {
        throw new Error('Network error: Please check your internet connection and try again.');
      }

      if (error.message.includes('CORS')) {
        throw new Error('CORS error: Please check your Supabase project configuration and allowed origins.');
      }

      throw error;
    }
    
    throw new Error('Unknown error occurred during image upload');
  }
};

// Delete image from Supabase Storage
export const deleteImage = async (url: string): Promise<void> => {
  try {
    console.log('Deleting image:', url);
    
    // Extract file path from URL
    const urlParts = url.split('/');
    const fileName = urlParts[urlParts.length - 1];
    const folder = urlParts[urlParts.length - 2];
    const filePath = `${folder}/${fileName}`;

    console.log('Deleting file path:', filePath);

    // Use service role client if available for deletion
    const clientToUse = supabaseServiceRole || supabase;

    const { error } = await clientToUse.storage
      .from('images')
      .remove([filePath]);

    if (error) {
      console.error('Storage delete error:', error);
      throw error;
    }

    console.log('Image deleted successfully');
  } catch (error) {
    console.error('Error deleting image:', error);
    // Don't throw error for deletion failures to avoid blocking other operations
  }
};