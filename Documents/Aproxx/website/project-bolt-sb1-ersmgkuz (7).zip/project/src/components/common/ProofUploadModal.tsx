import React, { useState, useRef } from 'react';
import { X, Camera, Upload, Image as ImageIcon } from 'lucide-react';
import { uploadImage } from '../../lib/supabase';
import toast from 'react-hot-toast';

interface ProofUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (imageUrl: string) => void;
  title: string;
  description: string;
}

function ProofUploadModal({ isOpen, onClose, onSubmit, title, description }: ProofUploadModalProps) {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleImageSelect = (file: File) => {
    // Validate file type
    if (!file.type.match('image/jpeg') && !file.type.match('image/png')) {
      toast.error('Alleen JPG of PNG afbeeldingen zijn toegestaan');
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('Afbeelding mag maximaal 10MB zijn');
      return;
    }

    setSelectedImage(file);

    // Create preview
    const reader = new FileReader();
    reader.onload = (event) => {
      setImagePreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleImageSelect(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    if (!selectedImage) {
      toast.error('Selecteer eerst een afbeelding');
      return;
    }

    setIsSubmitting(true);

    try {
      // Upload image to Supabase Storage or local storage
      const imageUrl = await uploadImage(selectedImage, 'proof');
      
      // Call the onSubmit callback with the uploaded image URL or key
      onSubmit(imageUrl);
      
      // Reset form
      setSelectedImage(null);
      setImagePreview(null);
      
      toast.success('Afbeelding succesvol geüpload');
    } catch (error) {
      console.error('Error uploading image:', error);
      toast.error('Fout bij uploaden van afbeelding');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setSelectedImage(null);
    setImagePreview(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={handleClose} className="text-gray-500 hover: text-gray-700">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6">
          <p className="text-gray-600 mb-6">{description}</p>
          
          {/* Image Preview */}
          {imagePreview ? (
            <div className="mb-6">
              <div className="relative w-full h-48 rounded-lg overflow-hidden border border-gray-200">
                <img 
                  src={imagePreview} 
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => {
                    setSelectedImage(null);
                    setImagePreview(null);
                  }}
                  className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                >
                  <X size={16} />
                </button>
              </div>
            </div>
          ) : (
            <div className="mb-6">
              <div className="w-full h-48 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <ImageIcon size={48} className="mx-auto text-gray-400 mb-2" />
                  <p className="text-gray-500">Geen afbeelding geselecteerd</p>
                </div>
              </div>
            </div>
          )}
          
          {/* Upload Options */}
          <div className="space-y-3 mb-6">
            <button
              onClick={() => cameraInputRef.current?.click()}
              className="w-full btn btn-primary flex items-center justify-center"
              disabled={isSubmitting}
            >
              <Camera size={20} className="mr-2" />
              <span>Foto Maken</span>
            </button>
            
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full btn btn-secondary flex items-center justify-center"
              disabled={isSubmitting}
            >
              <Upload size={20} className="mr-2" />
              <span>Bestand Uploaden</span>
            </button>
          </div>
          
          {/* Hidden file inputs */}
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFileUpload}
            className="hidden"
          />
          
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png"
            onChange={handleFileUpload}
            className="hidden"
          />
          
          {/* Action Buttons */}
          <div className="flex justify-end space-x-3">
            <button 
              onClick={handleClose}
              className="btn btn-secondary"
              disabled={isSubmitting}
            >
              Annuleren
            </button>
            <button 
              onClick={handleSubmit}
              disabled={!selectedImage || isSubmitting}
              className={`btn btn-primary ${
                !selectedImage || isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? 'Uploaden...' : 'Bevestigen'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProofUploadModal;