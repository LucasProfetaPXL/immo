import React, { useState, useEffect } from 'react';
import { useSigns } from '../../context/SignsContext';
import ProofUploadModal from '../common/ProofUploadModal';
import ImageViewerModal from '../common/ImageViewerModal';
import { Search, X, Download, Camera, Users, Eye } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { getEmployeeWorkAssignment } from '../../utils/workDistribution';
import toast from 'react-hot-toast';
import { formatAddress } from '../../utils/addressFormatter.tsx';

function EmployeePlaceSignsTab() {
  const { signs, updateSignStatus, updateSign, getSignById, allSigns } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSigns, setSelectedSigns] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showProofModal, setShowProofModal] = useState(false);
  const [currentSignId, setCurrentSignId] = useState<string | null>(null);
  const [assignedSigns, setAssignedSigns] = useState<any[]>([]);
  const [workAssignment, setWorkAssignment] = useState<any>(null);
  const [imageViewerState, setImageViewerState] = useState<{
    isOpen: boolean;
    images: string[];
    currentIndex: number;
    title: string;
    description: string;
  }>({
    isOpen: false,
    images: [],
    currentIndex: 0,
    title: '',
    description: ''
  });
  
  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  const currentUser = getCurrentUser();
  
  // Load work assignment for current employee
  useEffect(() => {
    if (currentUser && currentUser.id) {
      console.log(`👤 Loading work assignment for employee: ${currentUser.username}`);
      const assignment = getEmployeeWorkAssignment(currentUser.id, allSigns);
      setWorkAssignment(assignment);
      
      if (assignment) {
        console.log(`📋 Employee ${currentUser.username} assigned ${assignment.placementSigns.length} placement signs`);
        setAssignedSigns(assignment.placementSigns);
      } else {
        console.log(`❌ No work assignment found for employee: ${currentUser.username}`);
        setAssignedSigns([]);
      }
    }
  }, [currentUser, allSigns]);
  
  // Apply search filter to assigned signs
  const filteredSigns = assignedSigns.filter(sign => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  // Download image function
  const handleDownloadImage = (imageUrl: string, address: string) => {
    downloadImage(imageUrl, `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}`);
  };

  // View placement images
  const handleViewPlacementImages = (sign: any) => {
    setImageViewerState({
      isOpen: true,
      images: sign.placementDetails.placementImages,
      currentIndex: 0,
      title: 'Plaatsingsafbeeldingen',
      description: `${sign.address} - ${sign.placementDetails.placementImages.length} afbeelding(en)`
    });
  };

  // Close image viewer
  const closeImageViewer = () => {
    setImageViewerState({
      isOpen: false,
      images: [],
      currentIndex: 0,
      title: '',
      description: ''
    });
  };

  const handleToggleSelect = (id: string) => {
    setSelectedSigns(prev => {
      if (prev.includes(id)) {
        return prev.filter(signId => signId !== id);
      }
      return [...prev, id];
    });
  };

  const handleMarkPlaced = () => {
    if (selectedSigns.length === 0) {
      toast.error('Selecteer ten minste één bord');
      return;
    }
    
    if (selectedSigns.length === 1) {
      // Single sign - show proof upload modal
      setCurrentSignId(selectedSigns[0]);
      setShowProofModal(true);
    } else {
      // Multiple signs - mark as placed without proof for now
      setIsSubmitting(true);
      
      setTimeout(() => {
        selectedSigns.forEach(id => {
          updateSignStatus(id, 'placed');
        });
        
        setSelectedSigns([]);
        setIsSubmitting(false);
        toast.success('Borden succesvol gemarkeerd als geplaatst!');
      }, 800);
    }
  };

  const handleProofSubmit = (proofImageUrl: string) => {
    if (currentSignId) {
      console.log(`🔄 Completing placement task for sign ${currentSignId}`);
      console.log(`📸 Proof image URL received: ${proofImageUrl}`);
      
      const currentSign = getSignById(currentSignId);
      if (currentSign) {
        console.log(`📋 Current sign found:`, currentSign.id);
        console.log(`📋 Current proof images:`, currentSign.proofImages);
        
        // Update with proof image
        updateSign(currentSignId, {
          proofImages: {
            ...(currentSign.proofImages || {}),
            placed: proofImageUrl
          }
        });
        
        console.log(`💾 Updated sign with proof image for placement`);
        
        // Update status to placed
        updateSignStatus(currentSignId, 'placed');
        console.log(`🔄 Updated sign status to 'placed'`);
      } else {
        console.error(`❌ Sign ${currentSignId} not found when trying to save proof`);
      }
      
      // Clear selection and close modal
      setSelectedSigns([]);
      setCurrentSignId(null);
      setShowProofModal(false);
      
      // Remove from assigned signs (for employee view)
      setAssignedSigns(prev => prev.filter(sign => sign.id !== currentSignId));
      
      toast.success('Bord gemarkeerd als geplaatst met bewijs!');
    }
  };

  // Remove the old handleProofSubmit function and replace with this corrected version
  const handleProofSubmitOld = (proofImageUrl: string) => {
    if (currentSignId) {
      // Update sign with proof image and status
      updateSign(currentSignId, {
        proofImages: {
          placed: proofImageUrl
        }
      });
      updateSignStatus(currentSignId, 'placed');
      
      setSelectedSigns([]);
      setCurrentSignId(null);
      setShowProofModal(false);
      
      // Remove the sign from assignedSigns to make it disappear from the list
      setAssignedSigns(prev => prev.filter(sign => sign.id !== currentSignId));
      
      toast.success('Bord gemarkeerd als geplaatst met bewijs!');
    }
  };

  return (
    <div>
      <h2 className="text-lg font-bold mb-4">Borden Plaatsen</h2>
      
      {/* Work Assignment Info */}
      {workAssignment && (
        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Users size={20} className="text-blue-600 mr-2" />
              <div>
                <h3 className="font-medium text-blue-800">Uw Werkgebied</h3>
                <p className="text-sm text-blue-600">
                  {workAssignment.placementSigns.length} borden om te plaatsen in uw toegewezen gebied
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-blue-600">Totaal werk toegewezen:</div>
              <div className="font-bold text-blue-800">{workAssignment.totalSigns} borden</div>
              <div className="text-xs text-blue-500">
                ({workAssignment.placementSigns.length} plaatsen + {workAssignment.removalSigns.length} ophalen)
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="bg-gray-50 rounded-lg border border-gray-200">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Zoek borden..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
            />
          </div>
          
          <div>
            <button
              onClick={handleMarkPlaced}
              disabled={selectedSigns.length === 0 || isSubmitting}
              className={`btn ${
                selectedSigns.length === 0
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'btn-success'
              } ${isSubmitting ? 'opacity-75 cursor-wait' : ''} flex items-center`}
            >
              <Camera size={16} className="mr-2" />
              {isSubmitting 
                ? 'Verwerken...' 
                : `Markeer als Geplaatst (${selectedSigns.length})`}
            </button>
          </div>
        </div>
        
        <div className="p-4">
          {filteredSigns.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              {assignedSigns.length === 0 ? (
                <div>
                  <p>Geen borden toegewezen</p>
                  <p className="text-sm">Er zijn momenteel geen borden aan u toegewezen om te plaatsen</p>
                </div>
              ) : (
                <p>Geen borden gevonden die voldoen aan uw zoekcriteria</p>
              )}
            </div>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredSigns.map(sign => (
                <div 
                  key={sign.id}
                  className={`p-3 rounded-md border transition-colors ${
                    selectedSigns.includes(sign.id)
                      ? 'border-primary-blue bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          className="mr-3 h-4 w-4 text-primary-blue rounded border-gray-300 focus:ring-primary-blue"
                          checked={selectedSigns.includes(sign.id)}
                          onChange={() => handleToggleSelect(sign.id)}
                        />
                        <div>
                          <p className="font-medium text-sm">{sign.companyName}</p>
                          <p className="text-xs text-gray-600">{sign.address}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center mt-2 ml-7">
                        <span className="status-badge status-confirmed text-xs">
                          Bevestigd
                        </span>
                        <span className="text-xs text-gray-500 ml-2">
                          {formatDateInDutch(new Date(sign.updatedAt))}
                        </span>
                      </div>

                      {/* Show placement details if available */}
                      {sign.placementDetails && (
                        <div className="ml-7 mt-2 p-2 bg-blue-50 rounded text-xs">
                          {sign.placementDetails.specificLocation && (
                            <div className="text-blue-700">
                              📍 {sign.placementDetails.specificLocation}
                            </div>
                          )}
                          <div className="text-blue-700">
                            🔄 {sign.placementDetails.orientation === 'above-ballast' ? 'Boven de ballast' : 'Links van de ballast'}
                          </div>
                          {sign.placementDetails.placementImages && sign.placementDetails.placementImages.length > 0 && (
                            <div className="text-blue-700 flex items-center">
                              <span>📷 {sign.placementDetails.placementImages.length} afbeelding(en)</span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleViewPlacementImages(sign);
                                }}
                                className="ml-2 text-blue-600 hover:text-blue-800"
                                title="Bekijk plaatsingsafbeeldingen"
                              >
                                <Eye size={10} />
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center">
                      {sign.imageUrl && (
                        <div className="flex items-center space-x-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDownloadImage(sign.imageUrl!, sign.address);
                            }}
                            className="text-gray-500 hover:text-gray-700"
                            title="Download afbeelding"
                          >
                            <Download size={12} />
                          </button>
                          <div className="w-12 h-12 rounded-md overflow-hidden border border-gray-200">
                            <div 
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundImage: `url(${sign.imageUrl})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                              }}
                            ></div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Proof Upload Modal */}
      {showProofModal && currentSignId && (
        <ProofUploadModal
          isOpen={showProofModal}
          onClose={() => {
            setShowProofModal(false);
            setCurrentSignId(null);
          }}
          onSubmit={handleProofSubmit}
          title="Bewijs van Plaatsing"
          description="Upload een foto als bewijs dat het bord is geplaatst"
        />
      )}

      {/* Image Viewer Modal */}
      <ImageViewerModal
        isOpen={imageViewerState.isOpen}
        onClose={closeImageViewer}
        images={imageViewerState.images}
        currentIndex={imageViewerState.currentIndex}
        onIndexChange={(index) => setImageViewerState(prev => ({ ...prev, currentIndex: index }))}
        title={imageViewerState.title}
        description={imageViewerState.description}
      />
    </div>
  );
}

export default EmployeePlaceSignsTab;