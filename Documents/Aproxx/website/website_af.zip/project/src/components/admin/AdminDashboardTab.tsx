import React, { useState } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { useSigns } from '../../context/SignsContext';
import SignMap from '../common/SignMap';
import { MapPin, Package, TrendingUp, Clock, Users, Building2, Eye, Download } from 'lucide-react';
import { getInventorySummary } from '../../utils/inventoryManager';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import ImageViewerModal from '../common/ImageViewerModal';

// Belgium bounds
const belgiumBounds = [[49.5, 2.5], [51.5, 6.4]] as L.LatLngBoundsExpression;
const defaultCenter = [50.8503, 4.3517] as [number, number]; // Brussels

function AdminDashboardTab() {
  const { signs, getAllSigns } = useSigns();
  const [selectedSign, setSelectedSign] = useState<any>(null);
  const [imageViewerState, setImageViewerState] = useState<{
    isOpen: boolean;
    images: string[];
    currentIndex: number;
    title: string;
    description: string;
  }>({
    isOpen: false,
    images: [],
    currentIndex: 0,
    title: '',
    description: ''
  });
  
  // Get all signs for admin view
  const allSigns = getAllSigns();
  
  // Calculate statistics
  const activeSigns = allSigns.filter(sign => sign.status === 'placed');
  const pendingSigns = allSigns.filter(sign => sign.status === 'pending');
  const confirmedSigns = allSigns.filter(sign => sign.status === 'confirmed');
  const removalRequestedSigns = allSigns.filter(sign => sign.status === 'removal-requested');
  const soldRequestedSigns = allSigns.filter(sign => sign.soldStatus === 'requested');
  const soldConfirmedSigns = allSigns.filter(sign => sign.soldStatus === 'confirmed');
  
  // Get recent requests (last 10)
  const recentRequests = [...allSigns]
    .filter(sign => sign.status === 'pending' || sign.soldStatus === 'requested')
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 10);
  
  // Inventory summary
  const inventorySummary = getInventorySummary(allSigns);

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  const handleSignClick = (sign: any) => {
    setSelectedSign(sign);
  };

  const handleViewProofImage = (imageUrl: string, type: 'placed' | 'removed' | 'sold', address: string) => {
    const titles = {
      placed: 'Bewijs van Plaatsing',
      removed: 'Bewijs van Ophaling',
      sold: 'Bewijs van Verkocht Bordje'
    };
    
    setImageViewerState({
      isOpen: true,
      images: [imageUrl],
      currentIndex: 0,
      title: titles[type],
      description: address
    });
  };

  const closeImageViewer = () => {
    setImageViewerState({
      isOpen: false,
      images: [],
      currentIndex: 0,
      title: '',
      description: ''
    });
  };

  const getStatusText = (status: string) => {
    switch(status) {
      case 'pending': return 'In afwachting';
      case 'confirmed': return 'Bevestigd';
      case 'placed': return 'Geplaatst';
      case 'removal-requested': return 'Verwijdering aangevraagd';
      case 'removal-confirmed': return 'Verwijderd';
      case 'removed': return 'Opgehaald';
      default: return status.replace('-', ' ');
    }
  };

  return (
    <div className="flex h-full">
      {/* Central Map */}
      <div className="flex-1 p-6">
        <h2 className="text-2xl font-bold mb-6">Admin Dashboard</h2>
        
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <MapPin size={24} className="text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Actieve Borden</p>
                <p className="text-2xl font-bold text-gray-900">{activeSigns.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <Clock size={24} className="text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Nieuwe Aanvragen</p>
                <p className="text-2xl font-bold text-gray-900">{pendingSigns.length + soldRequestedSigns.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <TrendingUp size={24} className="text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Verkocht Bordjes</p>
                <p className="text-2xl font-bold text-gray-900">{soldRequestedSigns.length + soldConfirmedSigns.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-orange-100">
                <Package size={24} className="text-orange-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Beschikbare Borden</p>
                <p className="text-2xl font-bold text-gray-900">{inventorySummary.totalAvailable}</p>
                <p className="text-xs text-gray-500">
                  {inventorySummary.totalInUse} van {inventorySummary.totalBoards} in gebruik<br/>
                  <span className="text-blue-500">{inventorySummary.totalExclusiveAllocations} exclusief</span> • 
                  <span className="text-green-500">{inventorySummary.sharedPoolSize} gedeeld</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Central Map */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold">Centrale Kaart</h3>
            <p className="text-sm text-gray-500">Alle borden in het systeem</p>
          </div>
          
          <div className="p-4">
            <div className="h-[500px] w-full rounded-lg overflow-hidden border border-gray-200">
              <MapContainer 
                center={defaultCenter} 
                zoom={8} 
                style={{ height: '100%', width: '100%', display: 'block' }}
                zoomControl={true}
                scrollWheelZoom={true}
                maxBounds={belgiumBounds}
              >
                <TileLayer
                  url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <SignMap signs={allSigns} showPreview={true} />
              </MapContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel */}
      <div className="w-80 bg-gray-50 border-l border-gray-200 p-4">
        {/* Recent Requests Tab */}
        <div className="bg-white rounded-lg border border-gray-200 mb-4">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold">Nieuwe Aanvragen</h3>
            <p className="text-sm text-gray-500">Chronologisch overzicht</p>
          </div>
          
          <div className="p-4">
            {recentRequests.length === 0 ? (
              <div className="text-center py-6 text-gray-500">
                <p className="text-sm">Geen nieuwe aanvragen</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {recentRequests.map(sign => (
                  <div 
                    key={sign.id}
                    className="p-3 border border-gray-200 rounded-md hover:border-primary-blue cursor-pointer transition-colors"
                    onClick={() => handleSignClick(sign)}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="text-sm font-medium">{sign.companyName}</p>
                        <p className="text-xs text-gray-500">{sign.address}</p>
                        <div className="mt-1">
                          {sign.soldStatus === 'requested' ? (
                            <span className="status-badge status-confirmed text-xs">
                              Verkocht bordje aangevraagd
                            </span>
                          ) : (
                            <span className={`status-badge status-${sign.status} text-xs`}>
                              {getStatusText(sign.status)}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-xs text-gray-400">
                        {formatDateInDutch(new Date(sign.updatedAt))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Selected Sign Details */}
        {selectedSign && (
          <div className="bg-white rounded-lg border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold">Bestelling Details</h3>
            </div>
            
            <div className="p-4">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900">{selectedSign.companyName}</h4>
                  <p className="text-sm text-gray-600">{selectedSign.address}</p>
                </div>
                
                <div>
                  <span className={`status-badge status-${selectedSign.status}`}>
                    {getStatusText(selectedSign.status)}
                  </span>
                  {selectedSign.soldStatus && selectedSign.soldStatus !== 'none' && (
                    <div className="mt-2">
                      <span className="status-badge status-confirmed text-xs">
                        {selectedSign.soldStatus === 'requested' ? 'Verkocht bordje aangevraagd' :
                         selectedSign.soldStatus === 'confirmed' ? 'Verkocht bordje bevestigd' :
                         selectedSign.soldStatus === 'placed' ? 'Verkocht bordje geplaatst' : ''}
                      </span>
                    </div>
                  )}
                </div>
                
                {selectedSign.imageUrl && (
                  <div>
                    <h5 className="text-sm font-medium text-gray-700 mb-2">Bordafbeelding</h5>
                    <div className="w-full h-32 rounded-md overflow-hidden border border-gray-200">
                      <div 
                        style={{
                          width: '100%',
                          height: '100%',
                          backgroundImage: `url(${selectedSign.imageUrl})`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center',
                        }}
                      ></div>
                    </div>
                  </div>
                )}
                
                {/* Proof Images */}
                {(selectedSign.proofImages?.placed || selectedSign.proofImages?.removed || selectedSign.proofImages?.sold) && (
                  <div>
                    <h5 className="text-sm font-medium text-gray-700 mb-2">Bewijsmateriaal</h5>
                    <div className="space-y-2">
                      {selectedSign.proofImages?.placed && (
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-md overflow-hidden border border-green-200">
                            <div 
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundImage: `url(${selectedSign.proofImages.placed})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                              }}
                              onClick={() => handleViewProofImage(selectedSign.proofImages.placed, 'placed', selectedSign.address)}
                              className="cursor-pointer"
                            ></div>
                          </div>
                          <span className="text-sm text-green-600">Bewijs van plaatsing</span>
                        </div>
                      )}
                      
                      {selectedSign.proofImages?.removed && (
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-md overflow-hidden border border-red-200">
                            <div 
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundImage: `url(${selectedSign.proofImages.removed})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                              }}
                              onClick={() => handleViewProofImage(selectedSign.proofImages.removed, 'removed', selectedSign.address)}
                              className="cursor-pointer"
                            ></div>
                          </div>
                          <span className="text-sm text-red-600">Bewijs van ophaling</span>
                        </div>
                      )}
                      
                      {selectedSign.proofImages?.sold && (
                        <div className="flex items-center space-x-2">
                          <div className="w-12 h-12 rounded-md overflow-hidden border border-purple-200">
                            <div 
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundImage: `url(${selectedSign.proofImages.sold})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                              }}
                              onClick={() => handleViewProofImage(selectedSign.proofImages.sold, 'sold', selectedSign.address)}
                              className="cursor-pointer"
                            ></div>
                          </div>
                          <span className="text-sm text-purple-600">Bewijs van verkocht bordje</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                <div className="text-xs text-gray-500">
                  <p>Aangemaakt: {formatDateInDutch(new Date(selectedSign.createdAt))}</p>
                  <p>Laatste update: {formatDateInDutch(new Date(selectedSign.updatedAt))}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Image Viewer Modal */}
      <ImageViewerModal
        isOpen={imageViewerState.isOpen}
        onClose={closeImageViewer}
        images={imageViewerState.images}
        currentIndex={imageViewerState.currentIndex}
        onIndexChange={(index) => setImageViewerState(prev => ({ ...prev, currentIndex: index }))}
        title={imageViewerState.title}
        description={imageViewerState.description}
      />
    </div>
  );
}

export default AdminDashboardTab;