import React, { useState } from 'react';
import { useSigns } from '../../context/SignsContext';
import { Search, Download, Eye } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { downloadImage } from '../../utils/imageUtils';
import { formatAddress } from '../../utils/addressFormatter.tsx';
import ImageViewerModal from '../common/ImageViewerModal';
import toast from 'react-hot-toast';

function StatusOverviewTab() {
  const { signs } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  const [imageViewerState, setImageViewerState] = useState<{
    isOpen: boolean;
    images: string[];
    currentIndex: number;
    title: string;
    description: string;
  }>({
    isOpen: false,
    images: [],
    currentIndex: 0,
    title: '',
    description: ''
  });

  // Dutch date formatting function
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  // Download image function
  const handleDownloadImage = (imageUrl: string, address: string) => {
    downloadImage(imageUrl, `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}`);
  };

  // Open image viewer for placement images
  const handleViewPlacementImages = (sign: any) => {
    if (!sign.placementDetails?.placementImages || sign.placementDetails.placementImages.length === 0) {
      return;
    }

    setImageViewerState({
      isOpen: true,
      images: sign.placementDetails.placementImages,
      currentIndex: 0,
      title: 'Plaatsingsafbeeldingen',
      description: `${sign.address} - ${sign.placementDetails.placementImages.length} afbeelding(en)`
    });
  };

  // Open image viewer for proof images
  const handleViewProofImage = (imageUrl: string, type: 'placed' | 'removed', address: string) => {
    setImageViewerState({
      isOpen: true,
      images: [imageUrl],
      currentIndex: 0,
      title: type === 'placed' ? 'Bewijs van Plaatsing' : 'Bewijs van Ophaling',
      description: address
    });
  };

  // Close image viewer
  const closeImageViewer = () => {
    setImageViewerState({
      isOpen: false,
      images: [],
      currentIndex: 0,
      title: '',
      description: ''
    });
  };

  // Apply search filter
  const filteredSigns = signs.filter(sign => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      sign.address.toLowerCase().includes(query) ||
      sign.companyName.toLowerCase().includes(query)
    );
  });

  // Sort by updated date (newest first)
  const sortedSigns = [...filteredSigns].sort((a, b) => 
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );

  const getStatusText = (status: string) => {
    switch(status) {
      case 'pending': return 'In afwachting';
      case 'confirmed': return 'Bevestigd';
      case 'placed': return 'Geplaatst';
      case 'removal-requested': return 'Verwijdering aangevraagd';
      case 'removal-confirmed': return 'Verwijderd';
      case 'removed': return 'Opgehaald';
      default: return status.replace('-', ' ');
    }
  };

  const getSoldStatusText = (soldStatus?: string) => {
    switch(soldStatus) {
      case 'requested': return 'Verkocht bordje aangevraagd';
      case 'confirmed': return 'Verkocht bordje bevestigd';
      case 'placed': return 'Verkocht bordje geplaatst';
      default: return '';
    }
  };
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Status Overzicht</h2>
      
      <div className="flex justify-between items-center mb-4">
        <div className="text-sm text-gray-500">
          {sortedSigns.length} borden totaal
        </div>
        
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Zoek borden..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-64"
          />
        </div>
      </div>
      
      {sortedSigns.length === 0 ? (
        <div className="text-center py-10 text-gray-500">
          <p>Geen borden gevonden</p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-gray-200">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Adres
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Laatste Update
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bordafbeelding
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Plaatsingsdetails
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bewijs Plaatsing
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Verkocht Bordje
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sortedSigns.map(sign => (
                  <tr key={sign.id}>
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900 text-sm leading-tight"> 
                        {formatAddress(sign.address)}
                      </div>
                      {/* Show placement details if available */}
                      {sign.placementDetails && (
                        <div className="text-xs text-blue-600 mt-1">
                          {sign.placementDetails.specificLocation && (
                            <div>📍 {sign.placementDetails.specificLocation}</div>
                          )}
                          <div>
                            🔄 {sign.placementDetails.orientation === 'above-ballast' ? 'Boven de ballast' : 'Links van de ballast'}
                          </div>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <span className={`status-badge status-${sign.status}`}>
                          {getStatusText(sign.status)}
                        </span>
                        {sign.soldStatus && sign.soldStatus !== 'none' && (
                          <div className="mt-1">
                            <span className="status-badge status-confirmed text-xs">
                              {getSoldStatusText(sign.soldStatus)}
                            </span>
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDateInDutch(new Date(sign.updatedAt))}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {sign.imageUrl ? (
                        <div className="flex items-center space-x-2">
                          <div className="w-10 h-10 rounded-md overflow-hidden border border-green-200 cursor-pointer hover:opacity-80 transition-opacity">
                            <div 
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundImage: `url(${sign.imageUrl})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                              }}
                              onClick={() => handleDownloadImage(sign.imageUrl!, sign.address)}
                            ></div>
                          </div>
                          <button
                            onClick={() => handleDownloadImage(sign.imageUrl!, sign.address)}
                            className="text-gray-500 hover:text-gray-700"
                            title="Download bordafbeelding"
                          >
                            <Download size={14} />
                          </button>
                        </div>
                      ) : (
                        <span className="text-gray-400 text-sm">Geen afbeelding</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {sign.placementDetails?.placementImages && sign.placementDetails.placementImages.length > 0 ? (
                        <div className="flex items-center space-x-2">
                          <div className="flex -space-x-1">
                            {sign.placementDetails.placementImages.slice(0, 3).map((image, index) => (
                              <div 
                                key={index}
                                className="w-8 h-8 rounded-md overflow-hidden border-2 border-white shadow-sm"
                              >
                                <div 
                                  style={{
                                    width: '100%',
                                    height: '100%',
                                    backgroundImage: `url(${image})`,
                                    backgroundSize: 'cover',
                                    backgroundPosition: 'center',
                                  }}
                                ></div>
                              </div>
                            ))}
                            {sign.placementDetails.placementImages.length > 3 && (
                              <div className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white shadow-sm flex items-center justify-center">
                                <span className="text-xs text-gray-600">+{sign.placementDetails.placementImages.length - 3}</span>
                              </div>
                            )}
                          </div>
                          <button
                            onClick={() => handleViewPlacementImages(sign)}
                            className="text-blue-600 hover:text-blue-800 text-xs"
                            title="Bekijk alle plaatsingsafbeeldingen"
                          >
                            <Eye size={14} />
                          </button>
                          <span className="text-xs text-gray-500">
                            ({sign.placementDetails.placementImages.length})
                          </span>
                        </div>
                      ) : (
                        <span className="text-gray-400 text-sm">Geen afbeeldingen</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        {/* Placement proof */}
                        {sign.proofImages?.placed && (
                          <div className="flex items-center space-x-1">
                            <div className="w-8 h-8 rounded-md overflow-hidden border border-green-200 cursor-pointer hover:opacity-80 transition-opacity">
                              <div 
                                style={{
                                  width: '100%',
                                  height: '100%',
                                  backgroundImage: `url(${sign.proofImages.placed})`,
                                  backgroundSize: 'cover',
                                  backgroundPosition: 'center',
                                }}
                                onClick={() => handleViewProofImage(sign.proofImages!.placed!, 'placed', sign.address)}
                              ></div>
                            </div>
                            <button
                              onClick={() => handleViewProofImage(sign.proofImages!.placed!, 'placed', sign.address)}
                              className="text-green-600 hover:text-green-800"
                              title="Bekijk bewijs van plaatsing"
                            >
                              <Eye size={12} />
                            </button>
                            <button
                              onClick={() => handleDownloadImage(sign.proofImages!.placed!, `bewijs_plaatsing_${sign.address}`)}
                              className="text-gray-500 hover:text-gray-700"
                              title="Download bewijs van plaatsing"
                            >
                              <Download size={12} />
                            </button>
                          </div>
                        )}
                        
                        {!sign.proofImages?.placed && (
                          <span className="text-gray-400 text-sm">Geen bewijs</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {sign.proofImages?.sold ? (
                        <div className="flex items-center space-x-2">
                          <div className="w-8 h-8 rounded-md overflow-hidden border border-purple-200 cursor-pointer hover:opacity-80 transition-opacity">
                            <div 
                              style={{
                                width: '100%',
                                height: '100%',
                                backgroundImage: `url(${sign.proofImages.sold})`,
                                backgroundSize: 'cover',
                                backgroundPosition: 'center',
                              }}
                              onClick={() => handleViewProofImage(sign.proofImages!.sold!, 'sold', sign.address)}
                            ></div>
                          </div>
                          <button
                            onClick={() => handleViewProofImage(sign.proofImages!.sold!, 'sold', sign.address)}
                            className="text-purple-600 hover:text-purple-800"
                            title="Bekijk bewijs van verkocht bordje"
                          >
                            <Eye size={12} />
                          </button>
                          <button
                            onClick={() => handleDownloadImage(sign.proofImages!.sold!, `bewijs_verkocht_${sign.address}`)}
                            className="text-gray-500 hover:text-gray-700"
                            title="Download bewijs van verkocht bordje"
                          >
                            <Download size={12} />
                          </button>
                        </div>
                      ) : sign.soldStatus === 'requested' ? (
                        <span className="text-purple-600 text-sm">In behandeling</span>
                      ) : sign.soldStatus === 'confirmed' ? (
                        <span className="text-purple-600 text-sm">Bevestigd</span>
                      ) : (
                        <span className="text-gray-400 text-sm">Geen verkocht bordje</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Image Viewer Modal */}
      <ImageViewerModal
        isOpen={imageViewerState.isOpen}
        onClose={closeImageViewer}
        images={imageViewerState.images}
        currentIndex={imageViewerState.currentIndex}
        onIndexChange={(index) => setImageViewerState(prev => ({ ...prev, currentIndex: index }))}
        title={imageViewerState.title}
        description={imageViewerState.description}
      />
    </div>
  );
}

// Add handleViewProofImage function for sold images
const handleViewProofImage = (imageUrl: string, type: 'placed' | 'removed' | 'sold', address: string, setImageViewerState: any) => {
  const titles = {
    placed: 'Bewijs van Plaatsing',
    removed: 'Bewijs van Ophaling', 
    sold: 'Bewijs van Verkocht Bordje'
  };
  
  setImageViewerState({
    isOpen: true,
    images: [imageUrl],
    currentIndex: 0,
    title: titles[type],
    description: address
  });
};
export default StatusOverviewTab;