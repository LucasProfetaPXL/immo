// Image utility functions
import toast from 'react-hot-toast';

/**
 * Download an image from a URL
 * 
 * @param imageUrl The URL of the image to download
 * @param filenameBase The base filename to use (without extension)
 */
export const downloadImage = (imageUrl: string, filenameBase: string): void => {
  try {
    // Create a temporary link element
    // Create a new image to load the URL
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      // Create a canvas to convert the image
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      
      // Draw the image on the canvas
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        
        // Convert to data URL and trigger download
        try {
          const dataUrl = canvas.toDataURL('image/png');
          const safeFilename = filenameBase.replace(/[^a-zA-Z0-9]/g, '_');
          
          const link = document.createElement('a');
          link.href = dataUrl;
          link.download = `${safeFilename}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          toast.success('Afbeelding download gestart');
        } catch (err) {
          console.error('Canvas export error:', err);
          fallbackDownload(imageUrl, filenameBase);
        }
      } else {
        fallbackDownload(imageUrl, filenameBase);
      }
    };
    
    img.onerror = () => {
      console.error('Image loading error');
      fallbackDownload(imageUrl, filenameBase);
    };
    
    img.src = imageUrl;
  } catch (error) {
    console.error('Download error:', error);
    fallbackDownload(imageUrl, filenameBase);
  }
};

/**
 * Fallback download method that tries direct download or opens in new tab
 */
const fallbackDownload = (imageUrl: string, filenameBase: string): void => {
  try {
    // Try direct download first
    const link = document.createElement('a');
    link.href = imageUrl;
    
    // Get file extension from URL or default to png
    const extension = imageUrl.split('.').pop()?.toLowerCase() || 'png';
    const safeFilename = filenameBase.replace(/[^a-zA-Z0-9]/g, '_');
    
    link.download = `${safeFilename}.${extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Afbeelding download gestart (fallback methode)');
  } catch (err) {
    // Last resort: open in new tab
    window.open(imageUrl, '_blank');
    toast.success('Afbeelding geopend in nieuw tabblad');
  }
};

/**
 * Format an address for use in filenames
 * 
 * @param address The address to format
 * @returns A safe filename string
 */
export const formatAddressForFilename = (address: string): string => {
  return address.replace(/[^a-zA-Z0-9]/g, '_');
};