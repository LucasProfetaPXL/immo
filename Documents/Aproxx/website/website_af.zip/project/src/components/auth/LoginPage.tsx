import React, { useState } from 'react';
import { MapPin, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

interface LoginPageProps {
  onLogin: (username: string, password: string) => boolean;
}

function LoginPage({ onLogin }: LoginPageProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    setTimeout(() => {
      const success = onLogin(username, password);
      
      if (success) {
        toast.success('Inloggen gelukt!');
      } else {
        toast.error('Ongeldige gebruikersnaam of wachtwoord');
      }
      
      setIsLoading(false);
    }, 800);
  };

  const handleBackToWebsite = () => {
    window.location.href = '/';
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center relative">
      {/* Back arrow */}
      <button
        onClick={handleBackToWebsite}
        className="absolute top-6 left-6 flex items-center text-gray-600 hover:text-primary-blue transition-colors duration-200 group"
        title="Terug naar website"
      >
        <ArrowLeft size={20} className="mr-2 group-hover:-translate-x-1 transition-transform duration-200" />
        <span className="text-sm font-medium">Terug naar website</span>
      </button>

      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <div className="text-center mb-6">
          <div className="flex items-center justify-center mb-2">
            <MapPin size={40} className="text-primary-blue" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800">Bordbeheer Systeem</h1>
          <p className="text-gray-600">Log in op uw account</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="username" className="form-label">Gebruikersnaam</label>
            <input
              id="username"
              type="text"
              className="form-input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Voer uw gebruikersnaam in"
              required
            />
          </div>
          
          <div>
            <label htmlFor="password" className="form-label">Wachtwoord</label>
            <input
              id="password"
              type="password"
              className="form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Voer uw wachtwoord in"
              required
            />
          </div>
          
          <button
            type="submit"
            className={`btn btn-primary w-full ${isLoading ? 'opacity-75 cursor-wait' : ''}`}
            disabled={isLoading}
          >
            {isLoading ? 'Inloggen...' : 'Inloggen'}
          </button>
        </form>
        
        <div className="mt-6 text-center text-sm text-gray-500">
          <p>Neem contact op via info@aproxx.com voor toegang</p>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;