import React, { useEffect } from 'react';
import { Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { SignData } from '../../types';
import { formatDistanceToNow } from 'date-fns';
import { nl } from 'date-fns/locale';
import { Download } from 'lucide-react';
import toast from 'react-hot-toast';

interface SignMapProps {
  signs: SignData[];
  showPreview: boolean;
}

function SignMap({ signs, showPreview }: SignMapProps) {
  const map = useMap();
  
  // Create custom markers based on sign status
  const createCustomMarker = (status: string) => {
    let color = '#10b981'; // Default green for active
    
    if (status === 'removal-requested' || status === 'removal-confirmed') {
      color = '#f59e0b'; // Orange for removal
    } else if (status === 'removed' || status === 'trashed') {
      color = '#ef4444'; // Red for removed
    } else if (status === 'pending' || status === 'confirmed') {
      color = '#3b82f6'; // Blue for pending/confirmed
    }
    
    return L.divIcon({
      className: 'custom-marker',
      html: `<div class="marker-icon" style="background-color: ${color};">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
                  <circle cx="12" cy="10" r="3"></circle>
                </svg>
             </div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 32],
      popupAnchor: [0, -32]
    });
  };

  // Fit map to bounds of all markers
  useEffect(() => {
    if (signs.length > 0) {
      const bounds = L.latLngBounds(signs.map(sign => [sign.lat, sign.lng]));
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [signs, map]);

  const handleDownloadImage = (imageUrl: string, address: string) => {
    try {
      // Create a temporary link element
      const link = document.createElement('a');
      link.href = imageUrl;
      link.download = `bord_${address.replace(/[^a-zA-Z0-9]/g, '_')}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success('Afbeelding download gestart');
    } catch (error) {
      console.error('Download error:', error);
      // Fallback: open in new tab
      window.open(imageUrl, '_blank');
      toast.success('Afbeelding geopend in nieuw tabblad');
    }
  };

  const getStatusText = (status: string) => {
    switch(status) {
      case 'pending': return 'In afwachting';
      case 'confirmed': return 'Bevestigd';
      case 'placed': return 'Geplaatst';
      case 'removal-requested': return 'Verwijdering aangevraagd';
      case 'removal-confirmed': return 'Verwijderd';
      case 'removed': return 'Verwijderd';
      default: return status.replace('-', ' ');
    }
  };

  // Dutch translations for date-fns
  const formatDateInDutch = (date: Date) => {
    return formatDistanceToNow(date, { 
      addSuffix: true, 
      locale: nl 
    });
  };

  return (
    <>
      {signs.map(sign => (
        <Marker 
          key={sign.id} 
          position={[sign.lat, sign.lng]} 
          icon={createCustomMarker(sign.status)}
        >
          <Popup>
            <div className="p-1">
              <h3 className="font-medium text-gray-900">{sign.companyName}</h3>
              <p className="text-sm text-gray-600">{sign.address}</p>
              
              <div className="flex items-center mt-2">
                <span className={`status-badge status-${sign.status}`}>
                  {getStatusText(sign.status)}
                </span>
              </div>
              
              {sign.createdAt && (
                <p className="text-xs text-gray-500 mt-2">
                  Aangemaakt {formatDateInDutch(new Date(sign.createdAt))}
                </p>
              )}
              
              {showPreview && sign.imageUrl && (
                <div className="mt-3 flex items-center space-x-2">
                  {/* Small image preview */}
                  <div className="w-12 h-12 rounded-md overflow-hidden border border-gray-200">
                    <div 
                      style={{
                        width: '100%',
                        height: '100%',
                        backgroundImage: `url(${sign.imageUrl})`,
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                      }}
                    ></div>
                  </div>
                  
                  {/* Download button */}
                  <button
                    onClick={() => handleDownloadImage(sign.imageUrl!, sign.address)}
                    className="btn btn-sm btn-secondary flex items-center"
                    title="Download afbeelding"
                  >
                    <Download size={14} className="mr-1" />
                    <span className="text-xs">Download</span>
                  </button>
                </div>
              )}
            </div>
          </Popup>
        </Marker>
      ))}
    </>
  );
}

export default SignMap;