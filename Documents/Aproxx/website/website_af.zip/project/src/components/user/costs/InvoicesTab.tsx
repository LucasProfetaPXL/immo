import React, { useState, useEffect } from 'react';
import { useInvoices } from '../../../context/InvoiceContext';
import { useSigns } from '../../../context/SignsContext';
import { formatAddress } from '../../../utils/addressFormatter.tsx';
import { formatDistanceToNow, differenceInDays } from 'date-fns';
import { calculateTotalAmountDue, calculateForfaitaryCompensation, calculateInterest } from '../../../lib/belgianFollowUp';
import toast from 'react-hot-toast';
import { downloadImage } from '../../../utils/imageUtils';
import ConfirmModal from '../../common/ConfirmModal';
import { generateInvoicePDF, generateCombinedInvoicePDF } from '../../../lib/pdf';

function InvoicesTab() {
  const { invoices, markInvoiceAsPaid } = useInvoices();
  const { getSignById } = useSigns();
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightNewInvoices, setHighlightNewInvoices] = useState(false);
  const [showOverdueDetails, setShowOverdueDetails] = useState<Record<string, boolean>>({});
  
  // Modal states
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    type: 'markPaid';
    invoiceId?: string;
    title: string;
    message: string;
    confirmText: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    type: 'markPaid',
    title: '',
    message: '',
    confirmText: '',
    onConfirm: () => {}
  });
  
  // Highlight new invoices briefly when component mounts or invoices change
  useEffect(() => {
    if (invoices.length > 0) {
      setHighlightNewInvoices(true);
      const timer = setTimeout(() => {
        setHighlightNewInvoices(false);
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [invoices.length]);
  
  // Sort invoices: unpaid first, then paid
  const sortedInvoices = [...invoices].sort((a, b) => {
    // First by payment status
    if (a.status === 'unpaid' && b.status === 'paid') return -1;
    if (a.status === 'paid' && b.status === 'unpaid') return 1;
    
    // Then by date (newest first)
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
  
  // Apply search filter
  const filteredInvoices = sortedInvoices.filter(invoice => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      invoice.companyName.toLowerCase().includes(query) ||
      invoice.address.toLowerCase().includes(query) ||
      invoice.billingDetails.name.toLowerCase().includes(query) ||
      (invoice.invoiceNumber && invoice.invoiceNumber.toLowerCase().includes(query))
    );
  });
  

  const handlePayInvoice = (invoiceId: string) => {
    setConfirmModal({
      isOpen: true,
      type: 'markPaid',
      invoiceId,
      title: 'Betaling Bevestigen',
      message: 'Weet u zeker dat deze betaling is voltooid?\n\nDe factuur wordt gemarkeerd als betaald.',
      confirmText: 'Markeer als Betaald',
      onConfirm: () => {
        markInvoiceAsPaid(invoiceId);
        toast.success('Factuur gemarkeerd als betaald');
      }
    });
  };




  const handleDownloadInvoice = async (invoice: any) => {
    try {
      // Re-generate the PDF for download
      if (invoice.signId === 'combined' && invoice.signDetails) {
        // This is a combined invoice - we need the original signs data
        // For now, we'll just download with available data
        const pdfDoc = await generateInvoicePDF(invoice);
        pdfDoc.save(`Factuur_${invoice.invoiceNumber || invoice.id.substring(0, 8)}.pdf`);
      } else {
        const pdfDoc = await generateInvoicePDF(invoice);
        pdfDoc.save(`Factuur_${invoice.invoiceNumber || invoice.id.substring(0, 8)}.pdf`);
      }
      
      toast.success('Factuur download gestart');
    } catch (error) {
      console.error('Error downloading invoice:', error);
      toast.error('Fout bij downloaden van factuur');
    }
  };

  const toggleOverdueDetails = (invoiceId: string) => {
    setShowOverdueDetails(prev => ({
      ...prev,
      [invoiceId]: !prev[invoiceId]
    }));
  };

  const renderOverdueDetails = (invoice: any) => {
    const now = new Date();
    const dueDate = new Date(invoice.dueDate);
    const daysOverdue = differenceInDays(now, dueDate);
    
    // Calculate Belgian follow-up details
    const totalAmountDue = calculateTotalAmountDue(invoice);
    const compensation = calculateForfaitaryCompensation(invoice.amount);
    
    let interestAmount = 0;
    if (invoice.firstReminderSent) {
      const reminderDate = new Date(invoice.firstReminderSent);
      const waitingPeriodEnd = new Date(reminderDate.getTime() + 14 * 24 * 60 * 60 * 1000);
      const daysLate = differenceInDays(now, waitingPeriodEnd);
      
      if (daysLate > 0) {
        const interest = calculateInterest(invoice.amount, daysLate);
        interestAmount = interest.interestAmount;
      }
    }

    return (
      <div className="mt-3 p-4 bg-orange-50 border border-orange-200 rounded-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <AlertTriangle size={18} className="text-orange-500 mr-2" />
            <span className="font-medium text-orange-700">
              Belgische Opvolgingsprocedure
            </span>
          </div>
          <button
            onClick={() => toggleOverdueDetails(invoice.id)}
            className="text-orange-600 hover:text-orange-800 text-sm"
          >
            {showOverdueDetails[invoice.id] ? 'Verberg details' : 'Toon details'}
          </button>
        </div>
        
        <div className="text-sm text-orange-700 mb-3">
          <strong>{daysOverdue} dagen te laat</strong> - Automatische opvolging actief
        </div>

        {showOverdueDetails[invoice.id] && (
          <div className="space-y-3">
            <div className="bg-white p-3 rounded border border-orange-200">
              <h5 className="font-medium text-orange-800 mb-2">Kostenoverzicht</h5>
              <div className="text-sm space-y-1">
                <div className="flex justify-between">
                  <span>Oorspronkelijk bedrag:</span>
                  <span>€{invoice.amount.toFixed(2)}</span>
                </div>
                {compensation.compensationAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Forfaitaire schadevergoeding:</span>
                    <span>€{compensation.compensationAmount.toFixed(2)}</span>
                  </div>
                )}
                {interestAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Verwijlintresten (12,5%/jaar):</span>
                    <span>€{interestAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-medium border-t border-orange-200 pt-1">
                  <span>Totaal verschuldigd:</span>
                  <span>€{totalAmountDue.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-3 rounded border border-orange-200">
              <h5 className="font-medium text-orange-800 mb-2">Procedure Status</h5>
              <div className="text-sm space-y-2">
                {!invoice.firstReminderSent && (
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-orange-400 rounded-full mr-2"></div>
                    <span>Eerste gratis herinnering wordt automatisch verstuurd na 30 dagen</span>
                  </div>
                )}
                {invoice.firstReminderSent && (
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-400 rounded-full mr-2"></div>
                    <span>Eerste herinnering verstuurd op {new Date(invoice.firstReminderSent).toLocaleDateString()}</span>
                  </div>
                )}
                {invoice.waitingPeriodEnd && new Date() < new Date(invoice.waitingPeriodEnd) && (
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-2"></div>
                    <span>Wettelijke wachttijd van 14 dagen loopt tot {new Date(invoice.waitingPeriodEnd).toLocaleDateString()}</span>
                  </div>
                )}
                {invoice.waitingPeriodEnd && new Date() > new Date(invoice.waitingPeriodEnd) && (
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-red-400 rounded-full mr-2"></div>
                    <span>Wachttijd verstreken - bijkomende kosten van toepassing</span>
                  </div>
                )}
              </div>
            </div>

            <div className="text-xs text-orange-600 bg-orange-100 p-2 rounded">
              <strong>Belgische wetgeving (vanaf 1 dec 2023):</strong> Na 30 dagen wordt automatisch een gratis herinnering verstuurd. 
              Na een wachttijd van 14 dagen kunnen verwijlintresten (12,5%/jaar) en forfaitaire schadevergoeding worden aangerekend.
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 space-y-2 sm:space-y-0">
        <h3 className="text-lg font-semibold">
          Factuurbeheer
          {highlightNewInvoices && invoices.length > 0 && (
            <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 text-sm rounded-md animate-pulse">
              Nieuwe factuur toegevoegd!
            </span>
          )}
        </h3>
        
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Zoek facturen..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 py-2 pr-3 border border-gray-300 rounded-md text-sm w-48"
            />
          </div>
        </div>
      </div>
      
      {/* Active Invoices */}
      <div className="overflow-hidden rounded-lg border border-gray-200 mb-6">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Factuurnummer
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Factuurgegevens
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Facturering
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Bedrag & Status
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Acties
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-10 text-center text-gray-500">
                    {invoices.length === 0 ? 'Nog geen facturen gegenereerd' : 'Geen facturen gevonden'}
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((invoice, index) => {
                  const sign = getSignById(invoice.signId);
                  const createdDate = new Date(invoice.createdAt);
                  const isOverdue = invoice.status === 'unpaid' && new Date() > new Date(invoice.dueDate);
                  const isNewInvoice = highlightNewInvoices && index < 3; // Highlight first 3 invoices
                  const totalAmountDue = calculateTotalAmountDue(invoice);
                  
                  return (
                    <tr 
                      key={invoice.id} 
                      className={`
                        ${invoice.status === 'paid' ? 'bg-gray-50' : ''} 
                        ${isNewInvoice ? 'bg-green-50 border-green-200' : ''}
                      `}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">
                          {invoice.invoiceNumber || invoice.id.substring(0, 8)}
                        </div>
                        <div className="text-xs text-gray-400">
                          Aangemaakt {formatDistanceToNow(createdDate, { addSuffix: true })}
                          {isNewInvoice && (
                            <span className="ml-2 px-1.5 py-0.5 bg-green-100 text-green-800 text-xs rounded">
                              Nieuw
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{invoice.companyName}</div>
                        <div className="text-sm text-gray-500">{formatAddress(invoice.address)}</div>
                        {/* Show comment/reference if available */}
                        {invoice.billingDetails.reference && invoice.billingDetails.reference.trim() && (
                          <div className="text-xs text-blue-600 mt-1 italic">
                            Opmerking: {invoice.billingDetails.reference}
                          </div>
                        )}
                        {isOverdue && renderOverdueDetails(invoice)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">{invoice.billingDetails.name}</div>
                        <div className="text-xs text-gray-500">{invoice.billingDetails.email}</div>
                        <div className="text-xs text-gray-500">
                          {invoice.billingDetails.vatNumber}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">
                          €{totalAmountDue.toFixed(2)}
                          {totalAmountDue !== invoice.amount && (
                            <div className="text-xs text-gray-500">
                              (oorspronkelijk €{invoice.amount.toFixed(2)})
                            </div>
                          )}
                        </div>
                        <div className="flex items-center mt-1">
                          <span className={`status-badge ${invoice.status === 'paid' ? 'status-paid' : isOverdue ? 'status-removal-requested' : 'status-invoiced'}`}>
                            {invoice.status === 'paid' ? 'Betaald' : 'Onbetaald'}
                            {isOverdue && ' (te laat)'}
                          </span>
                          
                          {invoice.reminderStatus !== 'none' && (
                            <span className="status-badge status-removal-confirmed ml-2 text-xs">
                              {invoice.reminderStatus === 'first' ? 'Eerste' : 
                               invoice.reminderStatus === 'second' ? 'Tweede' : 'Laatste'} herinnering
                            </span>
                          )}
                        </div>
                        {invoice.status === 'paid' && invoice.paidAt && (
                          <div className="text-xs text-gray-500 mt-1">
                            Betaald {formatDistanceToNow(new Date(invoice.paidAt), { addSuffix: true })}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => handleDownloadInvoice(invoice)}
                            className="btn btn-sm btn-secondary flex items-center"
                          >
                            <Download size={14} className="mr-1" />
                            <span>PDF</span>
                          </button>
                          
                          {invoice.status === 'unpaid' && (
                            <button
                              onClick={() => handlePayInvoice(invoice.id)}
                              className="btn btn-sm btn-success flex items-center"
                            >
                              <CreditCard size={14} className="mr-1" />
                              <span>Markeer als Betaald</span>
                            </button>
                          )}
                          
                          <button
                            onClick={() => handleDeleteInvoice(invoice.id)}
                            className={`btn btn-sm flex items-center ${
                              invoice.status === 'paid' ? 'btn-danger' : 'btn-secondary opacity-50 cursor-not-allowed'
                            }`}
                            disabled={invoice.status !== 'paid'}
                            title={invoice.status !== 'paid' ? 'Alleen betaalde facturen kunnen worden verwijderd' : 'Verwijder factuur'}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        confirmText={confirmModal.confirmText}
        type="success"
        icon={confirmModal.type === 'markPaid' ? 'payment' : 'trash'}
      />
    </div>
  );
}

export default InvoicesTab;