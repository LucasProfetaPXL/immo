# Verificatie Checklist voor Nieuwe Supabase Account

Gebruik deze checklist om te controleren of alles correct is overgezet.

## ✅ Database Schema Verificatie

### Tabellen Controle
- [ ] `users` tabel bestaat met alle kolommen
- [ ] `signs` tabel bestaat met alle kolommen  
- [ ] `billing_details` tabel bestaat met alle kolommen
- [ ] `invoices` tabel bestaat met alle kolommen
- [ ] `images` tabel bestaat met alle kolommen

### RLS (Row Level Security) Controle
- [ ] RLS is ingeschakeld op alle tabellen
- [ ] Users policies bestaan (SELECT, INSERT, UPDATE)
- [ ] Signs policies bestaan (SELECT, INSERT, UPDATE, DELETE)
- [ ] Billing details policies bestaan (SELECT, INSERT, UPDATE, DELETE)
- [ ] Invoices policies bestaan (SELECT, INSERT, UPDATE, DELETE)
- [ ] Images policies bestaan (SELECT, INSERT, UPDATE, DELETE)

### Indexes Controle
- [ ] Performance indexes zijn aangemaakt
- [ ] Email en username indexes bestaan
- [ ] Foreign key indexes bestaan

## ✅ Storage Configuratie Verificatie

### Bucket Controle
- [ ] "images" bucket bestaat
- [ ] Bucket is ingesteld als PUBLIC
- [ ] File size limit is 10MB
- [ ] Allowed MIME types zijn ingesteld

### Storage Policies Controle
- [ ] "Allow authenticated uploads" policy bestaat
- [ ] "Allow public downloads" policy bestaat  
- [ ] "Allow authenticated deletes" policy bestaat
- [ ] "Allow authenticated updates" policy bestaat

## ✅ Environment Variables Verificatie

### Credentials Controle
- [ ] VITE_SUPABASE_URL is bijgewerkt met nieuwe project URL
- [ ] VITE_SUPABASE_ANON_KEY is bijgewerkt met nieuwe anon key
- [ ] VITE_SUPABASE_SERVICE_ROLE_KEY is bijgewerkt met nieuwe service role key
- [ ] .env bestand is opgeslagen en geladen

## ✅ Applicatie Functionaliteit Verificatie

### Authentication Controle
- [ ] Admin login werkt (admin/admin123)
- [ ] Nieuwe gebruiker kan worden aangemaakt
- [ ] Gebruiker kan inloggen
- [ ] Werknemer account kan worden aangemaakt

### Core Functionaliteiten Controle
- [ ] Bord kan worden geplaatst door gebruiker
- [ ] Afbeelding upload werkt bij bord plaatsing
- [ ] Admin kan borden bevestigen
- [ ] Status updates werken correct
- [ ] Bord verwijdering werkt

### Advanced Functionaliteiten Controle
- [ ] Factuur generatie werkt
- [ ] PDF download werkt
- [ ] Belgisch opvolgsysteem werkt
- [ ] Custom pricing per gebruiker werkt
- [ ] Work distribution onder werknemers werkt
- [ ] Placement details en afbeeldingen werken
- [ ] Proof images (bewijs van plaatsing/ophaling) werken

### Image Management Controle
- [ ] Afbeeldingen kunnen worden geüpload
- [ ] Afbeeldingen kunnen worden bekeken
- [ ] Afbeeldingen kunnen worden gedownload
- [ ] Image viewer modal werkt correct
- [ ] Placement images kunnen worden bekeken

## ✅ Data Integriteit Verificatie

### User Data Controle
- [ ] Gebruikers hebben correcte rollen
- [ ] Custom pricing instellingen werken
- [ ] Billing details kunnen worden opgeslagen

### Sign Data Controle
- [ ] Borden hebben correcte status
- [ ] Locatie data is correct
- [ ] Status history wordt bijgehouden
- [ ] Placement details worden opgeslagen

### Invoice Data Controle
- [ ] Facturen worden correct gegenereerd
- [ ] Belgische follow-up velden werken
- [ ] Pricing informatie wordt opgeslagen

## 🚨 Troubleshooting

### Als Storage Upload Niet Werkt
1. Voer `STORAGE_POLICIES_FIX.sql` uit
2. Controleer bucket instellingen in Dashboard
3. Controleer environment variables

### Als Authentication Niet Werkt
1. Controleer environment variables
2. Controleer Site URL in Authentication settings
3. Controleer browser console voor errors

### Als Database Queries Falen
1. Controleer RLS policies
2. Controleer table permissions
3. Voer verificatie queries uit

## ✅ Migratie Voltooid

Wanneer alle items zijn afgevinkt, is je migratie succesvol voltooid!

Je nieuwe Supabase account heeft nu alle functionaliteiten van het oude account:
- Complete database schema
- Veilige storage configuratie  
- Alle applicatie functionaliteiten
- Belgian invoice follow-up system
- Multi-user support met rollen
- Custom pricing per gebruiker
- Work distribution systeem
- Image management met metadata
- Placement details en proof images

🎉 **Je Sign Management System is nu volledig operationeel op je nieuwe Supabase account!**