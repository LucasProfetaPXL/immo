import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { v4 as uuidv4 } from '../utils/uuid';
import { Invoice, InvoiceStatus, SignData } from '../types';
import { useSigns } from './SignsContext';
import { addDays, isAfter } from 'date-fns';
import { calculateSignCost, calculateSignCostWithPricing, getUserPricing } from '../utils/costCalculator';
import { generateInvoicePDF, generateCombinedInvoicePDF } from '../lib/pdf';
import { getNextInvoiceNumber } from '../lib/invoiceNumbering';
import { processInvoiceFollowUp } from '../lib/belgianFollowUp';
import toast from 'react-hot-toast';

interface InvoiceContextType {
  invoices: Invoice[];
  deletedInvoices: Invoice[];
  generateInvoice: (signId: string, billingDetails: any) => Promise<string>;
  generateAllInvoices: (billingDetails: any) => Promise<string[]>;
  markInvoiceAsPaid: (invoiceId: string) => void;
  markInvoiceAsUnpaid: (invoiceId: string) => void;
  deleteInvoice: (invoiceId: string) => void;
  restoreInvoice: (invoiceId: string) => void;
  deleteAllPaidInvoices: () => void;
  getInvoiceById: (invoiceId: string) => Invoice | undefined;
  getInvoicesByStatus: (status: InvoiceStatus) => Invoice[];
  getUserBillingDetails: () => any;
  setUserBillingDetails: (details: any) => void;
  getAllInvoices: () => Invoice[]; // For admin access
  getAllDeletedInvoices: () => Invoice[]; // For admin access to deleted invoices
  processFollowUps: () => void; // Manual trigger for follow-ups
  getOverdueInvoices: () => Invoice[];
  sendReminder: (invoiceId: string) => void;
}

const InvoiceContext = createContext<InvoiceContextType | undefined>(undefined);

export function InvoiceProvider({ children }: { children: ReactNode }) {
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const [allDeletedInvoices, setAllDeletedInvoices] = useState<Invoice[]>([]);
  const [userBillingDetails, setUserBillingDetails] = useState<any>(null);
  const { getSignById, updateSign, getAllSignsIncludingHidden } = useSigns(); // Use hidden signs for invoices

  // Get current user info
  const getCurrentUser = () => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      return JSON.parse(currentUser);
    }
    return null;
  };

  // Filter invoices for current user (unless admin)
  const getFilteredInvoices = () => {
    const user = getCurrentUser();
    if (!user) return [];
    
    if (user.isAdmin) {
      return allInvoices; // Admin sees all invoices
    }
    
    // Regular users only see their own invoices
    return allInvoices.filter(invoice => invoice.userId === user.id);
  };

  const getFilteredDeletedInvoices = () => {
    const user = getCurrentUser();
    if (!user) return [];
    
    if (user.isAdmin) {
      return allDeletedInvoices; // Admin sees all deleted invoices
    }
    
    // Regular users only see their own deleted invoices
    return allDeletedInvoices.filter(invoice => invoice.userId === user.id);
  };

  // Load invoices from localStorage
  useEffect(() => {
    const savedInvoices = localStorage.getItem('allInvoices');
    if (savedInvoices) {
      try {
        setAllInvoices(JSON.parse(savedInvoices));
      } catch (error) {
        console.error('Error loading invoices:', error);
      }
    }

    const savedDeletedInvoices = localStorage.getItem('allDeletedInvoices');
    if (savedDeletedInvoices) {
      try {
        setAllDeletedInvoices(JSON.parse(savedDeletedInvoices));
      } catch (error) {
        console.error('Error loading deleted invoices:', error);
      }
    }
  }, []);

  // Save invoices to localStorage
  useEffect(() => {
    localStorage.setItem('allInvoices', JSON.stringify(allInvoices));
  }, [allInvoices]);

  useEffect(() => {
    localStorage.setItem('allDeletedInvoices', JSON.stringify(allDeletedInvoices));
  }, [allDeletedInvoices]);

  // Load saved billing details from localStorage (user-specific)
  useEffect(() => {
    const user = getCurrentUser();
    if (user && !user.isAdmin) {
      const savedBillingDetails = localStorage.getItem(`userBillingDetails_${user.id}`);
      if (savedBillingDetails) {
        try {
          setUserBillingDetails(JSON.parse(savedBillingDetails));
        } catch (error) {
          console.error('Error loading billing details:', error);
          setUserBillingDetails(null);
        }
      }
    }
  }, []);

  // Save billing details to localStorage when updated (user-specific)
  useEffect(() => {
    const user = getCurrentUser();
    if (userBillingDetails && user && !user.isAdmin) {
      try {
        localStorage.setItem(`userBillingDetails_${user.id}`, JSON.stringify(userBillingDetails));
      } catch (error) {
        console.error('Error saving billing details:', error);
      }
    }
  }, [userBillingDetails]);

  // Process follow-ups every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      processFollowUps();
    }, 5 * 60 * 1000); // 5 minutes

    // Also run on component mount
    processFollowUps();

    return () => clearInterval(interval);
  }, [allInvoices]);

  const processFollowUps = () => {
    setAllInvoices(prevInvoices => {
      const updatedInvoices = [...prevInvoices];
      let hasUpdates = false;

      prevInvoices.forEach((invoice, index) => {
        const followUpResult = processInvoiceFollowUp(invoice);
        
        if (followUpResult.needsAction && followUpResult.updatedInvoice) {
          updatedInvoices[index] = {
            ...invoice,
            ...followUpResult.updatedInvoice
          };
          hasUpdates = true;

          // In a real application, you would send the email here
          if (followUpResult.reminderEmail) {
            console.log('📧 Reminder email would be sent:', followUpResult.reminderEmail);
            
            // Show notification to user about reminder being sent
            if (followUpResult.actionType === 'first_reminder') {
              toast.success(`Eerste herinnering verstuurd voor factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`);
            } else if (followUpResult.actionType === 'second_reminder') {
              toast.warning(`Tweede herinnering verstuurd voor factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`);
            } else if (followUpResult.actionType === 'final_reminder') {
              toast.error(`Laatste herinnering verstuurd voor factuur ${invoice.invoiceNumber || invoice.id.substring(0, 8)}`);
            }
          }
        }
      });

      return hasUpdates ? updatedInvoices : prevInvoices;
    });
  };

  const generateInvoice = async (signId: string, billingDetails: any): Promise<string> => {
    const user = getCurrentUser();
    if (!user || user.isAdmin) {
      throw new Error('Only regular users can generate invoices');
    }

    const sign = getSignById(signId);
    
    if (!sign) {
      throw new Error('Sign not found');
    }
    
    // Check if invoice already exists for this sign
    const existingInvoice = allInvoices.find(inv => inv.signId === signId);
    if (existingInvoice) {
      return existingInvoice.id;
    }
    
    // Get user-specific pricing
    const userPricing = getUserPricing(user.id);
    
    // Calculate sign cost with user pricing
    const totalCost = calculateSignCost(sign);
    
    // Calculate days active
    let days = 0;
    if (sign.placedAt && sign.removalRequestedAt) {
      const placedDate = new Date(sign.placedAt);
      const removalDate = new Date(sign.removalRequestedAt);
      days = Math.max(0, Math.floor(
        (removalDate.getTime() - placedDate.getTime()) / (1000 * 60 * 60 * 24)
      )) + 1; // +1 to include both days
    }
    
    const invoiceId = uuidv4();
    const invoiceNumber = getNextInvoiceNumber(); // Global invoice numbering
    
    const newInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber,
      signId,
      userId: user.id, // Associate invoice with current user
      companyName: sign.companyName,
      address: sign.address,
      billingDetails,
      amount: totalCost,
      status: 'unpaid',
      reminderStatus: 'none',
      createdAt: new Date().toISOString(),
      dueDate: addDays(new Date(), 30).toISOString(),
      days,
      // Belgian follow-up system fields
      totalAmountDue: totalCost, // Initially same as amount
      // Store pricing used for this invoice
      pricingUsed: {
        baseCost: userPricing.baseCost,
        dailyCost: userPricing.dailyCost
      }
    };
    
    setAllInvoices(prev => [...prev, newInvoice]);
    
    // Update sign status to invoiced
    updateSign(signId, { 
      invoiceStatus: 'invoiced',
      updatedAt: new Date().toISOString()
    });
    
    // Generate and download PDF
    try {
      const pdfDoc = await generateInvoicePDF(newInvoice);
      pdfDoc.save(`Factuur_${invoiceNumber}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
      // Continue with invoice creation even if PDF fails
    }
    
    // Save billing details for future use if not already saved (user-specific)
    if (!userBillingDetails) {
      setUserBillingDetails(billingDetails);
    }
    
    return invoiceId;
  };

  const generateAllInvoices = async (billingDetails: any): Promise<string[]> => {
    const user = getCurrentUser();
    if (!user || user.isAdmin) {
      throw new Error('Only regular users can generate invoices');
    }

    const userSigns = getAllSignsIncludingHidden().filter(sign => sign.userId === user.id); // Get user's signs including hidden
    const eligibleSigns = userSigns.filter(sign => 
      (sign.status === 'removal-requested' || sign.status === 'removal-confirmed' || sign.status === 'removed') && 
      !sign.invoiceStatus
    );
    
    if (eligibleSigns.length === 0) {
      return [];
    }
    
    // Get user-specific pricing
    const userPricing = getUserPricing(user.id);
    
    // Create one combined invoice for all eligible signs
    const invoiceId = uuidv4();
    const invoiceNumber = getNextInvoiceNumber(); // Global invoice numbering
    
    // Calculate total amount and prepare sign details
    let totalAmount = 0;
    const signDetails = eligibleSigns.map(sign => {
      const cost = calculateSignCost(sign);
      totalAmount += cost;
      
      let days = 0;
      if (sign.placedAt && sign.removalRequestedAt) {
        const placedDate = new Date(sign.placedAt);
        const removalDate = new Date(sign.removalRequestedAt);
        days = Math.max(0, Math.floor(
          (removalDate.getTime() - placedDate.getTime()) / (1000 * 60 * 60 * 24)
        )) + 1;
      }
      
      return {
        id: sign.id,
        address: sign.address,
        days,
        cost
      };
    });
    
    // Create combined invoice
    const combinedInvoice: Invoice = {
      id: invoiceId,
      invoiceNumber,
      signId: 'combined', // Special identifier for combined invoices
      userId: user.id, // Associate invoice with current user
      companyName: 'Gecombineerde Factuur',
      address: `${eligibleSigns.length} borden`,
      billingDetails,
      amount: totalAmount,
      status: 'unpaid',
      reminderStatus: 'none',
      createdAt: new Date().toISOString(),
      dueDate: addDays(new Date(), 30).toISOString(),
      days: 0, // Not applicable for combined invoice
      signDetails, // Add sign details for PDF generation
      // Belgian follow-up system fields
      totalAmountDue: totalAmount, // Initially same as amount
      // Store pricing used for this invoice
      pricingUsed: {
        baseCost: userPricing.baseCost,
        dailyCost: userPricing.dailyCost
      }
    };
    
    setAllInvoices(prev => [...prev, combinedInvoice]);
    
    // Update all signs to invoiced status
    eligibleSigns.forEach(sign => {
      updateSign(sign.id, { 
        invoiceStatus: 'invoiced',
        updatedAt: new Date().toISOString()
      });
    });
    
    // Generate and download combined PDF
    try {
      const pdfDoc = await generateCombinedInvoicePDF(combinedInvoice, eligibleSigns);
      pdfDoc.save(`Gecombineerde_Factuur_${invoiceNumber}.pdf`);
    } catch (error) {
      console.error('Error generating combined PDF:', error);
    }
    
    // Save billing details for future use if not already saved (user-specific)
    if (!userBillingDetails) {
      setUserBillingDetails(billingDetails);
    }
    
    return [invoiceId];
  };

  const markInvoiceAsPaid = (invoiceId: string) => {
    setAllInvoices(prevInvoices => 
      prevInvoices.map(invoice => 
        invoice.id === invoiceId 
          ? { 
              ...invoice, 
              status: 'paid', 
              paidAt: new Date().toISOString(),
              reminderStatus: 'none'
            } 
          : invoice
      )
    );
  };

  const markInvoiceAsUnpaid = (invoiceId: string) => {
    setAllInvoices(prevInvoices => 
      prevInvoices.map(invoice => 
        invoice.id === invoiceId 
          ? { 
              ...invoice, 
              status: 'unpaid', 
              paidAt: undefined
            } 
          : invoice
      )
    );
  };

  const deleteInvoice = (invoiceId: string) => {
    setAllInvoices(prevInvoices => {
      const invoiceToDelete = prevInvoices.find(inv => inv.id === invoiceId);
      
      if (invoiceToDelete) {
        setAllDeletedInvoices(prev => [...prev, {
          ...invoiceToDelete,
          deletedAt: new Date().toISOString()
        }]);
      }
      
      return prevInvoices.filter(inv => inv.id !== invoiceId);
    });
  };

  const restoreInvoice = (invoiceId: string) => {
    setAllDeletedInvoices(prevDeleted => {
      const invoiceToRestore = prevDeleted.find(inv => inv.id === invoiceId);
      
      if (invoiceToRestore) {
        const { deletedAt, ...restoreData } = invoiceToRestore;
        setAllInvoices(prev => [...prev, restoreData]);
      }
      
      return prevDeleted.filter(inv => inv.id !== invoiceId);
    });
  };

  const deleteAllPaidInvoices = () => {
    const filteredInvoices = getFilteredInvoices();
    const paidInvoices = filteredInvoices.filter(inv => inv.status === 'paid');
    
    if (paidInvoices.length > 0) {
      setAllDeletedInvoices(prev => [
        ...prev,
        ...paidInvoices.map(inv => ({
          ...inv,
          deletedAt: new Date().toISOString()
        }))
      ]);
      
      // Remove paid invoices from all invoices
      setAllInvoices(prev => prev.filter(inv => 
        !paidInvoices.some(paidInv => paidInv.id === inv.id)
      ));
    }
  };

  const getInvoiceById = (invoiceId: string) => {
    const user = getCurrentUser();
    
    // Admin can see all invoices including deleted ones
    if (user && user.isAdmin) {
      return allInvoices.find(inv => inv.id === invoiceId) || 
             allDeletedInvoices.find(inv => inv.id === invoiceId);
    }
    
    // Regular users only see their own invoices
    const filteredInvoices = getFilteredInvoices();
    const filteredDeletedInvoices = getFilteredDeletedInvoices();
    
    return filteredInvoices.find(inv => inv.id === invoiceId) || 
           filteredDeletedInvoices.find(inv => inv.id === invoiceId);
  };

  const getInvoicesByStatus = (status: InvoiceStatus) => {
    const filteredInvoices = getFilteredInvoices();
    return filteredInvoices.filter(inv => inv.status === status);
  };

  const getAllInvoices = () => {
    return allInvoices; // For admin access to all invoices
  };

  const getAllDeletedInvoices = () => {
    return allDeletedInvoices; // For admin access to all deleted invoices
  };

  const getOverdueInvoices = () => {
    const now = new Date();
    const filteredInvoices = getFilteredInvoices();
    return filteredInvoices.filter(invoice => 
      invoice.status === 'unpaid' && 
      isAfter(now, new Date(invoice.dueDate))
    );
  };

  const sendReminder = (invoiceId: string) => {
    const invoice = allInvoices.find(inv => inv.id === invoiceId);
    if (!invoice) return;

    const followUpResult = processInvoiceFollowUp(invoice);
    
    if (followUpResult.needsAction && followUpResult.updatedInvoice) {
      setAllInvoices(prev => 
        prev.map(inv => 
          inv.id === invoiceId 
            ? { ...inv, ...followUpResult.updatedInvoice }
            : inv
        )
      );

      if (followUpResult.reminderEmail) {
        console.log('📧 Manual reminder sent:', followUpResult.reminderEmail);
        toast.success('Herinnering verstuurd');
      }
    }
  };

  const getUserBillingDetailsFunc = () => {
    return userBillingDetails;
  };

  const setUserBillingDetailsFunc = (details: any) => {
    setUserBillingDetails(details);
  };

  const value = {
    invoices: getFilteredInvoices(),
    deletedInvoices: getFilteredDeletedInvoices(),
    generateInvoice,
    generateAllInvoices,
    markInvoiceAsPaid,
    markInvoiceAsUnpaid,
    deleteInvoice,
    restoreInvoice,
    deleteAllPaidInvoices,
    getInvoiceById,
    getInvoicesByStatus,
    getUserBillingDetails: getUserBillingDetailsFunc,
    setUserBillingDetails: setUserBillingDetailsFunc,
    getAllInvoices,
    getAllDeletedInvoices, // New function for admin access to deleted invoices
    processFollowUps,
    getOverdueInvoices,
    sendReminder
  };

  return (
    <InvoiceContext.Provider value={value}>
      {children}
    </InvoiceContext.Provider>
  );
}

export function useInvoices() {
  const context = useContext(InvoiceContext);
  if (context === undefined) {
    throw new Error('useInvoices must be used within an InvoiceProvider');
  }
  return context;
}