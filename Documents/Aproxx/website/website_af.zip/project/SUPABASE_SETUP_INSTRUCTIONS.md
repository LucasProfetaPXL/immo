# Supabase Storage Setup Instructions

Het probleem met de image uploads is dat de RLS (Row Level Security) policies voor storage niet correct zijn ingesteld. Volg deze stappen om het op te lossen:

## Stap 1: Ga naar je Supabase Dashboard
1. Open [https://supabase.com/dashboard](https://supabase.com/dashboard)
2. Selecteer je project
3. Ga naar **Storage** in het linker menu

## Stap 2: Controleer of de 'images' bucket bestaat
1. Kijk of er een bucket genaamd "images" bestaat
2. Als deze niet bestaat, klik op **"New bucket"**
3. Naam: `images`
4. Zet **"Public bucket"** aan (toggle naar rechts)
5. Klik **"Save"**

## Stap 3: Configureer Storage Policies
1. Ga naar **Storage** → **Policies**
2. Klik op **"New policy"** voor de `objects` tabel
3. Maak de volgende policies aan:

### Policy 1: Upload Policy
- **Policy name**: `Allow authenticated uploads`
- **Allowed operation**: `INSERT`
- **Target roles**: `authenticated`
- **USING expression**: (laat leeg)
- **WITH CHECK expression**: 
```sql
bucket_id = 'images'
```

### Policy 2: Public Read Policy
- **Policy name**: `Allow public downloads`
- **Allowed operation**: `SELECT`
- **Target roles**: `public`
- **USING expression**: 
```sql
bucket_id = 'images'
```

### Policy 3: Delete Policy
- **Policy name**: `Allow authenticated deletes`
- **Allowed operation**: `DELETE`
- **Target roles**: `authenticated`
- **USING expression**: 
```sql
bucket_id = 'images'
```

### Policy 4: Update Policy
- **Policy name**: `Allow authenticated updates`
- **Allowed operation**: `UPDATE`
- **Target roles**: `authenticated`
- **USING expression**: 
```sql
bucket_id = 'images'
```
- **WITH CHECK expression**: 
```sql
bucket_id = 'images'
```

## Stap 4: Test de configuratie
1. Ga terug naar je applicatie
2. Probeer een afbeelding te uploaden
3. De upload zou nu moeten werken zonder errors

## Alternatieve methode via SQL Editor
Als je de policies liever via SQL wilt instellen:

1. Ga naar **SQL Editor** in je Supabase Dashboard
2. Voer deze query uit:

```sql
-- Maak de images bucket aan (als deze nog niet bestaat)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'images',
  'images',
  true,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO UPDATE SET
  public = true,
  file_size_limit = 10485760,
  allowed_mime_types = ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];

-- Verwijder bestaande policies om conflicten te voorkomen
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated deletes" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated updates" ON storage.objects;

-- Maak nieuwe policies aan
CREATE POLICY "Allow authenticated uploads"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow public downloads"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated deletes"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated updates"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'images')
WITH CHECK (bucket_id = 'images');
```

## Verificatie
Na het instellen van de policies zou je geen "Unauthorized" errors meer moeten krijgen bij het uploaden van afbeeldingen.

Als je nog steeds problemen hebt, controleer dan:
1. Of je Supabase project actief is
2. Of de environment variables correct zijn ingesteld
3. Of je internetverbinding stabiel is