import React, { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import toast from 'react-hot-toast';
import LoginPage from './components/auth/LoginPage';
import AdminDashboard from './components/admin/AdminDashboard';
import UserDashboard from './components/user/UserDashboard';
import EmployeeDashboard from './components/employee/EmployeeDashboard';
import { AuthProvider } from './context/AuthContext';
import { SignsProvider } from './context/SignsContext';
import { InvoiceProvider } from './context/InvoiceContext';
import { decryptData, encryptData } from './utils/encryption';
import { testLocalStorage } from './utils/storageUtils';
import './App.css';

interface UserAccount {
  id: string;
  companyName: string;
  username: string;
  password: string;
  createdAt: string;
  lastLogin?: string;
  role?: 'user' | 'employee';
  parentUserId?: string;
}

const STORAGE_KEY = 'userAccounts_encrypted';
const ADMIN_CREDENTIALS_KEY = 'adminCredentials_encrypted';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isEmployee, setIsEmployee] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  // Test localStorage availability on component mount
  useEffect(() => {
    const storageAvailable = testLocalStorage();
    if (!storageAvailable) {
      console.error('⚠️ localStorage is not available! Data persistence will not work.');
      toast.error('Waarschuwing: Lokale opslag is niet beschikbaar. Gegevens worden niet bewaard tussen sessies.', {
        duration: 6000,
      });
    }
  }, []);

  // Initialize storage ONLY ONCE on app start
  useEffect(() => {
    if (!isInitialized) {
      console.log('🚀 App initializing for the first time...');
      initializeStorageOnce();
      checkExistingLogin();
      setIsInitialized(true);
    }
  }, [isInitialized]);

  // Initialize storage with default admin credentials if needed - ONLY ONCE
  const initializeStorageOnce = () => {
    console.log('🔧 Initializing storage (one-time only)...');

    // Test localStorage availability
    if (!testLocalStorage()) {
      console.error('⚠️ localStorage is not available! Cannot initialize storage.');
      return;
    }
    
    // Initialize admin credentials ONLY if they don't exist
    const adminCredentials = localStorage.getItem(ADMIN_CREDENTIALS_KEY);
    if (!adminCredentials) {
      console.log('📝 Creating default admin credentials...');
      const defaultAdmin = { username: 'admin', password: 'admin123' };
      try {
        const dataToEncrypt = JSON.stringify(defaultAdmin);
        const encryptedData = encryptData(dataToEncrypt);
        localStorage.setItem(ADMIN_CREDENTIALS_KEY, JSON.stringify(encryptedData));
        console.log('✅ Default admin credentials created successfully');
      } catch (error) {
        console.error('❌ Error creating admin credentials:', error);
      }
    } else {
      console.log('✅ Admin credentials already exist');
    }

    // Initialize user accounts storage ONLY if it doesn't exist
    const userAccounts = localStorage.getItem(STORAGE_KEY);
    if (!userAccounts) {
      console.log('📝 Creating empty user accounts storage...');
      // Create empty encrypted storage ONLY if none exists
      try {
        const emptyData = JSON.stringify([]);
        const encryptedData = encryptData(emptyData);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(encryptedData));
        console.log('✅ Empty user accounts storage created successfully');
      } catch (error) {
        console.error('❌ Error creating user accounts storage:', error);
      }
    } else {
      console.log('✅ User accounts storage already exists');
    }
    
    console.log('✅ Storage initialization complete');
  };

  // Check if user is already logged in
  const checkExistingLogin = () => {
    const user = localStorage.getItem('currentUser');
    if (user) { 
      try {
        const userData = JSON.parse(user);
        setIsAuthenticated(true);
        setIsAdmin(userData.isAdmin || false);
        setIsEmployee(userData.isEmployee || false);
        setCurrentUser(userData.isAdmin ? null : userData);
      } catch (error) {
        console.error('Error parsing current user:', error);
        localStorage.removeItem('currentUser');
      }
    }
  };

  // Load admin credentials - NEVER MODIFY STORAGE HERE
  const getAdminCredentials = () => {
    const saved = localStorage.getItem(ADMIN_CREDENTIALS_KEY);
    if (saved) {
      try {
        const encryptedData = JSON.parse(saved);
        const decryptedData = decryptData(encryptedData);
        return JSON.parse(decryptedData);
      } catch (error) {
        console.error('Error loading admin credentials:', error);
      }
    }
    // Return default credentials if none found
    return { username: 'admin', password: 'admin123' };
  };

  // Load all user accounts from encrypted storage - NEVER MODIFY STORAGE HERE
  const loadUserAccounts = (): UserAccount[] => {
    const savedUsers = localStorage.getItem(STORAGE_KEY);
    if (savedUsers) {
      try {
        const encryptedData = JSON.parse(savedUsers);
        const decryptedData = decryptData(encryptedData);
        return JSON.parse(decryptedData);
      } catch (error) {
        console.error('Error loading user accounts:', error);
        return [];
      }
    }
    return [];
  };

  // Save user accounts to encrypted storage - ONLY CALLED WHEN EXPLICITLY NEEDED
  const saveUserAccounts = (users: UserAccount[]) => {
    try {
      console.log(`💾 Saving ${users.length} user accounts to encrypted storage`);
      const dataToEncrypt = JSON.stringify(users);
      const encryptedData = encryptData(dataToEncrypt);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(encryptedData));
      console.log('💾 User accounts saved successfully');
    } catch (error) {
      console.error('Error saving user accounts:', error);
    }
  };

  const handleLogin = (username: string, password: string) => {
    // Get current admin credentials
    const adminCredentials = getAdminCredentials();
    console.log(`🔑 Login attempt for user: ${username}`);
    
    // Check admin login with current credentials
    if (username === adminCredentials.username && password === adminCredentials.password) {
      console.log('✅ Admin login successful');
      const adminData = { username: adminCredentials.username, isAdmin: true };
      localStorage.setItem('currentUser', JSON.stringify(adminData));
      setIsAuthenticated(true);
      setIsAdmin(true);
      setIsEmployee(false);
      setCurrentUser(null);
      return true;
    }

    // Check user accounts from encrypted storage
    const users = loadUserAccounts();
    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
      console.log(`✅ User login successful: ${user.username} (${user.role || 'user'})`);
      // Update last login time in encrypted storage
      const updatedUsers = users.map(u => 
        u.id === user.id 
          ? { ...u, lastLogin: new Date().toISOString() }
          : u
      );
      
      // Save updated users back to encrypted storage
      saveUserAccounts(updatedUsers);
      
      // Set current user
      const userData = { 
        ...user, 
        isAdmin: false, 
        isEmployee: user.role === 'employee',
        lastLogin: new Date().toISOString() 
      };
      localStorage.setItem('currentUser', JSON.stringify(userData));
      setIsAuthenticated(true);
      setIsAdmin(false);
      setIsEmployee(user.role === 'employee');
      setCurrentUser(userData);
      return true;
    }
    
    console.log('❌ Login failed: Invalid credentials');
    return false;
  };

  const handleLogout = () => {
    console.log('🚪 Logging out user...');
    
    // CRITICAL: ONLY REMOVE CURRENT USER SESSION
    // NEVER TOUCH ANY OTHER STORAGE KEYS
    localStorage.removeItem('currentUser');
    
    // Reset state
    setIsAuthenticated(false);
    setIsAdmin(false);
    setIsEmployee(false); 
    setCurrentUser(null);
    
    // ABSOLUTELY DO NOT TOUCH THESE STORAGE KEYS:
    // - userAccounts_encrypted (contains all users and employees)
    // - adminCredentials_encrypted (contains admin credentials)
    // These must remain persistent across all sessions
    
    console.log('✅ Logout completed - user storage preserved');
  };

  const renderDashboard = () => {
    if (isAdmin) {
      return <AdminDashboard />;
    } else if (isEmployee) {
      return <EmployeeDashboard />;
    } else {
      return <UserDashboard />;
    }
  };

  return (
    <AuthProvider value={{ 
      isAuthenticated, 
      isAdmin, 
      isEmployee, 
      login: handleLogin, 
      logout: handleLogout 
    }}>
      <SignsProvider>
        <InvoiceProvider>
          <div className="App font-montserrat">
            {!isAuthenticated ? (
              <LoginPage onLogin={handleLogin} />
            ) : (
              renderDashboard()
            )}
            <Toaster position="top-right" />
          </div>
        </InvoiceProvider>
      </SignsProvider>
    </AuthProvider>
  );
}

export default App;