# EXACTE STORAGE POLICIES DIE JE NODIG HEBT

Het probleem is dat je storage policies niet correct zijn. Volg deze EXACTE stappen:

## Stap 1: Ga naar Storage Policies
1. Ga naar je Supabase Dashboard
2. Klik op **Storage** (links in menu)
3. Klik op **Policies** tab (bovenaan)
4. Je ziet nu de `storage.objects` tabel

## Stap 2: Verwijder ALLE bestaande policies
1. Verwijder alle bestaande policies voor `storage.objects`
2. Klik op de 3 puntjes naast elke policy en kies "Delete"

## Stap 3: Maak deze 4 EXACTE policies aan

### Policy 1: Upload Policy
- Klik **"New Policy"**
- **Policy name**: `Allow authenticated uploads`
- **Allowed operation**: `INSERT`
- **Target roles**: `authenticated`
- **USING expression**: (laat leeg)
- **WITH CHECK expression**: 
```sql
bucket_id = 'images'
```

### Policy 2: Public Read Policy
- Klik **"New Policy"**
- **Policy name**: `Allow public downloads`
- **Allowed operation**: `SELECT`
- **Target roles**: `public`
- **USING expression**: 
```sql
bucket_id = 'images'
```

### Policy 3: Delete Policy
- Klik **"New Policy"**
- **Policy name**: `Allow authenticated deletes`
- **Allowed operation**: `DELETE`
- **Target roles**: `authenticated`
- **USING expression**: 
```sql
bucket_id = 'images'
```

### Policy 4: Update Policy
- Klik **"New Policy"**
- **Policy name**: `Allow authenticated updates`
- **Allowed operation**: `UPDATE`
- **Target roles**: `authenticated`
- **USING expression**: 
```sql
bucket_id = 'images'
```
- **WITH CHECK expression**: 
```sql
bucket_id = 'images'
```

## ALTERNATIEF: Via SQL Editor (SNELLER)

Ga naar **SQL Editor** en voer deze query uit:

```sql
-- Verwijder alle bestaande policies
DROP POLICY IF EXISTS "Allow authenticated uploads" ON storage.objects;
DROP POLICY IF EXISTS "Allow public downloads" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated deletes" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated updates" ON storage.objects;
DROP POLICY IF EXISTS "Give users access to own folder" ON storage.objects;
DROP POLICY IF EXISTS "Allow public access" ON storage.objects;

-- Maak de juiste policies aan
CREATE POLICY "Allow authenticated uploads"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow public downloads"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated deletes"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'images');

CREATE POLICY "Allow authenticated updates"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'images')
WITH CHECK (bucket_id = 'images');
```

## Controleer ook dit:
1. Ga naar **Storage** → **Settings**
2. Zorg dat **"Enable RLS"** AAN staat voor storage.objects
3. Zorg dat je images bucket **PUBLIC** is (toggle aan)

Na deze stappen zou het moeten werken!